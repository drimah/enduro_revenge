extends Control
## Controles de toque com multitoque real (vários dedos ao mesmo tempo).
## Botões "tap" disparam o sinal `tapped`; botões "hold" ficam consultáveis via is_held().

signal tapped(action: String)

var buttons: Array[Dictionary] = []
var touches := {}       # índice do toque -> ação
var held := {}          # ação -> quantidade de dedos segurando
var item_label := "ITEM":
	set(v):
		if v != item_label:
			item_label = v
			queue_redraw()

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	get_viewport().size_changed.connect(_layout)
	_layout()

func _layout() -> void:
	var s := get_viewport().get_visible_rect().size
	buttons = [
		{"action": "left", "label": "◀", "pos": Vector2(105, s.y - 110), "r": 72.0, "hold": false},
		{"action": "right", "label": "▶", "pos": Vector2(265, s.y - 110), "r": 72.0, "hold": false},
		{"action": "jump", "label": "PULAR", "pos": Vector2(s.x - 118, s.y - 118), "r": 80.0, "hold": false},
		{"action": "item", "label": "ITEM", "pos": Vector2(s.x - 118, s.y - 292), "r": 52.0, "hold": false},
		{"action": "accel", "label": "▲", "pos": Vector2(s.x - 285, s.y - 205), "r": 50.0, "hold": true},
		{"action": "brake", "label": "▼", "pos": Vector2(s.x - 285, s.y - 82), "r": 50.0, "hold": true},
	]
	queue_redraw()

func is_held(action: String) -> bool:
	return held.get(action, 0) > 0

func release_all() -> void:
	touches.clear()
	held.clear()
	queue_redraw()

func _hit(p: Vector2) -> String:
	for b in buttons:
		if p.distance_to(b["pos"]) <= float(b["r"]) * 1.18:
			return b["action"]
	return ""

func _press(index: int, p: Vector2) -> bool:
	var a := _hit(p)
	if a == "":
		return false
	touches[index] = a
	held[a] = held.get(a, 0) + 1
	tapped.emit(a)
	queue_redraw()
	return true

func _release(index: int) -> void:
	if touches.has(index):
		var a: String = touches[index]
		held[a] = maxi(0, held.get(a, 0) - 1)
		touches.erase(index)
		queue_redraw()

func _input(event: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			if _press(event.index, event.position):
				get_viewport().set_input_as_handled()
		else:
			_release(event.index)
	elif event is InputEventMouseButton and event.device != InputEvent.DEVICE_ID_EMULATION and event.button_index == MOUSE_BUTTON_LEFT:
		# Mouse de verdade (para testar no PC). Toques emulados como mouse são ignorados.
		if event.pressed:
			if _press(1000, event.position):
				get_viewport().set_input_as_handled()
		else:
			_release(1000)

func _draw() -> void:
	var font := ThemeDB.fallback_font
	for b in buttons:
		var a: String = b["action"]
		var pressed := is_held(a)
		var c := Color(0.05, 0.18, 0.42, 0.45)
		if pressed:
			c = Color(0.15, 0.48, 0.85, 0.8)
		var pos: Vector2 = b["pos"]
		var r: float = b["r"]
		draw_circle(pos, r, c)
		draw_arc(pos, r, 0, TAU, 48, Color(1, 1, 1, 0.8), 3.0, true)
		var text: String = b["label"]
		if a == "item":
			text = item_label
		var fs := 40 if text.length() <= 1 else 20
		var tsize := font.get_string_size(text, HORIZONTAL_ALIGNMENT_CENTER, -1, fs)
		draw_string(font, pos + Vector2(-tsize.x * 0.5, fs * 0.36), text, HORIZONTAL_ALIGNMENT_CENTER, -1, fs, Color(1, 1, 1, 0.95))

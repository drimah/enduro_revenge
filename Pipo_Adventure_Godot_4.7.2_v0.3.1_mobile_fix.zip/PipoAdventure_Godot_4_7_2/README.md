# PIPO ADVENTURE — Godot 4.7.2

Homenagem ao **Penguin Adventure** (Konami, MSX, 1986), imaginando o que a série teria
se não tivesse sido descontinuada. Abra a pasta no **Godot 4.7.2** (Windows ou Linux Mint)
e aperte **F5**. Não precisa de nenhum plugin.

## Versão 0.4.2 — ícone do app
- Ícone do Pipo com o peixinho (`assets/icons/`), já ligado ao projeto, ao executável do Windows e à tela de abertura.
- **Android:** na janela de exportação (Projeto → Exportar → Android → *Launcher Icons*), aponte:
  - Main 192x192 → `res://assets/icons/icon_android_192.png`
  - Adaptive Foreground 432x432 → `res://assets/icons/icon_android_foreground.png`
  - Adaptive Background 432x432 → `res://assets/icons/icon_android_background.png`
  (Se deixar em branco, o Godot usa o ícone do projeto, que também funciona.)

## Versão 0.4.1 — peixinho novo
- Os peixes da pista, os peixes voadores e os peixes dourados do chefe usam o modelo 3D do peixinho, virado de frente para o Pipo.

## Versão 0.4.0 — "A Maçã Dourada"

### História
A Princesa Penélope caiu doente. Só a lendária **Maçã Dourada**, guardada pelo Rei Sombra
no Castelo da Aurora, pode curá-la. Pipo calça os esquis e atravessa 5 mundos.

### O que entrou (inspirado no original do MSX)
- **Corrida contra o relógio**: cada fase tem uma distância e um tempo. Se o tempo acabar, perde uma vida.
- **Controle de velocidade** (como no MSX): acelerar e frear. Quem não acelera não chega a tempo.
- **Trombar não mata**: o Pipo cai, gira e perde tempo. **Buracos e fendas** derrubam o Pipo (e custam tempo).
- **Focas** que saem dos buracos, **peixes voadores** que pulam de um lado ao outro.
- **Loja do Tio Morsa** entre as fases: peixes são a moeda.
- **Tocas secretas**: buracos brilhantes dão peixes, tempo e pontos.

### O que uma continuação teria (novidades)
- **5 mundos × 3 fases** (2 fases + chefe):
  1. Planície Gelada — focas, bonecos de neve, peixes voadores
  2. Caverna de Cristal — morcegos, estalactites que caem, escuridão (compre a **Lanterna**)
  3. Mar Congelado — banquisas sobre o mar, fendas de água, gaivotas
  4. Floresta Perdida — troncos, mini-dinossauros, cogumelos-trampolim, vulcão ao fundo
  5. Castelo da Aurora — fantasmas que somem e aparecem, aurora boreal, castelo no horizonte
- **Chefes**: Rei Morsa, Morcegão, Polvo Kraken, Dino Rex e Rei Sombra. Cada um tem ataques
  próprios (bolas de neve, pedras, tentáculos que cobrem 2 pistas, troncos rolando, ondas de sombra).
  Pegue os **peixes dourados** para arremessá-los no chefe. No chefe você tem 3 corações.
- **Itens**: Hélice (voa 5 s), Capacete (aguenta 1 trombada), Botas Turbo, Lanterna, Relógio (+20 s), Vida extra.
- **Power-ups na pista**: Hélice, Relógio (+10 s), Ímã de peixes, Estrela de gelo (invencível).
- **Combos** de peixe, bônus de tempo e de peixes ao fim de cada fase.
- **Final** com a Princesa Penélope (o próprio modelo do Pipo recolorido por shader) e a Maçã Dourada.
- **Recorde salvo** e opção **Continuar** a partir do último mundo alcançado.
- **Trilhas novas** em estilo chiptune: chefe, loja, final, fase completa e game over, além de vários efeitos sonoros.

## Controles
| Ação | Teclado | Controle | Celular |
|---|---|---|---|
| Trocar de pista | ← → / A D | D-pad | ◀ ▶ |
| Acelerar / frear | ↑ ↓ / W S | D-pad ↑↓ ou RB / LB | ▲ ▼ |
| Pular | Espaço / Z | A | PULAR |
| Usar Hélice | E / Shift | B ou X | ITEM / VOAR |
| Pausar | Esc / P | Start | Ⅱ |

- Atenção: **W / ↑ agora aceleram** (na versão anterior pulavam). Pular é **Espaço**.
- Os botões de toque aparecem sozinhos em celular/tela touch. No PC, a tecla **T** liga/desliga.
- Os botões de toque agora aceitam **vários dedos ao mesmo tempo** (dá pra segurar ▲ e pular).
- O jogo pausa sozinho quando a janela perde o foco ou o app vai para segundo plano.

## Estrutura
- `scripts/game.gd` — jogo, estados, fases, chefes, loja, HUD, final
- `scripts/builder.gd` — temas dos 5 mundos e todos os modelos (primitivas com cache, leve para celular)
- `scripts/touch_pad.gd` — controles de toque multitoque
- `assets/pipo.obj` — modelo do Pipo (inalterado)
- `assets/peixinho.obj` — peixinho criado pelo autor (reduzido de 48 mil para 4 mil triângulos, cores mantidas); a versão dourada é o mesmo modelo pintado por shader
- `assets/audio/` — música e efeitos (os originais foram mantidos)

Renderer: Compatibility (OpenGL), o mesmo para PC e celular.

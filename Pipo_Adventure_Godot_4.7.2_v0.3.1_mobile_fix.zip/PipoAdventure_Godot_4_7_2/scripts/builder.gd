extends RefCounted
## Fábrica de malhas/materiais do Pipo Adventure.
## Tudo é feito com primitivas do Godot, com cache de materiais e malhas
## para rodar leve em celular (renderer Compatibility).

const THEMES := {
	"ice": {
		"sky_top": Color(0.12, 0.43, 0.95), "sky_horizon": Color(0.72, 0.87, 1.0),
		"ground": Color(0.9, 0.95, 1.0), "road": Color(0.5, 0.7, 0.95), "bank": Color(0.86, 0.92, 1.0),
		"side": Color(0.9, 0.94, 1.0), "fog": Color(0.8, 0.9, 1.0), "fog_density": 0.006,
		"ambient": Color(0.75, 0.83, 1.0), "ambient_energy": 0.6, "sun": Color(1, 0.98, 0.94), "sun_energy": 1.0,
		"gap": Color(0.05, 0.16, 0.38), "particles": "snow", "props": ["pine", "pine", "pine", "igloo", "ice_rock"],
		"block": "ice_block", "block2": "snowman",
	},
	"cave": {
		"sky_top": Color(0.03, 0.02, 0.08), "sky_horizon": Color(0.09, 0.05, 0.18),
		"ground": Color(0.18, 0.2, 0.32), "road": Color(0.42, 0.5, 0.7), "bank": Color(0.22, 0.24, 0.4),
		"side": Color(0.16, 0.16, 0.28), "fog": Color(0.06, 0.03, 0.12), "fog_density": 0.055,
		"ambient": Color(0.45, 0.4, 0.75), "ambient_energy": 0.55, "sun": Color(0.6, 0.55, 1.0), "sun_energy": 0.35,
		"gap": Color(0.0, 0.0, 0.02), "particles": "dust", "props": ["crystal", "crystal", "stalagmite_big", "crystal_cluster"],
		"block": "stalagmite", "block2": "ice_block",
	},
	"sea": {
		"sky_top": Color(0.2, 0.55, 0.95), "sky_horizon": Color(0.85, 0.93, 1.0),
		"ground": Color(0.05, 0.32, 0.62), "road": Color(0.85, 0.93, 1.0), "bank": Color(0.75, 0.88, 0.98),
		"side": Color(0.06, 0.38, 0.7), "fog": Color(0.78, 0.9, 1.0), "fog_density": 0.007,
		"ambient": Color(0.75, 0.85, 1.0), "ambient_energy": 0.65, "sun": Color(1, 0.97, 0.9), "sun_energy": 1.05,
		"gap": Color(0.03, 0.3, 0.62), "particles": "snow_light", "props": ["iceberg", "iceberg", "floe", "floe"],
		"block": "ice_block", "block2": "ice_block",
	},
	"forest": {
		"sky_top": Color(0.18, 0.55, 0.62), "sky_horizon": Color(0.95, 0.86, 0.62),
		"ground": Color(0.28, 0.55, 0.22), "road": Color(0.72, 0.6, 0.42), "bank": Color(0.36, 0.5, 0.22),
		"side": Color(0.25, 0.5, 0.2), "fog": Color(0.85, 0.82, 0.6), "fog_density": 0.012,
		"ambient": Color(0.85, 0.85, 0.7), "ambient_energy": 0.75, "sun": Color(1, 0.92, 0.75), "sun_energy": 1.2,
		"gap": Color(0.18, 0.1, 0.04), "particles": "leaves", "props": ["jungle_tree", "jungle_tree", "fern", "giant_mushroom"],
		"block": "rock", "block2": "rock",
	},
	"aurora": {
		"sky_top": Color(0.01, 0.02, 0.1), "sky_horizon": Color(0.1, 0.18, 0.35),
		"ground": Color(0.5, 0.55, 0.78), "road": Color(0.48, 0.55, 0.85), "bank": Color(0.7, 0.74, 0.95),
		"side": Color(0.45, 0.5, 0.75), "fog": Color(0.08, 0.12, 0.28), "fog_density": 0.014,
		"ambient": Color(0.55, 0.6, 1.0), "ambient_energy": 0.7, "sun": Color(0.6, 0.8, 1.0), "sun_energy": 0.6,
		"gap": Color(0.02, 0.0, 0.08), "particles": "sparkle", "props": ["ice_pillar", "ice_pillar", "pine_dark", "lamp_post"],
		"block": "ice_block", "block2": "ice_pillar_small",
	},
}

var _mats := {}
var _meshes := {}

# ------------------------------------------------------------------ util
func mat(color: Color, emission: float = 0.0, alpha: bool = false, unshaded: bool = false, rough: float = 0.8) -> StandardMaterial3D:
	var key := "%s|%s|%s|%s|%s" % [color.to_html(), emission, alpha, unshaded, rough]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	if rough >= 0.5:
		m.metallic_specular = 0.12
	if emission > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = emission
	if alpha or color.a < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	if unshaded:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_mats[key] = m
	return m

func box_mesh(size: Vector3) -> BoxMesh:
	var key := "box%s" % size
	if not _meshes.has(key):
		var b := BoxMesh.new()
		b.size = size
		_meshes[key] = b
	return _meshes[key]

func sphere_mesh(r: float, h: float, seg: int = 16) -> SphereMesh:
	var key := "sph%s_%s_%s" % [r, h, seg]
	if not _meshes.has(key):
		var s := SphereMesh.new()
		s.radius = r
		s.height = h
		s.radial_segments = seg
		s.rings = maxi(4, seg / 2)
		_meshes[key] = s
	return _meshes[key]

func cyl_mesh(top: float, bottom: float, h: float, seg: int = 12) -> CylinderMesh:
	var key := "cyl%s_%s_%s_%s" % [top, bottom, h, seg]
	if not _meshes.has(key):
		var c := CylinderMesh.new()
		c.top_radius = top
		c.bottom_radius = bottom
		c.height = h
		c.radial_segments = seg
		c.rings = 1
		_meshes[key] = c
	return _meshes[key]

func add_mesh(parent: Node3D, mesh: Mesh, material: Material, pos: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE, rot: Vector3 = Vector3.ZERO, shadow: bool = true) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = material
	mi.position = pos
	mi.scale = scl
	mi.rotation_degrees = rot
	if not shadow:
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi

func node_at(parent: Node3D, pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	parent.add_child(n)
	return n

func eyes(root: Node3D, y: float, z: float, spread: float, size: float, angry: bool = false) -> void:
	for s in [-1.0, 1.0]:
		add_mesh(root, sphere_mesh(size, size * 2.0, 10), mat(Color.WHITE, 0.0, false, false, 0.3), Vector3(s * spread, y, z), Vector3.ONE, Vector3.ZERO, false)
		add_mesh(root, sphere_mesh(size * 0.5, size, 8), mat(Color(0.02, 0.02, 0.05)), Vector3(s * spread, y, z - size * 0.75), Vector3.ONE, Vector3.ZERO, false)
		if angry:
			add_mesh(root, box_mesh(Vector3(size * 2.2, size * 0.45, size * 0.4)), mat(Color(0.05, 0.03, 0.03)), Vector3(s * spread, y + size * 1.1, z - size * 0.6), Vector3.ONE, Vector3(0, 0, 18.0 * s), false)

# ------------------------------------------------------------------ cenário
func make_prop(parent: Node3D, kind: String, pos: Vector3) -> Node3D:
	var r := node_at(parent, pos)
	match kind:
		"pine", "pine_dark":
			var dark := kind == "pine_dark"
			add_mesh(r, cyl_mesh(0.2, 0.32, 1.6, 8), mat(Color(0.42, 0.22, 0.12)), Vector3(0, 0.8, 0))
			var greens := [Color(0.05, 0.42, 0.24), Color(0.08, 0.52, 0.29), Color(0.12, 0.62, 0.34)]
			if dark:
				greens = [Color(0.06, 0.2, 0.3), Color(0.08, 0.26, 0.36), Color(0.1, 0.32, 0.42)]
			for j in range(3):
				add_mesh(r, cyl_mesh(0.0, 1.35 - j * 0.3, 1.5, 10), mat(greens[j]), Vector3(0, 1.8 + j * 0.85, 0))
			add_mesh(r, cyl_mesh(0.0, 0.5, 0.55, 10), mat(Color(0.96, 0.98, 1.0)), Vector3(0, 4.1, 0))
			r.scale = Vector3.ONE * randf_range(0.85, 1.35)
		"igloo":
			add_mesh(r, sphere_mesh(2.0, 2.0, 16), mat(Color(0.9, 0.95, 1.0)), Vector3(0, 0.0, 0), Vector3(1.0, 1.0, 1.0))
			add_mesh(r, cyl_mesh(0.7, 0.7, 1.4, 12), mat(Color(0.86, 0.92, 1.0)), Vector3(0, 0.5, -1.8), Vector3.ONE, Vector3(90, 0, 0))
			add_mesh(r, cyl_mesh(0.5, 0.5, 0.1, 12), mat(Color(0.1, 0.12, 0.25)), Vector3(0, 0.5, -2.5), Vector3.ONE, Vector3(90, 0, 0))
		"ice_rock":
			add_mesh(r, sphere_mesh(0.9, 1.3, 8), mat(Color(0.58, 0.78, 0.96), 0.0, false, false, 0.25), Vector3(0, 0.3, 0), Vector3(1.3, 0.8, 1.0), Vector3(0, randf() * 90, 0))
		"crystal", "crystal_cluster":
			var cols := [Color(0.3, 0.95, 1.0), Color(0.95, 0.35, 1.0), Color(0.5, 0.6, 1.0), Color(0.4, 1.0, 0.7)]
			var c: Color = cols[randi() % cols.size()]
			var count := 1 if kind == "crystal" else 4
			for i in range(count):
				var h := randf_range(1.5, 3.8)
				add_mesh(r, cyl_mesh(0.0, randf_range(0.3, 0.6), h, 6), mat(c, 1.6, false, false, 0.1), Vector3(randf_range(-0.8, 0.8) * (count - 1) * 0.4, h * 0.5, randf_range(-0.6, 0.6) * (count - 1) * 0.4), Vector3.ONE, Vector3(randf_range(-18, 18), 0, randf_range(-18, 18)), false)
			# estalactite no teto da caverna
			add_mesh(r, cyl_mesh(0.7, 0.0, 3.2, 7), mat(Color(0.2, 0.2, 0.35)), Vector3(randf_range(-1, 1), 8.0, randf_range(-1, 1)))
		"stalagmite_big":
			add_mesh(r, cyl_mesh(0.0, 1.1, 4.5, 7), mat(Color(0.3, 0.3, 0.48)), Vector3(0, 2.25, 0))
			add_mesh(r, cyl_mesh(0.9, 0.0, 4.0, 7), mat(Color(0.25, 0.25, 0.42)), Vector3(0, 8.0, 0))
		"iceberg":
			add_mesh(r, cyl_mesh(randf_range(0.6, 1.8), randf_range(2.5, 3.5), randf_range(3.0, 7.0), 6), mat(Color(0.93, 0.97, 1.0), 0.0, false, false, 0.3), Vector3(0, 1.0, 0), Vector3(1.0, 1.0, 0.8), Vector3(0, randf() * 60, randf_range(-6, 6)))
		"floe":
			add_mesh(r, cyl_mesh(1.4, 1.5, 0.35, 7), mat(Color(0.92, 0.97, 1.0)), Vector3(0, 0.0, 0), Vector3(randf_range(0.7, 1.4), 1, randf_range(0.7, 1.4)), Vector3(0, randf() * 60, 0))
			if randf() < 0.4:
				add_mesh(r, sphere_mesh(0.35, 0.7, 10), mat(Color(0.12, 0.12, 0.2)), Vector3(0, 0.5, 0), Vector3(1, 1.3, 1))
				add_mesh(r, sphere_mesh(0.26, 0.5, 10), mat(Color(0.98, 0.98, 1.0)), Vector3(0, 0.45, -0.18), Vector3(1, 1.2, 0.7))
		"jungle_tree":
			var h := randf_range(5.0, 8.0)
			add_mesh(r, cyl_mesh(0.28, 0.42, h, 8), mat(Color(0.45, 0.3, 0.15)), Vector3(0, h * 0.5, 0))
			for i in range(6):
				var a := i * TAU / 6.0
				add_mesh(r, sphere_mesh(1.4, 0.4, 10), mat(Color(0.12, 0.55 + randf() * 0.15, 0.18)), Vector3(cos(a) * 1.2, h, sin(a) * 1.2), Vector3(1.2, 1, 0.6), Vector3(0, -rad_to_deg(a), -25))
		"fern":
			for i in range(5):
				add_mesh(r, cyl_mesh(0.0, 0.35, 1.6, 6), mat(Color(0.2, 0.62, 0.22)), Vector3(0, 0.6, 0), Vector3.ONE, Vector3(randf_range(-40, 40), randf() * 360, randf_range(-40, 40)))
		"giant_mushroom":
			add_mesh(r, cyl_mesh(0.3, 0.45, 2.6, 10), mat(Color(0.95, 0.92, 0.82)), Vector3(0, 1.3, 0))
			add_mesh(r, sphere_mesh(1.6, 1.4, 14), mat(Color(0.9, 0.2, 0.2)), Vector3(0, 2.6, 0), Vector3(1, 0.7, 1))
			for i in range(5):
				add_mesh(r, sphere_mesh(0.22, 0.2, 8), mat(Color(1, 1, 1)), Vector3(randf_range(-0.9, 0.9), 3.05, randf_range(-0.9, 0.9)), Vector3.ONE, Vector3.ZERO, false)
		"ice_pillar":
			var h := randf_range(4.0, 7.5)
			add_mesh(r, cyl_mesh(0.5, 0.7, h, 6), mat(Color(0.6, 0.75, 1.0), 0.7, false, false, 0.15), Vector3(0, h * 0.5, 0))
			add_mesh(r, cyl_mesh(0.0, 0.6, 1.2, 6), mat(Color(0.85, 0.7, 1.0), 1.5, false, false, 0.1), Vector3(0, h + 0.6, 0), Vector3.ONE, Vector3.ZERO, false)
		"lamp_post":
			add_mesh(r, cyl_mesh(0.08, 0.12, 3.0, 8), mat(Color(0.15, 0.15, 0.25)), Vector3(0, 1.5, 0))
			add_mesh(r, sphere_mesh(0.3, 0.6, 10), mat(Color(0.6, 1.0, 0.9), 3.0), Vector3(0, 3.1, 0), Vector3.ONE, Vector3.ZERO, false)
		_:
			add_mesh(r, box_mesh(Vector3.ONE), mat(Color.MAGENTA), Vector3(0, 0.5, 0))
	return r

func make_far_scenery(parent: Node3D, theme: String) -> void:
	# Montanhas/ilhas distantes; o nó "far" acompanha o Pipo no eixo Z.
	var t: Dictionary = THEMES[theme]
	var c: Color = t["bank"].darkened(0.1)
	for i in range(14):
		var side := -1.0 if i % 2 == 0 else 1.0
		var x := side * randf_range(28.0, 70.0)
		var z := randf_range(30.0, 140.0)
		var h := randf_range(10.0, 26.0)
		match theme:
			"forest":
				add_mesh(parent, cyl_mesh(0.0, h * 0.8, h, 8), mat(Color(0.22, 0.4, 0.25)), Vector3(x, h * 0.5 - 1.0, z), Vector3.ONE, Vector3.ZERO, false)
			"cave":
				add_mesh(parent, cyl_mesh(h * 0.15, h * 0.5, h * 1.5, 7), mat(Color(0.1, 0.08, 0.18)), Vector3(x * 0.5, h * 0.3, z), Vector3.ONE, Vector3.ZERO, false)
			"sea":
				add_mesh(parent, cyl_mesh(h * 0.3, h * 0.6, h * 0.6, 6), mat(Color(0.94, 0.97, 1.0)), Vector3(x, h * 0.2, z), Vector3.ONE, Vector3.ZERO, false)
			_:
				add_mesh(parent, cyl_mesh(0.0, h * 0.9, h, 8), mat(c), Vector3(x, h * 0.5 - 1.0, z), Vector3.ONE, Vector3.ZERO, false)
				add_mesh(parent, cyl_mesh(0.0, h * 0.3, h * 0.34, 8), mat(Color(0.97, 0.98, 1.0)), Vector3(x, h - 1.0 - h * 0.16, z), Vector3.ONE, Vector3.ZERO, false)
	if theme == "forest":
		# vulcão ao fundo
		add_mesh(parent, cyl_mesh(6.0, 30.0, 34.0, 10), mat(Color(0.35, 0.25, 0.22)), Vector3(-30, 14, 170), Vector3.ONE, Vector3.ZERO, false)
		add_mesh(parent, cyl_mesh(5.5, 5.5, 0.6, 10), mat(Color(1.0, 0.4, 0.1), 3.0), Vector3(-30, 31.2, 170), Vector3.ONE, Vector3.ZERO, false)
	if theme == "aurora":
		# auroras boreais (faixas emissivas) + estrelas
		var cols := [Color(0.2, 1.0, 0.6, 0.35), Color(0.4, 0.6, 1.0, 0.3), Color(0.9, 0.4, 1.0, 0.28)]
		for i in range(5):
			var pm := PlaneMesh.new()
			pm.size = Vector2(120, 16)
			pm.orientation = PlaneMesh.FACE_Z
			add_mesh(parent, pm, mat(cols[i % 3], 2.0, true, true), Vector3(randf_range(-50, 50), 26 + i * 4, 95 + i * 6), Vector3.ONE, Vector3(0, randf_range(-25, 25), randf_range(-12, 12)), false)
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = sphere_mesh(0.25, 0.5, 4)
		mm.instance_count = 160
		for i in range(160):
			var p := Vector3(randf_range(-160, 160), randf_range(25, 90), randf_range(80, 220))
			mm.set_instance_transform(i, Transform3D(Basis.IDENTITY.scaled(Vector3.ONE * randf_range(0.6, 1.6)), p))
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.material_override = mat(Color(1, 1, 0.95), 3.0, false, true)
		mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(mmi)

func make_castle(parent: Node3D, pos: Vector3) -> Node3D:
	var r := node_at(parent, pos)
	var wall := mat(Color(0.55, 0.6, 0.9), 0.2, false, false, 0.2)
	var roof := mat(Color(0.7, 0.35, 0.95), 0.6)
	add_mesh(r, box_mesh(Vector3(26, 10, 6)), wall, Vector3(0, 5, 0))
	for x in [-13.0, -6.0, 6.0, 13.0]:
		add_mesh(r, cyl_mesh(2.0, 2.2, 16, 10), wall, Vector3(x, 8, 0))
		add_mesh(r, cyl_mesh(0.0, 2.8, 5, 10), roof, Vector3(x, 18.5, 0))
	add_mesh(r, cyl_mesh(3.0, 3.2, 24, 12), wall, Vector3(0, 12, 2))
	add_mesh(r, cyl_mesh(0.0, 4.0, 8, 12), roof, Vector3(0, 28, 2))
	add_mesh(r, box_mesh(Vector3(5, 7, 1)), mat(Color(0.08, 0.05, 0.2)), Vector3(0, 3.5, -3.1))
	return r

# ------------------------------------------------------------------ pista
func make_ground(parent: Node3D, theme: String, length: float) -> void:
	var t: Dictionary = THEMES[theme]
	var mid := length * 0.5 - 30.0
	var road_len := length + 80.0
	add_mesh(parent, box_mesh(Vector3(9.4, 0.5, road_len)), mat(t["road"], 0.0, false, false, 0.95), Vector3(0, -0.25, mid))
	# faixas sutis marcando as pistas
	for x in [-1.125, 1.125]:
		add_mesh(parent, box_mesh(Vector3(0.1, 0.02, road_len)), mat(t["road"].lightened(0.45)), Vector3(x, 0.005, mid), Vector3.ONE, Vector3.ZERO, false)
	if theme == "sea":
		var water := add_mesh(parent, box_mesh(Vector3(400, 0.4, road_len + 300)), mat(t["side"], 0.0, false, false, 0.08), Vector3(0, -0.75, mid), Vector3.ONE, Vector3.ZERO, false)
		water.name = "Water"
	else:
		for s in [-1.0, 1.0]:
			add_mesh(parent, box_mesh(Vector3(0.8, 0.5, road_len)), mat(t["bank"]), Vector3(s * 5.1, 0.1, mid), Vector3.ONE, Vector3.ZERO, false)
		add_mesh(parent, box_mesh(Vector3(400, 0.5, road_len + 300)), mat(t["side"]), Vector3(0, -0.4, mid), Vector3.ONE, Vector3.ZERO, false)
	if theme == "cave":
		add_mesh(parent, box_mesh(Vector3(80, 1.0, road_len + 100)), mat(Color(0.08, 0.06, 0.14)), Vector3(0, 10.5, mid), Vector3.ONE, Vector3.ZERO, false)

func make_finish(parent: Node3D, z: float) -> Node3D:
	var r := node_at(parent, Vector3(0, 0, z))
	var post := mat(Color(0.95, 0.2, 0.2))
	for s in [-1.0, 1.0]:
		add_mesh(r, cyl_mesh(0.25, 0.3, 5.0, 10), post, Vector3(s * 4.6, 2.5, 0))
		add_mesh(r, sphere_mesh(0.45, 0.9, 12), mat(Color(1, 0.85, 0.2), 1.0), Vector3(s * 4.6, 5.2, 0))
	# faixa quadriculada
	var img := Image.create(16, 2, false, Image.FORMAT_RGB8)
	for x in range(16):
		for y in range(2):
			img.set_pixel(x, y, Color.WHITE if (x + y) % 2 == 0 else Color(0.05, 0.05, 0.1))
	var tex := ImageTexture.create_from_image(img)
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	add_mesh(r, box_mesh(Vector3(9.2, 1.0, 0.2)), m, Vector3(0, 4.4, 0))
	var floor_m := StandardMaterial3D.new()
	floor_m.albedo_texture = tex
	floor_m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	floor_m.uv1_scale = Vector3(1, 0.5, 1)
	add_mesh(r, box_mesh(Vector3(9.2, 0.02, 1.0)), floor_m, Vector3(0, 0.01, 0), Vector3.ONE, Vector3.ZERO, false)
	return r

# ------------------------------------------------------------------ itens
# ------------------------------------------------------------------ peixinho (modelo do usuário)
var fish_mesh: Mesh
var fish_mat: StandardMaterial3D
var gold_mat: ShaderMaterial

func _init() -> void:
	var m = load("res://assets/peixinho.obj")
	if m is Mesh:
		fish_mesh = m
		fish_mat = StandardMaterial3D.new()
		fish_mat.vertex_color_use_as_albedo = true
		fish_mat.roughness = 0.35
		var sh := Shader.new()
		sh.code = """
shader_type spatial;
render_mode cull_back;
// Peixe dourado: pinta o peixinho de ouro mantendo olhos e detalhes escuros.
void fragment() {
	float l = dot(COLOR.rgb, vec3(0.3, 0.59, 0.11));
	vec3 g = mix(vec3(0.3, 0.15, 0.0), vec3(1.0, 0.86, 0.3), smoothstep(0.05, 0.7, l));
	ALBEDO = g;
	METALLIC = 0.55;
	ROUGHNESS = 0.25;
	EMISSION = g * 0.45 * step(0.15, l);
}
"""
		gold_mat = ShaderMaterial.new()
		gold_mat.shader = sh

func make_fish(parent: Node3D, pos: Vector3, golden: bool = false) -> Node3D:
	var r := node_at(parent, pos)
	if fish_mesh:
		# o modelo olha para +Z; giramos 180° para o rostinho ficar virado para o Pipo
		var mi := add_mesh(r, fish_mesh, gold_mat if golden else fish_mat, Vector3(0, -0.3, 0), Vector3.ONE * 0.8, Vector3(0, 180, 0), false)
		mi.name = "Model"
		if golden:
			r.scale = Vector3.ONE * 1.35
		return r
	var body_c := Color(1.0, 0.8, 0.15) if golden else Color(0.05, 0.72, 1.0)
	var tail_c := Color(1.0, 0.55, 0.05) if golden else Color(0.0, 0.48, 0.9)
	var em := 1.2 if golden else 0.25
	add_mesh(r, sphere_mesh(0.28, 0.45, 12), mat(body_c, em, false, false, 0.3), Vector3.ZERO, Vector3(1.3, 0.75, 0.65), Vector3.ZERO, false)
	add_mesh(r, cyl_mesh(0.0, 0.2, 0.3, 6), mat(tail_c, em), Vector3(-0.42, 0, 0), Vector3(1, 1, 0.4), Vector3(0, 0, 90), false)
	add_mesh(r, sphere_mesh(0.05, 0.1, 6), mat(Color(0.02, 0.02, 0.05)), Vector3(0.2, 0.06, 0.15), Vector3.ONE, Vector3.ZERO, false)
	if golden:
		r.scale = Vector3.ONE * 1.4
	return r

func make_powerup(parent: Node3D, pos: Vector3, ptype: String) -> Node3D:
	var r := node_at(parent, pos)
	var ring_c := {"propeller": Color(1.0, 0.6, 0.1), "clock": Color(0.3, 1.0, 0.5), "magnet": Color(1.0, 0.25, 0.3), "star": Color(1.0, 0.95, 0.2)}
	var c: Color = ring_c.get(ptype, Color.WHITE)
	add_mesh(r, sphere_mesh(0.55, 1.1, 16), mat(Color(c.r, c.g, c.b, 0.28), 0.6, true, false, 0.1), Vector3.ZERO, Vector3.ONE, Vector3.ZERO, false)
	match ptype:
		"propeller":
			add_mesh(r, sphere_mesh(0.22, 0.25, 10), mat(Color(0.2, 0.5, 1.0)), Vector3(0, -0.05, 0), Vector3.ONE, Vector3.ZERO, false)
			add_mesh(r, box_mesh(Vector3(0.75, 0.04, 0.12)), mat(Color(1, 0.3, 0.2), 0.5), Vector3(0, 0.12, 0), Vector3.ONE, Vector3.ZERO, false).name = "Blade"
		"clock":
			add_mesh(r, cyl_mesh(0.3, 0.3, 0.1, 16), mat(Color(1, 1, 1)), Vector3.ZERO, Vector3.ONE, Vector3(90, 0, 0), false)
			add_mesh(r, box_mesh(Vector3(0.04, 0.2, 0.04)), mat(Color(0.1, 0.1, 0.1)), Vector3(0, 0.08, -0.07), Vector3.ONE, Vector3.ZERO, false)
			add_mesh(r, box_mesh(Vector3(0.15, 0.04, 0.04)), mat(Color(0.1, 0.1, 0.1)), Vector3(0.06, 0, -0.07), Vector3.ONE, Vector3.ZERO, false)
		"magnet":
			add_mesh(r, box_mesh(Vector3(0.12, 0.4, 0.12)), mat(Color(0.9, 0.15, 0.15)), Vector3(-0.15, 0, 0), Vector3.ONE, Vector3.ZERO, false)
			add_mesh(r, box_mesh(Vector3(0.12, 0.4, 0.12)), mat(Color(0.9, 0.15, 0.15)), Vector3(0.15, 0, 0), Vector3.ONE, Vector3.ZERO, false)
			add_mesh(r, box_mesh(Vector3(0.42, 0.12, 0.12)), mat(Color(0.9, 0.15, 0.15)), Vector3(0, 0.2, 0), Vector3.ONE, Vector3.ZERO, false)
			add_mesh(r, box_mesh(Vector3(0.13, 0.1, 0.13)), mat(Color(0.9, 0.9, 0.95)), Vector3(-0.15, -0.22, 0), Vector3.ONE, Vector3.ZERO, false)
			add_mesh(r, box_mesh(Vector3(0.13, 0.1, 0.13)), mat(Color(0.9, 0.9, 0.95)), Vector3(0.15, -0.22, 0), Vector3.ONE, Vector3.ZERO, false)
		"star":
			for i in range(5):
				add_mesh(r, cyl_mesh(0.0, 0.11, 0.38, 4), mat(Color(1, 0.9, 0.1), 1.5), Vector3(cos(i * TAU / 5.0 + PI / 2) * 0.17, sin(i * TAU / 5.0 + PI / 2) * 0.17, 0), Vector3.ONE, Vector3(0, 0, rad_to_deg(i * TAU / 5.0)), false)
			add_mesh(r, sphere_mesh(0.14, 0.28, 8), mat(Color(1, 0.9, 0.1), 1.5), Vector3.ZERO, Vector3.ONE, Vector3.ZERO, false)
	return r

# ------------------------------------------------------------------ perigos
func make_block(parent: Node3D, pos: Vector3, kind: String) -> Node3D:
	var r := node_at(parent, pos)
	match kind:
		"ice_block":
			add_mesh(r, box_mesh(Vector3(1.3, 1.0, 1.0)), mat(Color(0.55, 0.82, 1.0, 0.92), 0.15, true, false, 0.1), Vector3(0, 0.5, 0))
			add_mesh(r, box_mesh(Vector3(1.32, 0.12, 1.02)), mat(Color(0.97, 0.99, 1.0)), Vector3(0, 1.02, 0), Vector3.ONE, Vector3.ZERO, false)
		"snowman":
			add_mesh(r, sphere_mesh(0.6, 1.2, 14), mat(Color(0.97, 0.98, 1.0)), Vector3(0, 0.5, 0))
			add_mesh(r, sphere_mesh(0.42, 0.84, 14), mat(Color(0.97, 0.98, 1.0)), Vector3(0, 1.25, 0))
			add_mesh(r, cyl_mesh(0.0, 0.07, 0.35, 6), mat(Color(1, 0.5, 0.1)), Vector3(0, 1.28, -0.5), Vector3.ONE, Vector3(-90, 0, 0), false)
			add_mesh(r, cyl_mesh(0.28, 0.3, 0.4, 10), mat(Color(0.1, 0.1, 0.15)), Vector3(0, 1.75, 0), Vector3.ONE, Vector3.ZERO, false)
			eyes(r, 1.38, -0.35, 0.14, 0.06)
		"stalagmite":
			add_mesh(r, cyl_mesh(0.0, 0.62, 1.5, 7), mat(Color(0.45, 0.42, 0.62)), Vector3(0, 0.75, 0))
			add_mesh(r, cyl_mesh(0.0, 0.3, 0.8, 6), mat(Color(0.4, 0.95, 1.0), 1.2), Vector3(0.35, 0.4, -0.1), Vector3.ONE, Vector3(0, 0, -20), false)
		"rock":
			add_mesh(r, sphere_mesh(0.7, 1.1, 8), mat(Color(0.48, 0.44, 0.4)), Vector3(0, 0.45, 0), Vector3(1.0, 0.9, 0.9), Vector3(0, randf() * 90, 0))
			add_mesh(r, sphere_mesh(0.3, 0.3, 8), mat(Color(0.3, 0.6, 0.25)), Vector3(0.1, 0.85, 0), Vector3(1.6, 0.6, 1.4), Vector3.ZERO, false)
		"ice_pillar_small":
			add_mesh(r, cyl_mesh(0.45, 0.55, 1.4, 6), mat(Color(0.6, 0.75, 1.0), 0.8, false, false, 0.15), Vector3(0, 0.7, 0))
			add_mesh(r, cyl_mesh(0.0, 0.5, 0.6, 6), mat(Color(0.85, 0.7, 1.0), 1.5), Vector3(0, 1.7, 0), Vector3.ONE, Vector3.ZERO, false)
		"log":
			add_mesh(r, cyl_mesh(0.38, 0.38, 9.0, 12), mat(Color(0.48, 0.32, 0.18)), Vector3(0, 0.38, 0), Vector3.ONE, Vector3(0, 0, 90))
			for s in [-1.0, 1.0]:
				add_mesh(r, cyl_mesh(0.3, 0.3, 0.02, 12), mat(Color(0.8, 0.65, 0.4)), Vector3(s * 4.51, 0.38, 0), Vector3.ONE, Vector3(0, 0, 90), false)
		_:
			add_mesh(r, box_mesh(Vector3(1.2, 1.0, 1.0)), mat(Color(0.45, 0.76, 0.98)), Vector3(0, 0.5, 0))
	return r

func make_hole(parent: Node3D, pos: Vector3, radius_x: float, radius_z: float, color: Color, glow: bool = false) -> Node3D:
	var r := node_at(parent, pos)
	var c := color
	add_mesh(r, cyl_mesh(1.0, 1.0, 0.02, 20), mat(c.lightened(0.55)), Vector3(0, 0.006, 0), Vector3(radius_x + 0.14, 1, radius_z + 0.14), Vector3.ZERO, false)
	add_mesh(r, cyl_mesh(1.0, 1.0, 0.02, 20), mat(c, 2.2 if glow else 0.0, false, glow), Vector3(0, 0.012, 0), Vector3(radius_x, 1, radius_z), Vector3.ZERO, false)
	return r

func make_gap(parent: Node3D, pos: Vector3, depth_z: float, color: Color, sea: bool) -> Node3D:
	var r := node_at(parent, pos)
	add_mesh(r, box_mesh(Vector3(9.6, 0.03, depth_z)), mat(color, 0.0, false, false, 0.1 if sea else 0.9), Vector3(0, 0.012, 0), Vector3.ONE, Vector3.ZERO, false)
	# bordas
	for s in [-1.0, 1.0]:
		add_mesh(r, box_mesh(Vector3(9.6, 0.05, 0.18)), mat(Color(0.97, 0.99, 1.0) if sea else color.lightened(0.5)), Vector3(0, 0.02, s * depth_z * 0.5), Vector3.ONE, Vector3.ZERO, false)
	return r

func make_seal(parent: Node3D, pos: Vector3, hole_color: Color) -> Dictionary:
	var r := make_hole(parent, pos, 0.75, 0.6, hole_color)
	var seal := node_at(r, Vector3(0, -1.2, 0))
	add_mesh(seal, sphere_mesh(0.5, 1.4, 14), mat(Color(0.55, 0.6, 0.7)), Vector3(0, 0.6, 0), Vector3(1, 1, 0.85))
	add_mesh(seal, sphere_mesh(0.36, 0.6, 12), mat(Color(0.82, 0.84, 0.9)), Vector3(0, 0.7, -0.3), Vector3(1, 1, 0.6), Vector3.ZERO, false)
	add_mesh(seal, sphere_mesh(0.07, 0.14, 8), mat(Color(0.05, 0.05, 0.08)), Vector3(0, 0.82, -0.52), Vector3.ONE, Vector3.ZERO, false)
	eyes(seal, 1.05, -0.4, 0.17, 0.08)
	return {"root": r, "seal": seal}

func make_bat(parent: Node3D, pos: Vector3, big: float = 1.0) -> Node3D:
	var r := node_at(parent, pos)
	var c := Color(0.3, 0.15, 0.45)
	add_mesh(r, sphere_mesh(0.35, 0.6, 12), mat(c), Vector3.ZERO)
	for s in [-1.0, 1.0]:
		var w := add_mesh(r, box_mesh(Vector3(0.9, 0.05, 0.5)), mat(c.lightened(0.15)), Vector3(s * 0.6, 0.05, 0), Vector3.ONE, Vector3(0, 0, -15 * s))
		w.name = "WingL" if s < 0 else "WingR"
		add_mesh(r, cyl_mesh(0.0, 0.1, 0.25, 4), mat(c), Vector3(s * 0.18, 0.35, 0), Vector3.ONE, Vector3.ZERO, false)
	add_mesh(r, sphere_mesh(0.08, 0.16, 8), mat(Color(1, 0.9, 0.2), 2.0), Vector3(-0.12, 0.08, -0.3), Vector3.ONE, Vector3.ZERO, false)
	add_mesh(r, sphere_mesh(0.08, 0.16, 8), mat(Color(1, 0.9, 0.2), 2.0), Vector3(0.12, 0.08, -0.3), Vector3.ONE, Vector3.ZERO, false)
	r.scale = Vector3.ONE * big
	return r

func make_bird(parent: Node3D, pos: Vector3) -> Node3D:
	var r := node_at(parent, pos)
	add_mesh(r, sphere_mesh(0.3, 0.6, 12), mat(Color(0.97, 0.97, 1.0)), Vector3.ZERO, Vector3(1, 0.9, 1.5))
	add_mesh(r, cyl_mesh(0.0, 0.08, 0.3, 6), mat(Color(1, 0.75, 0.1)), Vector3(0, 0, -0.55), Vector3.ONE, Vector3(-90, 0, 0), false)
	for s in [-1.0, 1.0]:
		var w := add_mesh(r, box_mesh(Vector3(1.0, 0.04, 0.35)), mat(Color(0.75, 0.78, 0.85)), Vector3(s * 0.6, 0.05, 0))
		w.name = "WingL" if s < 0 else "WingR"
	eyes(r, 0.12, -0.3, 0.13, 0.05)
	return r

func make_dino(parent: Node3D, pos: Vector3) -> Node3D:
	var r := node_at(parent, pos)
	var c := Color(0.35, 0.7, 0.3)
	add_mesh(r, sphere_mesh(0.55, 1.0, 14), mat(c), Vector3(0, 0.75, 0), Vector3(0.9, 0.9, 1.3))
	add_mesh(r, sphere_mesh(0.35, 0.6, 12), mat(c), Vector3(0, 1.35, -0.5))
	add_mesh(r, cyl_mesh(0.05, 0.3, 0.9, 8), mat(c), Vector3(0, 0.75, 0.85), Vector3.ONE, Vector3(70, 0, 0))
	for s in [-1.0, 1.0]:
		add_mesh(r, cyl_mesh(0.13, 0.16, 0.5, 8), mat(c.darkened(0.2)), Vector3(s * 0.28, 0.25, 0))
	for i in range(4):
		add_mesh(r, cyl_mesh(0.0, 0.12, 0.25, 4), mat(Color(1, 0.6, 0.2)), Vector3(0, 1.22 - i * 0.05, -0.1 + i * 0.25), Vector3.ONE, Vector3.ZERO, false)
	eyes(r, 1.48, -0.75, 0.15, 0.07)
	return r

func make_ghost(parent: Node3D, pos: Vector3) -> Node3D:
	var r := node_at(parent, pos)
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.85, 0.9, 1.0, 0.8)
	m.emission_enabled = true
	m.emission = Color(0.5, 0.6, 1.0)
	m.emission_energy_multiplier = 0.8
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	var body := add_mesh(r, sphere_mesh(0.55, 1.6, 14), m, Vector3(0, 1.0, 0), Vector3(1, 1, 0.9), Vector3.ZERO, false)
	body.name = "Body"
	add_mesh(r, sphere_mesh(0.1, 0.22, 8), mat(Color(0.05, 0.02, 0.15)), Vector3(-0.17, 1.25, -0.46), Vector3.ONE, Vector3.ZERO, false)
	add_mesh(r, sphere_mesh(0.1, 0.22, 8), mat(Color(0.05, 0.02, 0.15)), Vector3(0.17, 1.25, -0.46), Vector3.ONE, Vector3.ZERO, false)
	add_mesh(r, sphere_mesh(0.12, 0.12, 8), mat(Color(0.05, 0.02, 0.15)), Vector3(0, 0.95, -0.5), Vector3.ONE, Vector3.ZERO, false)
	return r

func make_stalactite(parent: Node3D, pos: Vector3) -> Dictionary:
	var r := node_at(parent, pos)
	var shadow := add_mesh(r, cyl_mesh(0.6, 0.6, 0.02, 14), mat(Color(0, 0, 0, 0.45), 0.0, true, true), Vector3(0, 0.02, 0), Vector3.ONE, Vector3.ZERO, false)
	var rock := node_at(r, Vector3(0, 8.5, 0))
	add_mesh(rock, cyl_mesh(0.55, 0.0, 1.8, 7), mat(Color(0.5, 0.48, 0.7)), Vector3(0, 0.9, 0))
	add_mesh(rock, cyl_mesh(0.25, 0.0, 0.9, 6), mat(Color(0.4, 0.95, 1.0), 1.5), Vector3(0.2, 0.6, 0), Vector3.ONE, Vector3.ZERO, false)
	return {"root": r, "rock": rock, "shadow": shadow}

func make_bounce(parent: Node3D, pos: Vector3) -> Node3D:
	var r := node_at(parent, pos)
	add_mesh(r, cyl_mesh(0.25, 0.32, 0.4, 10), mat(Color(0.98, 0.95, 0.85)), Vector3(0, 0.2, 0))
	add_mesh(r, sphere_mesh(0.8, 0.8, 14), mat(Color(0.95, 0.35, 0.85), 0.4), Vector3(0, 0.45, 0), Vector3(1, 0.55, 1))
	for i in range(4):
		add_mesh(r, sphere_mesh(0.12, 0.1, 6), mat(Color.WHITE), Vector3(cos(i * 1.6) * 0.45, 0.62, sin(i * 1.6) * 0.45), Vector3.ONE, Vector3.ZERO, false)
	return r

# ------------------------------------------------------------------ chefes
func make_boss(parent: Node3D, kind: String) -> Node3D:
	var r := Node3D.new()
	parent.add_child(r)
	var body := Node3D.new()
	body.name = "Body"
	r.add_child(body)
	match kind:
		"walrus":
			var c := Color(0.62, 0.42, 0.3)
			add_mesh(body, sphere_mesh(1.8, 3.4, 20), mat(c), Vector3(0, 1.7, 0), Vector3(1.15, 1, 1))
			add_mesh(body, sphere_mesh(1.1, 1.8, 16), mat(c.lightened(0.08)), Vector3(0, 3.3, -0.6))
			for s in [-1.0, 1.0]:
				add_mesh(body, sphere_mesh(0.5, 0.9, 12), mat(c.lightened(0.25)), Vector3(s * 0.42, 2.85, -1.45))
				add_mesh(body, cyl_mesh(0.02, 0.17, 1.4, 8), mat(Color(1, 0.98, 0.9)), Vector3(s * 0.45, 2.05, -1.65), Vector3.ONE, Vector3(-10, 0, 0))
				add_mesh(body, sphere_mesh(0.55, 0.5, 10), mat(c.darkened(0.15)), Vector3(s * 1.9, 0.6, -0.6), Vector3(1.4, 1, 1.8))
			add_mesh(body, cyl_mesh(0.5, 0.65, 0.7, 12), mat(Color(0.9, 0.15, 0.2)), Vector3(0, 4.3, -0.5))
			add_mesh(body, sphere_mesh(0.15, 0.3, 8), mat(Color(1, 1, 1)), Vector3(0, 4.75, -0.5))
			eyes(body, 3.75, -1.3, 0.42, 0.17, true)
		"bat":
			var c := Color(0.32, 0.12, 0.45)
			add_mesh(body, sphere_mesh(1.3, 2.4, 18), mat(c), Vector3(0, 0, 0))
			for s in [-1.0, 1.0]:
				var w := node_at(body, Vector3(s * 1.1, 0.2, 0))
				w.name = "WingL" if s < 0 else "WingR"
				add_mesh(w, box_mesh(Vector3(3.2, 0.12, 1.8)), mat(c.lightened(0.12)), Vector3(s * 1.6, 0, 0), Vector3.ONE, Vector3(0, 0, -10 * s))
				add_mesh(body, cyl_mesh(0.0, 0.35, 0.9, 4), mat(c), Vector3(s * 0.65, 1.3, 0), Vector3.ONE, Vector3(0, 0, -15 * s))
				add_mesh(body, cyl_mesh(0.0, 0.08, 0.35, 4), mat(Color(1, 1, 1)), Vector3(s * 0.25, -0.55, -1.15), Vector3.ONE, Vector3(180, 0, 0), false)
			add_mesh(body, sphere_mesh(0.3, 0.6, 10), mat(Color(1, 0.85, 0.1), 2.5), Vector3(-0.45, 0.35, -1.05))
			add_mesh(body, sphere_mesh(0.3, 0.6, 10), mat(Color(1, 0.85, 0.1), 2.5), Vector3(0.45, 0.35, -1.05))
			add_mesh(body, sphere_mesh(0.13, 0.3, 8), mat(Color(0.8, 0, 0)), Vector3(-0.45, 0.35, -1.3), Vector3.ONE, Vector3.ZERO, false)
			add_mesh(body, sphere_mesh(0.13, 0.3, 8), mat(Color(0.8, 0, 0)), Vector3(0.45, 0.35, -1.3), Vector3.ONE, Vector3.ZERO, false)
			body.position.y = 3.0
		"octopus":
			var c := Color(0.85, 0.3, 0.5)
			add_mesh(body, sphere_mesh(1.7, 3.6, 20), mat(c), Vector3(0, 2.6, 0.2), Vector3(1, 1.1, 1))
			for i in range(8):
				var a := i * TAU / 8.0
				var t := node_at(body, Vector3(cos(a) * 1.3, 0.6, sin(a) * 1.0))
				t.name = "Tentacle%d" % i
				for k in range(4):
					add_mesh(t, sphere_mesh(0.42 - k * 0.07, 0.8 - k * 0.12, 10), mat(c.darkened(0.05 * k)), Vector3(cos(a) * k * 0.45, -k * 0.12, sin(a) * k * 0.35))
			eyes(body, 2.4, -1.55, 0.6, 0.32, true)
			add_mesh(body, cyl_mesh(0.18, 0.25, 0.4, 10), mat(c.darkened(0.3)), Vector3(0, 1.6, -1.6), Vector3.ONE, Vector3(90, 0, 0), false)
		"dino":
			var c := Color(0.3, 0.62, 0.3)
			add_mesh(body, sphere_mesh(1.6, 3.0, 18), mat(c), Vector3(0, 2.2, 0.4), Vector3(1, 1.1, 1.3))
			add_mesh(body, sphere_mesh(1.05, 1.8, 16), mat(c), Vector3(0, 4.1, -1.0), Vector3(1, 0.9, 1.25))
			add_mesh(body, box_mesh(Vector3(1.5, 0.35, 1.3)), mat(c.darkened(0.15)), Vector3(0, 3.55, -1.9))
			for i in range(5):
				add_mesh(body, cyl_mesh(0.0, 0.08, 0.25, 4), mat(Color(1, 1, 1)), Vector3(-0.55 + i * 0.27, 3.72, -2.5), Vector3.ONE, Vector3(180, 0, 0), false)
			for i in range(7):
				add_mesh(body, cyl_mesh(0.0, 0.35, 0.7, 4), mat(Color(1, 0.55, 0.15)), Vector3(0, 4.6 - i * 0.35, -0.6 + i * 0.5), Vector3.ONE, Vector3.ZERO, false)
			for s in [-1.0, 1.0]:
				add_mesh(body, cyl_mesh(0.4, 0.5, 1.6, 10), mat(c.darkened(0.15)), Vector3(s * 0.9, 0.8, 0.4))
				add_mesh(body, cyl_mesh(0.1, 0.12, 0.7, 8), mat(c), Vector3(s * 0.85, 2.6, -1.2), Vector3.ONE, Vector3(60, 0, 0))
			eyes(body, 4.55, -1.85, 0.5, 0.2, true)
		"shadow":
			var c := Color(0.12, 0.08, 0.25)
			add_mesh(body, sphere_mesh(1.5, 3.4, 20), mat(c, 0.3), Vector3(0, 2.0, 0), Vector3(1, 1.1, 1))
			add_mesh(body, sphere_mesh(1.0, 2.0, 16), mat(c, 0.3), Vector3(0, 4.0, 0))
			add_mesh(body, sphere_mesh(0.95, 2.4, 14), mat(Color(0.35, 0.25, 0.55)), Vector3(0, 1.9, -0.75), Vector3(0.9, 0.9, 0.5))
			add_mesh(body, cyl_mesh(0.0, 0.3, 0.6, 6), mat(Color(1, 0.6, 0.1)), Vector3(0, 3.8, -1.05), Vector3.ONE, Vector3(-90, 0, 0), false)
			for s in [-1.0, 1.0]:
				var w := node_at(body, Vector3(s * 1.45, 2.4, 0))
				w.name = "WingL" if s < 0 else "WingR"
				add_mesh(w, sphere_mesh(0.4, 2.2, 10), mat(c.lightened(0.1), 0.3), Vector3(s * 0.2, -0.6, 0), Vector3.ONE, Vector3(0, 0, 20 * s))
			add_mesh(body, sphere_mesh(0.2, 0.4, 10), mat(Color(1, 0.1, 0.25), 3.0), Vector3(-0.35, 4.25, -0.85), Vector3.ONE, Vector3.ZERO, false)
			add_mesh(body, sphere_mesh(0.2, 0.4, 10), mat(Color(1, 0.1, 0.25), 3.0), Vector3(0.35, 4.25, -0.85), Vector3.ONE, Vector3.ZERO, false)
			# coroa sombria
			for i in range(5):
				add_mesh(body, cyl_mesh(0.0, 0.18, 0.6, 4), mat(Color(0.6, 0.3, 1.0), 2.0), Vector3(cos(i * TAU / 5.0) * 0.6, 5.1, sin(i * TAU / 5.0) * 0.6), Vector3.ONE, Vector3.ZERO, false)
	return r

func make_projectile(parent: Node3D, pos: Vector3, kind: String) -> Node3D:
	if kind == "log":
		return make_block(parent, pos, "log")
	if kind == "fish_shot":
		return make_fish(parent, pos, true)
	var r := node_at(parent, pos)
	match kind:
		"snowball":
			add_mesh(r, sphere_mesh(0.45, 0.9, 12), mat(Color(0.98, 0.99, 1.0)), Vector3(0, 0.45, 0))
		"bigball":
			add_mesh(r, sphere_mesh(1.0, 2.0, 16), mat(Color(0.95, 0.97, 1.0)), Vector3(0, 1.0, 0))
		"rock":
			add_mesh(r, sphere_mesh(0.5, 0.9, 7), mat(Color(0.45, 0.4, 0.5)), Vector3(0, 0.45, 0))
		"ink":
			add_mesh(r, sphere_mesh(0.5, 1.0, 12), mat(Color(0.12, 0.05, 0.2), 0.0, false, false, 0.1), Vector3(0, 0.5, 0))
		"tentacle":
			for i in range(5):
				add_mesh(r, sphere_mesh(0.45, 0.9, 10), mat(Color(0.85, 0.3, 0.5)), Vector3(-1.1 + i * 0.55, 0.6 + sin(i) * 0.3, 0))
				add_mesh(r, sphere_mesh(0.4, 0.8, 10), mat(Color(0.85, 0.3, 0.5)), Vector3(-1.1 + i * 0.55, 1.3 + cos(i) * 0.2, 0))
		"fireball":
			add_mesh(r, sphere_mesh(0.5, 1.0, 12), mat(Color(1, 0.45, 0.1), 3.0), Vector3(0, 0.5, 0), Vector3.ONE, Vector3.ZERO, false)
			add_mesh(r, sphere_mesh(0.3, 0.6, 10), mat(Color(1, 0.9, 0.3), 3.0), Vector3(0, 0.5, -0.25), Vector3.ONE, Vector3.ZERO, false)
		"shadowball":
			add_mesh(r, sphere_mesh(0.55, 1.1, 12), mat(Color(0.5, 0.1, 0.9), 2.0), Vector3(0, 0.55, 0), Vector3.ONE, Vector3.ZERO, false)
		"wave":
			add_mesh(r, box_mesh(Vector3(9.4, 0.6, 0.5)), mat(Color(0.45, 0.15, 0.85, 0.8), 1.6, true), Vector3(0, 0.3, 0), Vector3.ONE, Vector3.ZERO, false)
	return r

# ------------------------------------------------------------------ final
func make_golden_apple(parent: Node3D, pos: Vector3) -> Node3D:
	var r := node_at(parent, pos)
	var gold := StandardMaterial3D.new()
	gold.albedo_color = Color(1.0, 0.8, 0.2)
	gold.metallic = 0.9
	gold.roughness = 0.2
	gold.emission_enabled = true
	gold.emission = Color(1.0, 0.7, 0.1)
	gold.emission_energy_multiplier = 0.9
	add_mesh(r, sphere_mesh(0.45, 0.85, 20), gold, Vector3.ZERO, Vector3(1.05, 0.95, 1.05))
	add_mesh(r, cyl_mesh(0.03, 0.04, 0.3, 6), mat(Color(0.45, 0.28, 0.1)), Vector3(0, 0.5, 0))
	add_mesh(r, sphere_mesh(0.15, 0.06, 8), mat(Color(0.2, 0.75, 0.25)), Vector3(0.14, 0.55, 0), Vector3(1.6, 1, 0.8), Vector3(0, 0, -25))
	return r

func make_princess(parent: Node3D, pos: Vector3, pipo_mesh: Mesh) -> Node3D:
	var r := node_at(parent, pos)
	if pipo_mesh:
		var mi := MeshInstance3D.new()
		mi.mesh = pipo_mesh
		mi.scale = Vector3.ONE * 2.0
		var sh := Shader.new()
		sh.code = """
shader_type spatial;
render_mode cull_back;
// Reaproveita o modelo do Pipo trocando o azul por rosa (Princesa Penélope).
vec3 rgb2hsv(vec3 c){vec4 K=vec4(0.0,-1.0/3.0,2.0/3.0,-1.0);vec4 p=mix(vec4(c.bg,K.wz),vec4(c.gb,K.xy),step(c.b,c.g));vec4 q=mix(vec4(p.xyw,c.r),vec4(c.r,p.yzx),step(p.x,c.r));float d=q.x-min(q.w,q.y);float e=1.0e-10;return vec3(abs(q.z+(q.w-q.y)/(6.0*d+e)),d/(q.x+e),q.x);}
vec3 hsv2rgb(vec3 c){vec4 K=vec4(1.0,2.0/3.0,1.0/3.0,3.0);vec3 p=abs(fract(c.xxx+K.xyz)*6.0-K.www);return c.z*mix(K.xxx,clamp(p-K.xxx,0.0,1.0),c.y);}
void fragment(){
	vec3 hsv = rgb2hsv(COLOR.rgb);
	if (hsv.x > 0.5 && hsv.x < 0.78 && hsv.y > 0.35) { hsv.x = 0.92; hsv.y *= 0.65; hsv.z = min(1.0, hsv.z * 1.15 + 0.15); }
	ALBEDO = hsv2rgb(hsv);
	ROUGHNESS = 0.35;
}
"""
		var sm := ShaderMaterial.new()
		sm.shader = sh
		mi.material_override = sm
		r.add_child(mi)
	# coroa
	var crown := node_at(r, Vector3(0, 1.93, 0))
	var gold := mat(Color(1.0, 0.8, 0.2), 0.8, false, false, 0.2)
	add_mesh(crown, cyl_mesh(0.22, 0.22, 0.12, 12), gold, Vector3.ZERO, Vector3.ONE, Vector3.ZERO, false)
	for i in range(5):
		add_mesh(crown, cyl_mesh(0.0, 0.07, 0.2, 4), gold, Vector3(cos(i * TAU / 5.0) * 0.18, 0.15, sin(i * TAU / 5.0) * 0.18), Vector3.ONE, Vector3.ZERO, false)
	add_mesh(crown, sphere_mesh(0.05, 0.1, 6), mat(Color(1, 0.2, 0.5), 2.0), Vector3(0, 0.08, -0.22), Vector3.ONE, Vector3.ZERO, false)
	return r

func make_particles(theme: String) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.amount = 260
	p.lifetime = 4.0
	p.preprocess = 4.0
	p.local_coords = false
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = Vector3(16, 1, 24)
	p.direction = Vector3(0, -1, 0)
	p.spread = 20.0
	p.gravity = Vector3(0, -1.2, 0)
	p.initial_velocity_min = 0.6
	p.initial_velocity_max = 1.6
	var q := QuadMesh.new()
	q.size = Vector2(0.09, 0.09)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(1, 1, 1, 0.9)
	match theme:
		"dust":
			m.albedo_color = Color(0.6, 0.9, 1.0, 0.7)
			p.gravity = Vector3(0, 0.15, 0)
			p.amount = 120
		"snow_light":
			p.amount = 120
		"leaves":
			q.size = Vector2(0.16, 0.1)
			m.albedo_color = Color(0.9, 0.6, 0.2, 0.95)
			p.amount = 90
			p.angular_velocity_min = -180
			p.angular_velocity_max = 180
		"sparkle":
			m.albedo_color = Color(0.7, 0.9, 1.0, 0.9)
			m.emission_enabled = true
			m.emission = Color(0.6, 0.8, 1.0)
			p.gravity = Vector3(0, -0.4, 0)
	q.material = m
	p.mesh = q
	return p

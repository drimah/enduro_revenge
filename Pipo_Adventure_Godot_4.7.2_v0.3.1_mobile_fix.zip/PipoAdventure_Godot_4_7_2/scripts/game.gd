extends Node3D
## PIPO ADVENTURE — homenagem ao Penguin Adventure (MSX) com o que uma
## continuação teria: 5 mundos, corrida contra o relógio, controle de
## velocidade, buracos, loja, chefes e o final com a Maçã Dourada.

const Builder := preload("res://scripts/builder.gd")
const TouchPadScript := preload("res://scripts/touch_pad.gd")

const VERSION := "0.4.2"
const SAVE_PATH := "user://pipo_adventure.cfg"
const LANE_WIDTH := 2.25
const JUMP_VELOCITY := 8.2
const GRAVITY := 22.0
const SPEED_MIN := 5.0
const SPEED_START := 9.0
const SPEED_MAX := 16.0
const SPEED_MAX_BOOTS := 19.5
const BOSS_SPEED := 10.0
const BOSS_DIST := 22.0
const VIEW_AHEAD := 92.0
const PLAYER_H := 1.5
const MODEL_SCALE := 1.9
const FLY_HEIGHT := 2.7

const WORLDS := [
	{"name": "PLANÍCIE GELADA", "theme": "ice", "boss": "walrus", "boss_name": "REI MORSA"},
	{"name": "CAVERNA DE CRISTAL", "theme": "cave", "boss": "bat", "boss_name": "MORCEGÃO"},
	{"name": "MAR CONGELADO", "theme": "sea", "boss": "octopus", "boss_name": "POLVO KRAKEN"},
	{"name": "FLORESTA PERDIDA", "theme": "forest", "boss": "dino", "boss_name": "DINO REX"},
	{"name": "CASTELO DA AURORA", "theme": "aurora", "boss": "shadow", "boss_name": "REI SOMBRA"},
]

const SHOP_ITEMS := [
	{"id": "propeller", "name": "Hélice", "desc": "Voa 5 s por cima de tudo (botão ITEM ou E)", "price": 15},
	{"id": "helmet", "name": "Capacete", "desc": "Aguenta 1 trombada sem cair", "price": 20},
	{"id": "boots", "name": "Botas Turbo", "desc": "Velocidade máxima maior na próxima fase", "price": 25},
	{"id": "lantern", "name": "Lanterna", "desc": "Ilumina a caverna e a noite (permanente)", "price": 30},
	{"id": "clock", "name": "Relógio", "desc": "+20 segundos na próxima fase", "price": 12},
	{"id": "life", "name": "Vida extra", "desc": "+1 Pipo", "price": 50},
]

enum S { TITLE, INTRO, PLAY, DYING, CLEAR, SHOP, GAMEOVER, ENDING }

var B: Builder

# ---------------------------------------------------------------- progresso
var state: S = S.TITLE
var paused := false
var world := 0
var stage := 0          # 0 e 1 = fases normais, 2 = chefe
var lives := 3
var score := 0
var fish := 0
var stage_fish := 0
var hiscore := 0
var best_world := 0
var propellers := 0
var helmet := false
var boots := false
var lantern := false
var clock_bonus := 0

# ---------------------------------------------------------------- fase atual
var level: Node3D
var far: Node3D
var props: Array[Node3D] = []
var props_span := 0.0
var particles: CPUParticles3D
var objects: Array[Dictionary] = []
var theme := "ice"
var stage_len := 800.0
var time_left := 60.0
var spawn_z := 0.0
var secret_spawned := false
var speed := SPEED_START
var pz := 0.0
var px := 0.0
var py := 0.0
var vy := 0.0
var lane := 0
var act := "run"
var act_t := 0.0
var invuln := 0.0
var fly_t := 0.0
var magnet_t := 0.0
var star_t := 0.0
var jump_buf := 0.0
var beep_t := 0.0
var combo := 0
var combo_t := 0.0
var fall_resume_z := 0.0
var shake := 0.0
var state_t := 0.0
var anim_t := 0.0

# ---------------------------------------------------------------- chefe
var is_boss := false
var boss: Node3D
var boss_kind := ""
var boss_hp := 0
var boss_max := 0
var boss_x := 0.0
var boss_target_x := 0.0
var boss_attack_t := 0.0
var boss_move_t := 0.0
var boss_flash := 0.0
var boss_dead := false
var hearts := 3
var ammo_t := 0.0

# ---------------------------------------------------------------- nós
var env: Environment
var sun: DirectionalLight3D
var player: Node3D
var model: MeshInstance3D
var model_mat: StandardMaterial3D
var pipo_mesh: Mesh
var skis: Array[MeshInstance3D] = []
var hat: Node3D
var helmet_node: Node3D
var lantern_light: OmniLight3D
var camera: Camera3D
var hud: CanvasLayer
var touch: TouchPadScript
var ui_root: Control
var top_bar: Control
var lives_label: Label
var score_label: Label
var fish_label: Label
var stage_label: Label
var time_label: Label
var prog_bg: ColorRect
var prog_fill: ColorRect
var prog_marker: ColorRect
var speed_box: Control
var speed_fill: ColorRect
var inv_label: Label
var boss_box: Control
var boss_name_label: Label
var boss_fill: ColorRect
var hearts_label: Label
var center_label: Label
var sub_label: Label
var toast_label: Label
var toast_t := 0.0
var pause_btn: Button
var panel: Control
var music: AudioStreamPlayer
var music_name := ""
var sfx_pool: Array[AudioStreamPlayer] = []
var sfx_i := 0
var sounds := {}

# ================================================================ BOOT
func _ready() -> void:
	randomize()
	B = Builder.new()
	_load_save()
	_setup_input()
	_build_env()
	_build_player()
	_build_camera()
	_build_hud()
	_setup_audio()
	_show_title()

func _setup_input() -> void:
	var keys := {
		"left": [KEY_LEFT, KEY_A], "right": [KEY_RIGHT, KEY_D], "jump": [KEY_SPACE, KEY_Z, KEY_K],
		"accel": [KEY_UP, KEY_W], "brake": [KEY_DOWN, KEY_S], "item": [KEY_E, KEY_SHIFT, KEY_X, KEY_L],
		"pause": [KEY_ESCAPE, KEY_P], "toggle_touch": [KEY_T],
	}
	var pads := {
		"left": [JOY_BUTTON_DPAD_LEFT], "right": [JOY_BUTTON_DPAD_RIGHT], "jump": [JOY_BUTTON_A],
		"accel": [JOY_BUTTON_DPAD_UP, JOY_BUTTON_RIGHT_SHOULDER], "brake": [JOY_BUTTON_DPAD_DOWN, JOY_BUTTON_LEFT_SHOULDER],
		"item": [JOY_BUTTON_B, JOY_BUTTON_X], "pause": [JOY_BUTTON_START],
	}
	for action in keys:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for k in keys[action]:
			var e := InputEventKey.new()
			e.physical_keycode = k
			InputMap.action_add_event(action, e)
		for b in pads.get(action, []):
			var j := InputEventJoypadButton.new()
			j.button_index = b
			InputMap.action_add_event(action, j)

func _load_save() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		hiscore = int(cf.get_value("pipo", "hiscore", 0))
		best_world = int(cf.get_value("pipo", "best_world", 0))

func _save() -> void:
	hiscore = maxi(hiscore, score)
	var cf := ConfigFile.new()
	cf.set_value("pipo", "hiscore", hiscore)
	cf.set_value("pipo", "best_world", best_world)
	cf.save(SAVE_PATH)

# ================================================================ ÁUDIO
func _setup_audio() -> void:
	music = AudioStreamPlayer.new()
	music.volume_db = -9.0
	add_child(music)
	music.finished.connect(func():
		if music_name in ["theme", "boss", "shop", "ending"]:
			music.play())
	for i in range(6):
		var p := AudioStreamPlayer.new()
		p.volume_db = -4.0
		add_child(p)
		sfx_pool.append(p)
	for n in ["collect", "jump", "hit", "powerup", "fall", "splash", "stumble", "buy", "beep", "propeller",
			"boss_hit", "throw", "bounce", "secret", "menu", "boss_defeat", "stage_clear", "game_over"]:
		sounds[n] = load("res://assets/audio/%s.wav" % n)
	sounds["theme"] = load("res://assets/audio/pipo_adventure_theme.wav")
	sounds["boss"] = load("res://assets/audio/boss_theme.wav")
	sounds["shop"] = load("res://assets/audio/shop_theme.wav")
	sounds["ending"] = load("res://assets/audio/ending_theme.wav")

func _music(name: String) -> void:
	if music_name == name and music.playing:
		return
	music_name = name
	if name == "" or not sounds.has(name):
		music.stop()
		return
	music.stream = sounds[name]
	music.play()

func _sfx(name: String) -> void:
	if not sounds.has(name) or sounds[name] == null:
		return
	var p := sfx_pool[sfx_i]
	sfx_i = (sfx_i + 1) % sfx_pool.size()
	p.stream = sounds[name]
	p.play()

# ================================================================ AMBIENTE
func _build_env() -> void:
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky.sky_material = ProceduralSkyMaterial.new()
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_sky_affect = 0.6
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -25, 0)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 45.0
	add_child(sun)

func _apply_theme(t: String) -> void:
	theme = t
	var d: Dictionary = Builder.THEMES[t]
	var sm := env.sky.sky_material as ProceduralSkyMaterial
	sm.sky_top_color = d["sky_top"]
	sm.sky_horizon_color = d["sky_horizon"]
	sm.ground_horizon_color = d["sky_horizon"]
	sm.ground_bottom_color = d["side"]
	env.ambient_light_color = d["ambient"]
	env.ambient_light_energy = d["ambient_energy"]
	env.fog_light_color = d["fog"]
	var dens: float = d["fog_density"]
	if lantern and t in ["cave", "aurora"]:
		dens *= 0.45
		env.ambient_light_energy = float(d["ambient_energy"]) + 0.25
	env.fog_density = dens
	sun.light_color = d["sun"]
	sun.light_energy = d["sun_energy"]
	lantern_light.visible = lantern and t in ["cave", "aurora"]

# ================================================================ PIPO
func _build_player() -> void:
	player = Node3D.new()
	player.name = "Pipo"
	add_child(player)
	var m = load("res://assets/pipo.obj")
	if m is Mesh:
		pipo_mesh = m
		model = MeshInstance3D.new()
		model.mesh = pipo_mesh
		model.scale = Vector3.ONE * MODEL_SCALE
		model_mat = StandardMaterial3D.new()
		model_mat.vertex_color_use_as_albedo = true
		model_mat.roughness = 0.34
		model.material_override = model_mat
	else:
		model = MeshInstance3D.new()
		model.mesh = B.sphere_mesh(0.55, 1.1)
		model.position.y = 0.6
		model_mat = B.mat(Color(0.08, 0.2, 0.9)).duplicate()
		model.material_override = model_mat
	player.add_child(model)
	# esquis
	var ski_m := B.mat(Color(0.04, 0.28, 0.82), 0.0, false, false, 0.3)
	var tip_m := B.mat(Color(0.12, 0.68, 1.0))
	for s in [-1.0, 1.0]:
		var ski := B.add_mesh(player, B.box_mesh(Vector3(0.19, 0.065, 1.05)), ski_m, Vector3(s * 0.27, 0.035, 0.16))
		B.add_mesh(ski, B.sphere_mesh(0.105, 0.13, 10), tip_m, Vector3(0, 0.015, 0.53), Vector3(1.0, 0.55, 1.35), Vector3.ZERO, false)
		skis.append(ski)
	# chapéu-hélice (aparece ao voar)
	hat = Node3D.new()
	hat.position = Vector3(0, 0.98 * MODEL_SCALE - 0.02, -0.03)
	player.add_child(hat)
	B.add_mesh(hat, B.sphere_mesh(0.26, 0.26, 12), B.mat(Color(1.0, 0.75, 0.1)), Vector3.ZERO, Vector3(1, 1, 1), Vector3.ZERO, false)
	B.add_mesh(hat, B.cyl_mesh(0.02, 0.02, 0.25, 6), B.mat(Color(0.3, 0.3, 0.3)), Vector3(0, 0.15, 0), Vector3.ONE, Vector3.ZERO, false)
	var blade := Node3D.new()
	blade.name = "Blade"
	blade.position.y = 0.28
	hat.add_child(blade)
	B.add_mesh(blade, B.box_mesh(Vector3(1.3, 0.03, 0.16)), B.mat(Color(0.95, 0.25, 0.2)), Vector3.ZERO, Vector3.ONE, Vector3.ZERO, false)
	B.add_mesh(blade, B.box_mesh(Vector3(0.16, 0.03, 1.3)), B.mat(Color(0.2, 0.5, 1.0)), Vector3.ZERO, Vector3.ONE, Vector3.ZERO, false)
	hat.visible = false
	# capacete
	helmet_node = Node3D.new()
	helmet_node.position = Vector3(0, 0.98 * MODEL_SCALE - 0.28, -0.03)
	player.add_child(helmet_node)
	B.add_mesh(helmet_node, B.sphere_mesh(0.48, 0.5, 16), B.mat(Color(0.95, 0.85, 0.15), 0.2, false, false, 0.3), Vector3.ZERO, Vector3(1.05, 1, 1.05), Vector3.ZERO, false)
	B.add_mesh(helmet_node, B.box_mesh(Vector3(0.12, 0.08, 0.7)), B.mat(Color(0.9, 0.2, 0.2)), Vector3(0, 0.22, 0), Vector3.ONE, Vector3.ZERO, false)
	helmet_node.visible = false
	# lanterna
	lantern_light = OmniLight3D.new()
	lantern_light.position = Vector3(0, 2.5, 2.5)
	lantern_light.light_color = Color(1.0, 0.85, 0.6)
	lantern_light.light_energy = 2.2
	lantern_light.omni_range = 16.0
	lantern_light.visible = false
	player.add_child(lantern_light)

func _build_camera() -> void:
	camera = Camera3D.new()
	camera.fov = 60.0
	camera.far = 260.0
	camera.current = true
	add_child(camera)

# ================================================================ HUD
func _style(bg: Color, radius: int = 14, border: Color = Color(1, 1, 1, 0.0), bw: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	s.border_color = border
	s.set_border_width_all(bw)
	s.content_margin_left = 14
	s.content_margin_right = 14
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	return s

func _label(text: String, size: int, color: Color = Color.WHITE, parent: Node = null) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0.02, 0.05, 0.14, 0.95))
	l.add_theme_constant_override("outline_size", maxi(4, size / 5))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if parent:
		parent.add_child(l)
	return l

func _build_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	# barra superior
	top_bar = PanelContainer.new()
	top_bar.add_theme_stylebox_override("panel", _style(Color(0.025, 0.08, 0.22, 0.75), 14))
	top_bar.anchor_right = 1.0
	top_bar.offset_left = 14
	top_bar.offset_right = -14
	top_bar.offset_top = 12
	top_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(top_bar)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 18)
	hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_bar.add_child(hb)
	lives_label = _label("🐧 ×3", 26, Color.WHITE, hb)
	score_label = _label("000000", 26, Color.WHITE, hb)
	fish_label = _label("🐟 ×0", 26, Color.WHITE, hb)
	stage_label = _label("MUNDO 1-1", 26, Color.WHITE, hb)
	time_label = _label("TEMPO 60", 26, Color(1, 0.95, 0.5), hb)
	for l in [lives_label, score_label, fish_label, stage_label, time_label]:
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	# barra de progresso da fase
	prog_bg = ColorRect.new()
	prog_bg.color = Color(0.02, 0.06, 0.18, 0.6)
	prog_bg.anchor_right = 1.0
	prog_bg.offset_left = 40
	prog_bg.offset_right = -110
	prog_bg.offset_top = 82
	prog_bg.offset_bottom = 92
	prog_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(prog_bg)
	prog_fill = ColorRect.new()
	prog_fill.color = Color(0.35, 0.85, 1.0)
	prog_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	prog_bg.add_child(prog_fill)
	prog_marker = ColorRect.new()
	prog_marker.color = Color(1, 0.85, 0.2)
	prog_marker.size = Vector2(14, 18)
	prog_marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
	prog_bg.add_child(prog_marker)
	# inventário
	inv_label = _label("", 20, Color(0.95, 0.98, 1.0), hud)
	inv_label.position = Vector2(26, 100)
	# velocímetro
	speed_box = Control.new()
	speed_box.anchor_left = 0.5
	speed_box.anchor_right = 0.5
	speed_box.anchor_top = 1.0
	speed_box.anchor_bottom = 1.0
	speed_box.offset_left = -160
	speed_box.offset_right = 160
	speed_box.offset_top = -58
	speed_box.offset_bottom = -20
	speed_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(speed_box)
	var sb := ColorRect.new()
	sb.color = Color(0.02, 0.06, 0.18, 0.65)
	sb.position = Vector2(0, 22)
	sb.size = Vector2(320, 14)
	sb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	speed_box.add_child(sb)
	speed_fill = ColorRect.new()
	speed_fill.color = Color(0.3, 1.0, 0.55)
	speed_fill.position = Vector2(2, 2)
	speed_fill.size = Vector2(100, 10)
	speed_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sb.add_child(speed_fill)
	var sl := _label("VELOCIDADE", 16, Color.WHITE, speed_box)
	sl.position = Vector2(0, 0)
	# chefe
	boss_box = Control.new()
	boss_box.anchor_left = 0.5
	boss_box.anchor_right = 0.5
	boss_box.offset_left = -260
	boss_box.offset_right = 260
	boss_box.offset_top = 100
	boss_box.offset_bottom = 150
	boss_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(boss_box)
	boss_name_label = _label("CHEFE", 22, Color(1, 0.8, 0.8), boss_box)
	var bb := ColorRect.new()
	bb.color = Color(0.1, 0.02, 0.05, 0.75)
	bb.position = Vector2(0, 30)
	bb.size = Vector2(520, 16)
	bb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	boss_box.add_child(bb)
	boss_fill = ColorRect.new()
	boss_fill.color = Color(1, 0.25, 0.3)
	boss_fill.position = Vector2(2, 2)
	boss_fill.size = Vector2(516, 12)
	boss_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bb.add_child(boss_fill)
	hearts_label = _label("♥♥♥", 34, Color(1, 0.3, 0.4), hud)
	hearts_label.position = Vector2(26, 130)
	# mensagens
	center_label = _label("", 54, Color(1.0, 0.93, 0.35), hud)
	center_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	center_label.anchor_top = 0.36
	center_label.anchor_bottom = 0.36
	center_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	center_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub_label = _label("", 28, Color.WHITE, hud)
	sub_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	sub_label.anchor_top = 0.47
	sub_label.anchor_bottom = 0.47
	sub_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	sub_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label = _label("", 30, Color(0.6, 1.0, 0.8), hud)
	toast_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	toast_label.anchor_top = 0.25
	toast_label.anchor_bottom = 0.25
	toast_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	# controles de toque
	touch = TouchPadScript.new()
	hud.add_child(touch)
	touch.tapped.connect(_on_touch)
	touch.visible = false
	# pausa
	pause_btn = Button.new()
	pause_btn.text = "Ⅱ"
	pause_btn.focus_mode = Control.FOCUS_NONE
	pause_btn.anchor_left = 1.0
	pause_btn.anchor_right = 1.0
	pause_btn.offset_left = -84
	pause_btn.offset_right = -20
	pause_btn.offset_top = 100
	pause_btn.offset_bottom = 164
	pause_btn.add_theme_font_size_override("font_size", 30)
	pause_btn.add_theme_stylebox_override("normal", _style(Color(0.05, 0.18, 0.42, 0.55), 32, Color(1, 1, 1, 0.85), 3))
	pause_btn.add_theme_stylebox_override("hover", _style(Color(0.08, 0.3, 0.65, 0.75), 32, Color(1, 1, 1, 0.85), 3))
	pause_btn.add_theme_stylebox_override("pressed", _style(Color(0.15, 0.48, 0.85, 0.9), 32, Color(1, 1, 1, 0.85), 3))
	pause_btn.pressed.connect(_toggle_pause)
	hud.add_child(pause_btn)
	# camada de menus
	ui_root = Control.new()
	ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(ui_root)

func _touch_wanted() -> bool:
	return DisplayServer.is_touchscreen_available() or OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios")

var touch_forced := -1   # -1 automático, 0 oculto, 1 visível

func _set_hud_mode(gameplay: bool) -> void:
	top_bar.visible = gameplay
	prog_bg.visible = gameplay and not is_boss
	speed_box.visible = gameplay and not is_boss
	inv_label.visible = gameplay
	boss_box.visible = gameplay and is_boss
	hearts_label.visible = gameplay and is_boss
	pause_btn.visible = gameplay
	time_label.visible = not is_boss
	var want := _touch_wanted() if touch_forced < 0 else touch_forced == 1
	touch.visible = gameplay and want
	if not touch.visible:
		touch.release_all()

func _toast(text: String, color: Color = Color(0.6, 1.0, 0.8)) -> void:
	toast_label.text = text
	toast_label.add_theme_color_override("font_color", color)
	toast_t = 1.4

func _update_hud() -> void:
	lives_label.text = "🐧 ×%d" % lives
	score_label.text = "%07d" % score
	fish_label.text = "🐟 ×%d" % fish
	stage_label.text = "MUNDO %d-%s" % [world + 1, "★" if is_boss else str(stage + 1)]
	var tl := int(ceil(time_left))
	time_label.text = "TEMPO %d" % tl
	time_label.add_theme_color_override("font_color", Color(1, 0.3, 0.3) if tl <= 10 and int(anim_t * 4) % 2 == 0 else Color(1, 0.95, 0.5))
	var w := prog_bg.size.x
	var f := clampf(pz / stage_len, 0, 1)
	prog_fill.size = Vector2(w * f, prog_bg.size.y)
	prog_marker.position = Vector2(w * f - 7, -4)
	var vmax := SPEED_MAX_BOOTS if boots else SPEED_MAX
	var sf := clampf((speed - 0) / vmax, 0, 1)
	speed_fill.size = Vector2(316 * sf, 10)
	speed_fill.color = Color(0.3, 1.0, 0.55).lerp(Color(1.0, 0.35, 0.25), clampf((speed - 11) / 7.0, 0, 1))
	var inv: Array[String] = []
	inv.append("HÉLICE ×%d [E]" % propellers)
	if helmet: inv.append("CAPACETE")
	if boots: inv.append("BOTAS TURBO")
	if lantern: inv.append("LANTERNA")
	if fly_t > 0: inv.append("✈ VOANDO %.0fs" % ceil(fly_t))
	if magnet_t > 0: inv.append("ÍMÃ %.0fs" % ceil(magnet_t))
	if star_t > 0: inv.append("★ ESTRELA %.0fs" % ceil(star_t))
	inv_label.text = "   ".join(inv)
	if is_boss:
		boss_fill.size = Vector2(516.0 * float(boss_hp) / maxf(1.0, float(boss_max)), 12)
		hearts_label.text = "♥".repeat(maxi(0, hearts)) + "♡".repeat(maxi(0, 3 - hearts))
	touch.item_label = ("VOAR ×%d" % propellers) if propellers > 0 else "ITEM"

# ================================================================ MENUS
func _clear_panel() -> void:
	if panel and is_instance_valid(panel):
		panel.queue_free()
	panel = null

func _make_panel(width: float, height: float, bg: Color = Color(0.03, 0.09, 0.25, 0.9)) -> VBoxContainer:
	_clear_panel()
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", _style(bg, 22, Color(0.6, 0.85, 1.0, 0.9), 3))
	pc.anchor_left = 0.5
	pc.anchor_right = 0.5
	pc.anchor_top = 0.5
	pc.anchor_bottom = 0.5
	pc.offset_left = -width * 0.5
	pc.offset_right = width * 0.5
	pc.offset_top = -height * 0.5
	pc.offset_bottom = height * 0.5
	ui_root.add_child(pc)
	panel = pc
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	pc.add_child(vb)
	return vb

func _btn(parent: Node, text: String, cb: Callable, size: int = 26) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", size)
	b.add_theme_stylebox_override("normal", _style(Color(0.08, 0.3, 0.7, 0.9), 16, Color(1, 1, 1, 0.7), 2))
	b.add_theme_stylebox_override("hover", _style(Color(0.15, 0.45, 0.9, 0.95), 16, Color(1, 1, 1, 0.9), 2))
	b.add_theme_stylebox_override("focus", _style(Color(0.15, 0.45, 0.9, 0.95), 16, Color(1, 0.9, 0.3, 1.0), 3))
	b.add_theme_stylebox_override("pressed", _style(Color(0.3, 0.6, 1.0, 1.0), 16, Color(1, 1, 1, 1), 2))
	b.add_theme_stylebox_override("disabled", _style(Color(0.2, 0.22, 0.3, 0.7), 16, Color(1, 1, 1, 0.3), 2))
	b.custom_minimum_size = Vector2(0, size * 2.1)
	b.pressed.connect(func():
		_sfx("menu")
		cb.call())
	parent.add_child(b)
	return b

func _center_text(parent: Node, text: String, size: int, color: Color = Color.WHITE) -> Label:
	var l := _label(text, size, color, parent)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

# ---------------------------------------------------------------- título
func _show_title() -> void:
	state = S.TITLE
	paused = false
	is_boss = false
	_build_scenery_only("ice")
	_set_hud_mode(false)
	center_label.text = ""
	sub_label.text = ""
	player.visible = true
	player.position = Vector3(0, 0, 0)
	player.rotation = Vector3.ZERO
	model.rotation = Vector3.ZERO
	model.visible = true
	model_mat.emission_enabled = false
	hat.visible = false
	helmet_node.visible = false
	for sk in skis:
		sk.visible = true
	_music("theme")
	var vb := _make_panel(560, 560, Color(0.03, 0.09, 0.25, 0.0))
	panel.add_theme_stylebox_override("panel", StyleBoxEmpty.new())
	panel.anchor_left = 0.0
	panel.anchor_right = 0.0
	panel.offset_left = 50
	panel.offset_right = 610
	var t := _center_text(vb, "PIPO\nADVENTURE", 76, Color(1.0, 0.9, 0.3))
	t.add_theme_constant_override("line_spacing", -18)
	_center_text(vb, "Em busca da Maçã Dourada", 26, Color(0.85, 0.95, 1.0))
	_center_text(vb, "RECORDE  %07d" % hiscore, 22, Color(0.7, 1.0, 0.8))
	var first := _btn(vb, "NOVO JOGO", func(): _new_game(0))
	if best_world > 0:
		_btn(vb, "CONTINUAR  (MUNDO %d)" % (best_world + 1), func(): _new_game(best_world))
	_btn(vb, "HISTÓRIA E CONTROLES", _show_help)
	_center_text(vb, "v%s" % VERSION, 14, Color(1, 1, 1, 0.6))
	first.grab_focus()

func _show_help() -> void:
	var vb := _make_panel(900, 640)
	_center_text(vb, "HISTÓRIA", 34, Color(1, 0.9, 0.3))
	_center_text(vb, "A Princesa Penélope caiu doente, e só a lendária Maçã Dourada, guardada pelo Rei Sombra no Castelo da Aurora, pode curá-la. Pipo calça os esquis e parte pelos 5 mundos gelados. Corra contra o relógio, pegue peixes para gastar na loja e derrote os guardiões de cada mundo!", 20)
	_center_text(vb, "CONTROLES", 30, Color(1, 0.9, 0.3))
	_center_text(vb, "◀ ▶ / A D — trocar de pista      ▲ ▼ / W S — acelerar e frear\nESPAÇO / Z — pular      E / SHIFT — usar Hélice      ESC / P — pausar\nControle: D-pad, A pula, B usa item, LB/RB freia/acelera\nCelular: botões na tela (T liga/desliga no PC)", 19, Color(0.85, 0.95, 1.0))
	_center_text(vb, "DICAS", 30, Color(1, 0.9, 0.3))
	_center_text(vb, "Trombar não tira vida, mas faz perder tempo. Buracos e fendas derrubam o Pipo. Se o tempo acabar, perde uma vida. Buracos brilhantes escondem tocas secretas! No chefe, pegue os peixes dourados para atirá-los nele.", 19)
	var b := _btn(vb, "VOLTAR", _show_title)
	b.grab_focus()

# ---------------------------------------------------------------- jogo
func _new_game(from_world: int) -> void:
	world = from_world
	lives = 3
	score = 0
	fish = 10 * from_world
	propellers = 1 if from_world > 0 else 0
	helmet = false
	boots = false
	lantern = from_world > 1
	clock_bonus = 0
	_start_stage(from_world, 0)

func _start_stage(w: int, s: int) -> void:
	world = w
	stage = s
	is_boss = s == 2
	paused = false
	_clear_panel()
	var wd: Dictionary = WORLDS[w]
	_build_level(wd["theme"])
	# estado do Pipo
	pz = 0.0
	px = 0.0
	py = 0.0
	vy = 0.0
	lane = 0
	speed = BOSS_SPEED if is_boss else SPEED_START
	act = "run"
	invuln = 0.0
	fly_t = 0.0
	magnet_t = 0.0
	star_t = 0.0
	combo = 0
	stage_fish = 0
	secret_spawned = false
	hearts = 3
	stage_len = 2200.0 if is_boss else 650.0 + w * 110.0 + s * 120.0
	time_left = (stage_len / 11.2) + 7.0 + clock_bonus
	clock_bonus = 0
	player.visible = true
	model.visible = true
	player.rotation = Vector3.ZERO
	model.rotation = Vector3.ZERO
	model.position = Vector3.ZERO
	_finish_level_build(not is_boss)
	state = S.INTRO
	state_t = 2.4
	_set_hud_mode(true)
	center_label.text = ("MUNDO %d  —  CHEFE!" % (w + 1)) if is_boss else ("MUNDO %d-%d" % [w + 1, s + 1])
	sub_label.text = (wd["boss_name"] as String) if is_boss else (wd["name"] as String)
	_music("boss" if is_boss else "theme")
	_update_hud()
	_update_camera(1.0, true)

func _build_scenery_only(t: String) -> void:
	_build_level(t)
	stage_len = 400.0
	pz = 0.0
	_finish_level_build()

func _build_level(t: String) -> void:
	if level and is_instance_valid(level):
		level.queue_free()
	objects.clear()
	props.clear()
	boss = null
	level = Node3D.new()
	level.name = "Level"
	add_child(level)
	_apply_theme(t)

func _finish_level_build(with_finish: bool = false) -> void:
	var d: Dictionary = Builder.THEMES[theme]
	B.make_ground(level, theme, stage_len)
	far = Node3D.new()
	level.add_child(far)
	B.make_far_scenery(far, theme)
	if theme == "aurora":
		B.make_castle(far, Vector3(0, -2, 115))
	# cenário reciclável dos lados
	var kinds: Array = d["props"]
	var spacing := 8.5
	var count := 15
	props_span = spacing * count
	for i in range(count):
		for s in [-1.0, 1.0]:
			var x: float = s * randf_range(7.2, 10.5)
			if theme == "sea":
				x = s * randf_range(8.0, 22.0)
			elif theme == "cave":
				x = s * randf_range(6.4, 9.0)
			var p := B.make_prop(level, kinds[randi() % kinds.size()], Vector3(x, 0, i * spacing + randf() * 4.0 - 6.0 + (4.0 if s > 0 else 0.0)))
			if theme == "sea":
				p.position.y = -0.45
			props.append(p)
	if with_finish:
		B.make_finish(level, stage_len)
	particles = B.make_particles(d["particles"])
	level.add_child(particles)
	spawn_z = 24.0
	if is_boss:
		_spawn_boss()

# ================================================================ GERAÇÃO DA FASE
func _add_obj(kind: String, node: Node3D, x: float, z: float, hx: float, hz: float, y0: float, y1: float) -> Dictionary:
	var o := {"kind": kind, "node": node, "x": x, "z": z, "hx": hx, "hz": hz, "y0": y0, "y1": y1, "t": randf() * 10.0, "done": false, "on": false}
	objects.append(o)
	return o

func _lx(l: int) -> float:
	return float(l) * LANE_WIDTH

func _rand_lane() -> int:
	return randi_range(-1, 1)

func _spawn_fish(x: float, z: float, y: float = 0.8) -> void:
	var n := B.make_fish(level, Vector3(x, y, z))
	var o := _add_obj("fish", n, x, z, 0.5, 0.5, y - 0.4, y + 0.4)
	o["base_y"] = y

func _spawn_block(l: int, z: float, kind: String = "") -> void:
	var d: Dictionary = Builder.THEMES[theme]
	if kind == "":
		kind = d["block"] if randf() < 0.7 else d["block2"]
	var x := _lx(l)
	var n := B.make_block(level, Vector3(x, 0, z), kind)
	var h := 1.0
	match kind:
		"snowman": h = 1.9
		"stalagmite": h = 1.5
		"rock": h = 0.95
		"ice_pillar_small": h = 2.0
	_add_obj("block", n, x, z, 0.6, 0.5, 0.0, h)

func _spawn_hole(l: int, z: float) -> void:
	var d: Dictionary = Builder.THEMES[theme]
	var x := _lx(l)
	var n := B.make_hole(level, Vector3(x, 0, z), 0.85, 0.75, d["gap"])
	_add_obj("hole", n, x, z, 0.75, 0.6, 0, 0)

func _spawn_gap(z: float, depth: float) -> void:
	var d: Dictionary = Builder.THEMES[theme]
	var n := B.make_gap(level, Vector3(0, 0, z), depth, d["gap"], theme == "sea")
	_add_obj("gap", n, 0, z, 6.0, depth * 0.5 - 0.15, 0, 0)

func _spawn_power(l: int, z: float, ptype: String = "") -> void:
	if ptype == "":
		var r := randf()
		ptype = "propeller" if r < 0.3 else ("clock" if r < 0.58 else ("magnet" if r < 0.85 else "star"))
	var n := B.make_powerup(level, Vector3(_lx(l), 1.0, z), ptype)
	var o := _add_obj("power", n, _lx(l), z, 0.6, 0.6, 0.4, 1.6)
	o["ptype"] = ptype

func _spawn_pattern(z: float) -> float:
	var diff := world * 2 + stage
	var weights := {
		"block": 3.0, "double_block": 0.8 + diff * 0.25, "hole": 2.0, "gap": 1.2, "fish_line": 2.6,
		"fish_arc": 1.3, "power": 0.55, "seal": 0.0, "leapfish": 0.0, "bat": 0.0, "stalactite": 0.0,
		"bird": 0.0, "log": 0.0, "dino": 0.0, "bounce": 0.0, "ghost": 0.0, "secret": 0.0,
	}
	match theme:
		"ice":
			weights["seal"] = 1.4
			weights["leapfish"] = 0.8
			weights["bird"] = 0.5
		"cave":
			weights["bat"] = 2.0
			weights["stalactite"] = 2.0
			weights["gap"] = 0.8
		"sea":
			weights["gap"] = 3.0
			weights["seal"] = 2.0
			weights["leapfish"] = 2.0
			weights["bird"] = 1.4
			weights["hole"] = 1.2
		"forest":
			weights["log"] = 2.2
			weights["dino"] = 1.6
			weights["bounce"] = 1.0
			weights["gap"] = 0.8
		"aurora":
			weights["ghost"] = 2.2
			weights["bat"] = 0.8
			weights["bird"] = 0.8
			weights["gap"] = 1.8
			weights["stalactite"] = 0.6
	if not secret_spawned and z > stage_len * 0.25 and randf() < 0.035:
		weights["secret"] = 50.0
	var total := 0.0
	for k in weights:
		total += weights[k]
	var r := randf() * total
	var pick := "block"
	for k in weights:
		r -= weights[k]
		if r <= 0:
			pick = k
			break
	var gap_after := maxf(7.5, randf_range(10.0, 15.5) - diff * 0.45)
	match pick:
		"block":
			var l := _rand_lane()
			_spawn_block(l, z)
			if randf() < 0.6:
				_spawn_fish(_lx(wrapi(l + 1, -1, 2)), z)
		"double_block":
			var free := _rand_lane()
			for l in [-1, 0, 1]:
				if l != free:
					_spawn_block(l, z)
			_spawn_fish(_lx(free), z)
			_spawn_fish(_lx(free), z + 2.0)
		"hole":
			var l := _rand_lane()
			_spawn_hole(l, z)
			if diff >= 3 and randf() < 0.5:
				_spawn_hole(wrapi(l + (1 if randf() < 0.5 else -1), -1, 2), z + 1.5)
		"gap":
			var depth := randf_range(1.8, 2.6) + diff * 0.06
			_spawn_gap(z, depth)
			var fl := _rand_lane()
			for i in range(3):
				_spawn_fish(_lx(fl), z - depth * 0.5 + i * depth * 0.5, 1.4 + (0.5 if i == 1 else 0.0))
			gap_after += depth
		"fish_line":
			var l := _rand_lane()
			for i in range(5):
				_spawn_fish(_lx(l), z + i * 2.2)
			gap_after += 8.0
		"fish_arc":
			var l := _rand_lane()
			_spawn_block(l, z + 4.0, "rock" if theme == "forest" else "ice_block")
			for i in range(5):
				var u := float(i) / 4.0
				_spawn_fish(_lx(l), z + 0.5 + i * 1.9, 0.9 + sin(u * PI) * 1.4)
			gap_after += 8.0
		"power":
			_spawn_power(_rand_lane(), z)
		"seal":
			var l := _rand_lane()
			var d: Dictionary = Builder.THEMES[theme]
			var res := B.make_seal(level, Vector3(_lx(l), 0, z), d["gap"])
			var o := _add_obj("seal", res["root"], _lx(l), z, 0.75, 0.6, 0.0, 1.4)
			o["seal"] = res["seal"]
		"leapfish":
			var n := B.make_fish(level, Vector3(-6, -1, z))
			var o := _add_obj("leapfish", n, -6, z, 0.6, 0.6, 0, 0)
			o["dir"] = 1.0 if randf() < 0.5 else -1.0
			for s in [-1.0, 1.0]:
				B.make_hole(level, Vector3(s * 4.3, 0, z), 0.4, 0.35, Builder.THEMES[theme]["gap"])
		"bat":
			var l := _rand_lane()
			var n := B.make_bat(level, Vector3(_lx(l), 1.35, z))
			var o := _add_obj("bat", n, _lx(l), z, 0.55, 0.4, 1.0, 1.75)
			o["base_x"] = _lx(l)
		"stalactite":
			var l := lane_hint() if randf() < 0.6 else _rand_lane()
			var res := B.make_stalactite(level, Vector3(_lx(l), 0, z))
			var o := _add_obj("stalactite", res["root"], _lx(l), z, 0.55, 0.5, 0.0, 0.0)
			o["rock"] = res["rock"]
			o["shadow"] = res["shadow"]
			o["ry"] = 8.5
			o["vy"] = 0.0
		"bird":
			var l := _rand_lane()
			var n := B.make_bird(level, Vector3(_lx(l), 6.0, z))
			var o := _add_obj("bird", n, _lx(l), z, 0.6, 0.5, 5.6, 6.4)
			o["ry"] = 6.0
		"log":
			var n := B.make_block(level, Vector3(0, 0, z), "log")
			_add_obj("block", n, 0, z, 5.0, 0.38, 0.0, 0.76)
			_spawn_fish(_lx(_rand_lane()), z, 1.9)
		"dino":
			var n := B.make_dino(level, Vector3(_lx(_rand_lane()), 0, z))
			var o := _add_obj("dino", n, n.position.x, z, 0.55, 0.6, 0.0, 1.6)
			o["dir"] = 1.0 if randf() < 0.5 else -1.0
		"bounce":
			var l := _rand_lane()
			var n := B.make_bounce(level, Vector3(_lx(l), 0, z))
			_add_obj("bounce", n, _lx(l), z, 0.7, 0.6, 0, 0.6)
			for i in range(6):
				_spawn_fish(_lx(l), z + 3.0 + i * 2.2, 2.0 + sin(float(i) / 5.0 * PI) * 2.5)
			gap_after += 12.0
		"ghost":
			var l := _rand_lane()
			var n := B.make_ghost(level, Vector3(_lx(l), 0, z))
			var o := _add_obj("ghost", n, _lx(l), z, 0.55, 0.45, 0.2, 1.8)
			o["base_x"] = _lx(l)
		"secret":
			secret_spawned = true
			var l := _rand_lane()
			var n := B.make_hole(level, Vector3(_lx(l), 0, z), 0.8, 0.7, Color(1.0, 0.35, 0.95), true)
			_add_obj("secret", n, _lx(l), z, 0.75, 0.6, 0, 0)
	return gap_after

func lane_hint() -> int:
	# pista onde o Pipo provavelmente estará — deixa a fase mais "viva"
	return lane

# ================================================================ CHEFE
func _spawn_boss() -> void:
	var wd: Dictionary = WORLDS[world]
	boss_kind = wd["boss"]
	boss = B.make_boss(level, boss_kind)
	boss.position = Vector3(0, 0, BOSS_DIST)
	boss.rotation_degrees.y = 0
	boss_max = 5 + world
	boss_hp = boss_max
	boss_x = 0.0
	boss_target_x = 0.0
	boss_attack_t = 3.0
	boss_move_t = 2.0
	boss_dead = false
	ammo_t = 2.0
	boss_name_label.text = wd["boss_name"]

func _boss_projectile(kind: String, x: float, hx: float, y0: float, y1: float, vz: float) -> void:
	var z := pz + BOSS_DIST - 1.5
	var n := B.make_projectile(level, Vector3(x, 0, z), kind)
	var o := _add_obj("proj", n, x, z, hx, 0.5, y0, y1)
	o["vz"] = vz
	o["pkind"] = kind
	if kind in ["snowball", "rock", "ink", "shadowball", "bigball"]:
		o["roll"] = true

func _boss_attack() -> void:
	var v := -3.0 - world * 0.7
	var l := _rand_lane()
	var other := wrapi(l + (1 if randf() < 0.5 else -1), -1, 2)
	var r := randf()
	_sfx("throw")
	match boss_kind:
		"walrus":
			if r < 0.5:
				_boss_projectile("snowball", _lx(l), 0.5, 0.0, 0.9, v)
			elif r < 0.8:
				_boss_projectile("snowball", _lx(l), 0.5, 0.0, 0.9, v)
				_boss_projectile("snowball", _lx(other), 0.5, 0.0, 0.9, v)
			else:
				_boss_projectile("bigball", _lx(l), 1.0, 0.0, 2.0, v * 0.85)
		"bat":
			if r < 0.55:
				_boss_projectile("rock", _lx(l), 0.5, 0.0, 0.9, v)
				if r < 0.25:
					_boss_projectile("rock", _lx(other), 0.5, 0.0, 0.9, v)
			else:
				for ll in [l, other]:
					var n := B.make_bat(level, Vector3(_lx(ll), 1.35, pz + BOSS_DIST - 1.5))
					var o := _add_obj("proj", n, _lx(ll), n.position.z, 0.55, 0.45, 1.0, 1.8)
					o["vz"] = v * 1.1
					o["pkind"] = "bat"
		"octopus":
			if r < 0.5:
				_boss_projectile("ink", _lx(l), 0.5, 0.0, 1.0, v)
			else:
				# tentáculo que cobre 2 pistas vizinhas — fuja para a pista livre (sempre uma ponta)
				var free := -1 if randf() < 0.5 else 1
				var covered: Array[int] = []
				for ll in [-1, 0, 1]:
					if ll != free:
						covered.append(ll)
				var cx := (_lx(covered[0]) + _lx(covered[1])) * 0.5
				_boss_projectile("tentacle", cx, 2.3, 0.0, 2.0, v * 0.9)
		"dino":
			if r < 0.4:
				_boss_projectile("log", 0.0, 5.0, 0.0, 0.76, v)
			elif r < 0.75:
				_boss_projectile("fireball", _lx(l), 0.5, 0.0, 1.0, v * 1.2)
			else:
				_boss_projectile("rock", _lx(l), 0.5, 0.0, 0.9, v)
				_boss_projectile("rock", _lx(other), 0.5, 0.0, 0.9, v)
		"shadow":
			if r < 0.25:
				_boss_projectile("wave", 0.0, 5.0, 0.0, 0.62, v)
			elif r < 0.5:
				_boss_projectile("shadowball", _lx(l), 0.55, 0.0, 1.1, v * 1.2)
				_boss_projectile("shadowball", _lx(other), 0.55, 0.0, 1.1, v * 1.2)
			elif r < 0.75:
				var free := _rand_lane()
				var covered: Array[int] = []
				for ll in [-1, 0, 1]:
					if ll != free:
						covered.append(ll)
				for ll in covered:
					_boss_projectile("shadowball", _lx(ll), 0.55, 0.0, 2.0, v)
			else:
				_boss_projectile("fireball", _lx(lane), 0.5, 0.0, 1.0, v * 1.3)

func _update_boss(d: float) -> void:
	if boss == null:
		return
	var body := boss.get_node("Body") as Node3D
	if boss_dead:
		boss.position.z = pz + BOSS_DIST
		body.rotation.y += d * 8.0
		body.position.y -= d * 2.5
		boss.scale = boss.scale.lerp(Vector3.ONE * 0.05, d * 1.5)
		return
	boss_move_t -= d
	if boss_move_t <= 0:
		boss_target_x = _lx(_rand_lane())
		boss_move_t = randf_range(1.2, 2.6) - world * 0.12
	boss_x = move_toward(boss_x, boss_target_x, d * 4.0)
	boss.position = Vector3(boss_x, 0, pz + BOSS_DIST)
	var bob := sin(anim_t * 3.0)
	body.position.y = (3.0 if boss_kind == "bat" else 0.0) + bob * (0.4 if boss_kind == "bat" else 0.12)
	for w in ["WingL", "WingR"]:
		var wn := body.get_node_or_null(w) as Node3D
		if wn:
			wn.rotation.z = sin(anim_t * 10.0) * 0.5 * (1.0 if w == "WingL" else -1.0)
	if boss_kind == "octopus":
		for i in range(8):
			var tn := body.get_node_or_null("Tentacle%d" % i) as Node3D
			if tn:
				tn.rotation.x = sin(anim_t * 3.0 + i) * 0.3
	if boss_flash > 0:
		boss_flash -= d
		boss.scale = Vector3.ONE * (1.0 + boss_flash * 0.5)
		boss.visible = int(boss_flash * 20) % 2 == 0
	else:
		boss.scale = Vector3.ONE
		boss.visible = true
	boss_attack_t -= d
	if boss_attack_t <= 0:
		_boss_attack()
		boss_attack_t = maxf(1.1, 2.3 - world * 0.2 + randf_range(-0.3, 0.3))
	ammo_t -= d
	if ammo_t <= 0:
		ammo_t = randf_range(2.6, 3.6)
		var l := _rand_lane()
		var z := pz + 28.0
		var n := B.make_fish(level, Vector3(_lx(l), 0.9, z), true)
		var o := _add_obj("gold", n, _lx(l), z, 0.6, 0.6, 0.4, 1.4)
		o["base_y"] = 0.9

func _throw_fish() -> void:
	var n := B.make_fish(level, Vector3(px, py + 1.0, pz + 0.5), true)
	var o := _add_obj("shot", n, px, pz + 0.5, 0, 0, 0, 0)
	o["y"] = py + 1.0
	_sfx("throw")

func _boss_hit() -> void:
	if boss_dead:
		return
	boss_hp -= 1
	boss_flash = 0.5
	shake = 0.35
	score += 500
	_sfx("boss_hit")
	if boss_hp <= 0:
		boss_dead = true
		_sfx("boss_defeat")
		_music("")
		center_label.text = "%s DERROTADO!" % (WORLDS[world]["boss_name"] as String)
		# limpa projéteis
		for o in objects:
			if o["kind"] == "proj":
				o["done"] = true
		var burst := CPUParticles3D.new()
		burst.one_shot = true
		burst.explosiveness = 1.0
		burst.amount = 80
		burst.lifetime = 1.6
		burst.direction = Vector3.UP
		burst.spread = 180
		burst.initial_velocity_min = 4
		burst.initial_velocity_max = 10
		var q := QuadMesh.new()
		q.size = Vector2(0.25, 0.25)
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
		m.vertex_color_use_as_albedo = true
		q.material = m
		burst.mesh = q
		var grad := Gradient.new()
		grad.set_color(0, Color(1, 0.9, 0.2))
		grad.set_color(1, Color(1, 0.3, 0.8))
		burst.color_initial_ramp = grad
		burst.position = boss.position + Vector3(0, 2, 0)
		level.add_child(burst)
		burst.emitting = true
		state = S.CLEAR
		state_t = 3.0
		touch.release_all()

# ================================================================ LOOP
func _process(delta: float) -> void:
	var d := minf(delta, 0.05)
	anim_t += d
	if toast_t > 0:
		toast_t -= d
		toast_label.modulate.a = clampf(toast_t * 2.0, 0, 1)
	if paused:
		return
	match state:
		S.TITLE:
			player.rotation.y += d * 0.6
			camera.position = Vector3(-2.4, 1.9, -5.2)
			camera.look_at(Vector3(-1.3, 1.25, 0), Vector3.UP)
			camera.fov = 55
			if particles:
				particles.position = Vector3(0, 6, 4)
		S.INTRO:
			state_t -= d
			_update_player_visual(d)
			_update_camera(d)
			_recycle_props()
			if state_t <= 0.6 and center_label.text != "VAI!":
				center_label.text = "VAI!"
				sub_label.text = ""
			if state_t <= 0:
				center_label.text = ""
				state = S.PLAY
		S.PLAY:
			_update_play(d)
		S.DYING:
			state_t -= d
			if act == "fall":
				py = move_toward(py, -2.5, d * 4.0)
			model.rotation.y += d * 10.0
			_update_player_visual(d)
			_update_camera(d)
			if state_t <= 0:
				if lives <= 0:
					_game_over()
				else:
					_start_stage(world, stage)
		S.CLEAR:
			state_t -= d
			if is_boss:
				_update_boss(d)
				speed = move_toward(speed, 4.0, d * 4.0)
				pz += speed * d
				_update_objects(d)
				_update_player_visual(d)
				_update_camera(d)
				if state_t <= 0 and panel == null:
					_show_clear_panel()
			else:
				speed = move_toward(speed, 0.0, d * 8.0)
				pz += speed * d
				py = maxf(0.0, py + vy * d)
				vy -= GRAVITY * d
				if py <= 0.0 and vy < 0:
					vy = 5.0 if speed < 1.0 else 0.0
				model.rotation.y = lerp_angle(model.rotation.y, PI if speed < 1.0 else 0.0, d * 4.0)
				_update_player_visual(d)
				_update_camera(d)
		S.ENDING:
			_update_ending(d)
		_:
			pass
	if toast_t <= 0:
		toast_label.text = ""

func _update_play(d: float) -> void:
	var acc := Input.is_action_pressed("accel") or touch.is_held("accel")
	var brk := Input.is_action_pressed("brake") or touch.is_held("brake")
	var vmax := SPEED_MAX_BOOTS if boots else SPEED_MAX
	match act:
		"run":
			if is_boss:
				speed = move_toward(speed, BOSS_SPEED, d * 8.0)
			elif acc:
				speed = minf(vmax, speed + d * 6.5)
			elif brk:
				speed = maxf(SPEED_MIN, speed - d * 11.0)
		"stumble":
			act_t -= d
			speed = move_toward(speed, 1.5, d * 30.0)
			if act_t <= 0:
				act = "run"
				speed = SPEED_MIN + 1.0
		"fall":
			act_t -= d
			speed = 0.0
			py = move_toward(py, -1.9, d * 5.0)
			if act_t <= 0:
				act = "run"
				pz = fall_resume_z
				py = 0.0
				vy = 0.0
				speed = SPEED_MIN
				invuln = 1.2
				px = _lx(lane)
				time_left -= 2.0
				_toast("-2 s", Color(1, 0.5, 0.4))
	pz += speed * d
	px = move_toward(px, _lx(lane), d * 13.0)
	# vertical
	jump_buf -= d
	if act == "stumble":
		vy -= GRAVITY * d
		py = maxf(0.0, py + vy * d)
	elif act == "run":
		if fly_t > 0:
			fly_t -= d
			py = move_toward(py, FLY_HEIGHT, d * 6.0)
			vy = 0.0
			if fly_t <= 0:
				_toast("A HÉLICE PAROU!", Color(1, 0.8, 0.4))
		else:
			if jump_buf > 0 and py <= 0.001:
				vy = JUMP_VELOCITY
				jump_buf = 0
				_sfx("jump")
			vy -= GRAVITY * d
			py += vy * d
			if py <= 0.0:
				py = 0.0
				vy = 0.0
	# timers
	invuln = maxf(0.0, invuln - d)
	magnet_t = maxf(0.0, magnet_t - d)
	star_t = maxf(0.0, star_t - d)
	combo_t -= d
	if combo_t <= 0:
		combo = 0
	shake = maxf(0.0, shake - d)
	if not is_boss:
		time_left -= d
		if time_left <= 10.0:
			beep_t -= d
			if beep_t <= 0:
				beep_t = 1.0
				_sfx("beep")
		if time_left <= 0:
			time_left = 0
			_lose_life("TEMPO ESGOTADO!")
			return
		# gerar fase à frente
		while spawn_z < pz + VIEW_AHEAD and spawn_z < stage_len - 22.0:
			spawn_z += _spawn_pattern(spawn_z)
		if spawn_z >= stage_len - 22.0 and spawn_z < stage_len:
			for i in range(5):
				_spawn_fish(_lx(i % 3 - 1), stage_len - 16.0 + i * 2.5)
			spawn_z = stage_len + 1.0
	else:
		_update_boss(d)
	_update_objects(d)
	if state != S.PLAY:
		return
	_recycle_props()
	_update_player_visual(d)
	_update_camera(d)
	_update_hud()
	if not is_boss and pz >= stage_len:
		_stage_clear()

func _recycle_props() -> void:
	for p in props:
		if p.position.z < pz - 14.0:
			p.position.z += props_span
	if far:
		far.position.z = pz
	if particles:
		particles.position = Vector3(px, 7.0, pz + 16.0)

func _grounded() -> bool:
	return py <= 0.01 and fly_t <= 0.0 and act == "run"

func _overlap(o: Dictionary) -> bool:
	return absf(px - float(o["x"])) < float(o["hx"]) + 0.42 and absf(pz - float(o["z"])) < float(o["hz"]) + 0.38 \
		and py < float(o["y1"]) and py + PLAYER_H > float(o["y0"])

func _over_hole(o: Dictionary) -> bool:
	return absf(px - float(o["x"])) < float(o["hx"]) and absf(pz - float(o["z"])) < float(o["hz"])

func _update_objects(d: float) -> void:
	var n_obj := objects.size()
	for i in range(n_obj):
		var o: Dictionary = objects[i]
		if o["done"]:
			continue
		var node: Node3D = o["node"]
		if not is_instance_valid(node):
			o["done"] = true
			continue
		o["t"] = float(o["t"]) + d
		var t: float = o["t"]
		var dz: float = float(o["z"]) - pz
		var kind: String = o["kind"]
		match kind:
			"fish", "gold":
				node.rotation.y = sin(t * 3.0) * 0.45
				node.rotation.z = sin(t * 6.0) * 0.08
				var by: float = o["base_y"]
				node.position.y = by + sin(t * 4.0) * 0.12
				if magnet_t > 0 and kind == "fish" and absf(dz) < 9.0:
					var target := Vector3(px, py + 0.8, pz + 0.3)
					node.position = node.position.move_toward(target, d * 16.0)
					o["x"] = node.position.x
					o["z"] = node.position.z
					o["base_y"] = node.position.y
				var fy := node.position.y
				var near := absf(px - node.position.x) < 1.0 and absf(pz - node.position.z) < 0.95
				if near and (fly_t > 0 or (fy > py - 0.3 and fy < py + PLAYER_H + 0.4)):
					o["done"] = true
					if kind == "gold":
						_throw_fish()
						_sfx("collect")
					else:
						_collect_fish()
			"power":
				node.rotate_y(d * 2.0)
				node.position.y = 1.0 + sin(t * 3.0) * 0.15
				var blade := node.get_node_or_null("Blade") as Node3D
				if blade:
					blade.rotate_y(d * 12.0)
				if _overlap(o) or (fly_t > 0 and absf(px - float(o["x"])) < 1.0 and absf(dz) < 1.0):
					o["done"] = true
					_get_power(o["ptype"])
			"block":
				if _overlap(o):
					_hit(o)
			"hole":
				if _grounded() and _over_hole(o):
					_fall(o)
			"gap":
				if _grounded() and absf(dz) < float(o["hz"]):
					_fall(o)
			"secret":
				node.rotate_y(d * 1.5)
				if _grounded() and _over_hole(o):
					o["done"] = true
					_secret()
			"seal":
				var seal: Node3D = o["seal"]
				var cyc := fmod(t, 2.8)
				var up := cyc < 1.3
				seal.position.y = move_toward(seal.position.y, 0.0 if up else -1.4, d * 6.0)
				if seal.position.y > -0.5:
					o["y1"] = 1.4
					if _overlap(o):
						_hit(o)
				elif _grounded() and _over_hole(o):
					_fall(o)
			"leapfish":
				if not o["on"] and dz < 16.0:
					o["on"] = true
					o["t"] = 0.0
					t = 0.0
				if o["on"]:
					var u := t / 1.3
					if u > 1.0:
						node.position.y = -2.0
					else:
						var dir: float = o["dir"]
						node.position.x = lerpf(-4.3, 4.3, u) * dir
						node.position.y = 0.2 + sin(u * PI) * 2.6
						node.rotation = Vector3((u - 0.5) * 1.6, -dir * PI * 0.5, 0)
						if absf(px - node.position.x) < 0.9 and absf(dz) < 1.0 and absf(node.position.y - (py + 0.8)) < 1.2:
							o["done"] = true
							_collect_fish(3)
							_toast("PEIXE VOADOR! +3", Color(0.5, 0.9, 1.0))
			"bat":
				var bx: float = o["base_x"]
				var nx := clampf(bx + sin(t * 1.4) * LANE_WIDTH * 0.75, -LANE_WIDTH, LANE_WIDTH)
				node.position.x = nx
				o["x"] = nx
				node.position.y = 1.35 + sin(t * 6.0) * 0.12
				for w in ["WingL", "WingR"]:
					var wn := node.get_node_or_null(w) as Node3D
					if wn:
						wn.rotation.z = sin(t * 18.0) * 0.6 * (1.0 if w == "WingL" else -1.0)
				if _overlap(o):
					_hit(o)
			"stalactite":
				var rock: Node3D = o["rock"]
				if not o["on"] and dz < 15.0:
					o["on"] = true
				if o["on"] and float(o["ry"]) > 0.0:
					o["vy"] = float(o["vy"]) - 20.0 * d
					o["ry"] = maxf(0.0, float(o["ry"]) + float(o["vy"]) * d)
					if float(o["ry"]) <= 0.0:
						shake = maxf(shake, 0.15)
				var ry: float = o["ry"]
				rock.position.y = ry
				var sh: Node3D = o["shadow"]
				sh.scale = Vector3.ONE * lerpf(1.2, 0.4, clampf(ry / 8.5, 0, 1))
				o["y0"] = ry
				o["y1"] = ry + 1.8
				if ry < 8.0 and _overlap(o):
					_hit(o)
			"bird":
				if dz < 26.0:
					o["on"] = true
				if o["on"]:
					o["ry"] = move_toward(float(o["ry"]), 1.2, d * 4.0)
					o["z"] = float(o["z"]) - d * 3.5
				var ry: float = o["ry"]
				node.position = Vector3(float(o["x"]), ry + sin(t * 5.0) * 0.1, float(o["z"]))
				for w in ["WingL", "WingR"]:
					var wn := node.get_node_or_null(w) as Node3D
					if wn:
						wn.rotation.z = sin(t * 14.0) * 0.5 * (1.0 if w == "WingL" else -1.0)
				o["y0"] = ry - 0.3
				o["y1"] = ry + 0.35
				if _overlap(o):
					_hit(o)
			"dino":
				var dir: float = o["dir"]
				var nx := float(o["x"]) + dir * d * 1.8
				if absf(nx) > LANE_WIDTH + 0.3:
					dir = -dir
					o["dir"] = dir
					nx = clampf(nx, -LANE_WIDTH - 0.3, LANE_WIDTH + 0.3)
				o["x"] = nx
				node.position.x = nx
				node.rotation.y = lerp_angle(node.rotation.y, -dir * PI * 0.5, d * 6.0)
				node.position.y = absf(sin(t * 8.0)) * 0.12
				if _overlap(o):
					_hit(o)
			"ghost":
				var bx: float = o["base_x"]
				node.position.x = bx + sin(t * 0.9) * 0.9
				o["x"] = node.position.x
				node.position.y = sin(t * 2.0) * 0.15
				var vis := 0.5 + 0.5 * sin(t * 2.2)
				var body := node.get_node("Body") as MeshInstance3D
				var gm := body.material_override as StandardMaterial3D
				gm.albedo_color.a = 0.12 + vis * 0.7
				if vis > 0.4 and _overlap(o):
					_hit(o)
			"bounce":
				if _grounded() and _overlap(o):
					vy = 14.0
					py = 0.02
					score += 50
					_sfx("bounce")
					node.scale = Vector3(1.3, 0.6, 1.3)
				node.scale = node.scale.lerp(Vector3.ONE, d * 6.0)
			"proj":
				o["z"] = float(o["z"]) + float(o["vz"]) * d
				node.position.z = o["z"]
				if o.get("roll", false) and node.get_child_count() > 0:
					(node.get_child(0) as Node3D).rotation.x -= d * 6.0
				if o.get("pkind", "") == "bat":
					for w in ["WingL", "WingR"]:
						var wn := node.get_node_or_null(w) as Node3D
						if wn:
							wn.rotation.z = sin(t * 18.0) * 0.6 * (1.0 if w == "WingL" else -1.0)
				if _overlap(o):
					o["done"] = true
					_hit(o)
			"shot":
				if boss == null or boss_dead:
					o["done"] = true
				else:
					var target := boss.position + Vector3(0, 2.2, 0)
					node.position = node.position.move_toward(target, d * 34.0)
					node.rotation = Vector3(0, PI + sin(t * 30.0) * 0.35, 0)
					o["z"] = node.position.z
					if node.position.distance_to(target) < 1.2:
						o["done"] = true
						_boss_hit()
		if float(o["z"]) - pz < -12.0:
			o["done"] = true
		if o["done"] and is_instance_valid(node):
			node.queue_free()
	objects = objects.filter(func(x): return not x["done"])

# ================================================================ EVENTOS
func _collect_fish(amount: int = 1) -> void:
	fish += amount
	stage_fish += amount
	combo += 1
	combo_t = 1.3
	var bonus := 100 * mini(combo, 5) * amount
	score += bonus
	_sfx("collect")
	if combo >= 3:
		_toast("COMBO ×%d  +%d" % [combo, bonus], Color(1.0, 0.9, 0.4))

func _get_power(ptype: String) -> void:
	_sfx("powerup")
	score += 200
	match ptype:
		"propeller":
			propellers += 1
			_toast("HÉLICE! (aperte E / ITEM para voar)", Color(1, 0.75, 0.3))
		"clock":
			time_left += 10.0
			_toast("+10 SEGUNDOS!", Color(0.5, 1.0, 0.6))
		"magnet":
			magnet_t = 8.0
			_toast("ÍMÃ DE PEIXES!", Color(1, 0.5, 0.5))
		"star":
			star_t = 6.0
			_toast("ESTRELA DE GELO! INVENCÍVEL!", Color(1, 1, 0.4))

func _use_item() -> void:
	if state != S.PLAY or act != "run" or fly_t > 0:
		return
	if propellers <= 0:
		_toast("SEM HÉLICE — compre na loja!", Color(1, 0.6, 0.5))
		return
	propellers -= 1
	fly_t = 5.0
	_sfx("propeller")
	_toast("VOANDO!", Color(1, 0.8, 0.3))

func _secret() -> void:
	_sfx("secret")
	fish += 20
	stage_fish += 20
	time_left += 10.0
	score += 2000
	_toast("TOCA SECRETA!  +20 🐟  +10 s  +2000", Color(1, 0.6, 1.0))

func _hit(o: Dictionary) -> void:
	if invuln > 0 or act != "run" or state != S.PLAY:
		return
	if star_t > 0:
		o["done"] = true
		score += 150
		_sfx("hit")
		_toast("CRASH! +150", Color(1, 1, 0.5))
		return
	if helmet:
		helmet = false
		invuln = 1.2
		_sfx("hit")
		shake = 0.3
		_toast("O CAPACETE PROTEGEU!", Color(1, 0.9, 0.3))
		return
	_sfx("stumble")
	shake = 0.45
	combo = 0
	if is_boss:
		hearts -= 1
		if hearts <= 0:
			_lose_life("O PIPO FOI NOCAUTEADO!")
			return
	act = "stumble"
	act_t = 0.7
	invuln = 1.7
	vy = 0.0

func _fall(o: Dictionary) -> void:
	if invuln > 0 or star_t > 0 or act != "run":
		return
	act = "fall"
	act_t = 1.15
	fall_resume_z = float(o["z"]) + float(o["hz"]) + 1.0
	px = clampf(px, float(o["x"]) - float(o["hx"]) + 0.1, float(o["x"]) + float(o["hx"]) - 0.1) if o["kind"] != "gap" else px
	_sfx("splash" if theme == "sea" else "fall")
	combo = 0
	shake = 0.2

func _lose_life(msg: String) -> void:
	lives -= 1
	state = S.DYING
	state_t = 2.2
	center_label.text = msg
	sub_label.text = "" if lives <= 0 else "Restam %d Pipos" % lives
	_music("")
	_sfx("hit")
	touch.release_all()

func _stage_clear() -> void:
	state = S.CLEAR
	state_t = 2.0
	vy = 6.0
	_music("")
	_sfx("stage_clear")
	center_label.text = "FASE COMPLETA!"
	touch.release_all()
	await get_tree().create_timer(1.6).timeout
	if state == S.CLEAR and panel == null:
		_show_clear_panel()

func _show_clear_panel() -> void:
	center_label.text = ""
	var time_bonus := int(time_left) * 50 if not is_boss else 0
	var fish_bonus := stage_fish * 20
	var boss_bonus := 5000 * (world + 1) if is_boss else 0
	var heart_bonus := hearts * 1000 if is_boss else 0
	score += time_bonus + fish_bonus + boss_bonus + heart_bonus
	boots = false
	if is_boss:
		best_world = maxi(best_world, mini(world + 1, WORLDS.size() - 1))
	_save()
	var vb := _make_panel(620, 420)
	_center_text(vb, "CHEFE DERROTADO!" if is_boss else "FASE COMPLETA!", 42, Color(1, 0.9, 0.3))
	if is_boss:
		_center_text(vb, "Bônus do chefe ......... %d" % boss_bonus, 24)
		_center_text(vb, "Corações restantes ..... %d" % heart_bonus, 24)
	else:
		_center_text(vb, "Tempo restante ......... %d" % time_bonus, 24)
	_center_text(vb, "Peixes na fase ......... %d" % fish_bonus, 24)
	_center_text(vb, "PONTUAÇÃO  %07d" % score, 30, Color(0.6, 1, 0.8))
	var b: Button
	if is_boss and world == WORLDS.size() - 1:
		b = _btn(vb, "PEGAR A MAÇÃ DOURADA ▶", _start_ending)
	else:
		b = _btn(vb, "IR PARA A LOJA ▶", _show_shop)
	_set_hud_mode(false)
	b.grab_focus()

# ---------------------------------------------------------------- loja
func _next_stage() -> void:
	if stage < 2:
		_start_stage(world, stage + 1)
	else:
		_start_stage(world + 1, 0)

func _show_shop() -> void:
	state = S.SHOP
	_set_hud_mode(false)
	center_label.text = ""
	sub_label.text = ""
	_music("shop")
	_build_shop()

func _owned_text(id: String) -> String:
	match id:
		"propeller": return "você tem %d" % propellers
		"helmet": return "equipado" if helmet else ""
		"boots": return "equipadas" if boots else ""
		"lantern": return "já tem" if lantern else ""
		"clock": return "+%d s guardados" % clock_bonus if clock_bonus > 0 else ""
		"life": return "%d vidas" % lives
	return ""

func _build_shop(focus_index: int = 0) -> void:
	var vb := _make_panel(900, 660)
	_center_text(vb, "LOJA DO TIO MORSA", 40, Color(1, 0.9, 0.3))
	var next_name := ""
	if stage < 2:
		next_name = "Próxima: MUNDO %d-%s" % [world + 1, "CHEFE" if stage + 1 == 2 else str(stage + 2)]
	else:
		next_name = "Próxima: MUNDO %d-1  %s" % [world + 2, WORLDS[world + 1]["name"]]
	_center_text(vb, "\"Peixe fresco é a única moeda que eu aceito!\"   🐟 ×%d\n%s" % [fish, next_name], 20, Color(0.85, 0.95, 1.0))
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 16)
	grid.add_theme_constant_override("v_separation", 6)
	vb.add_child(grid)
	var buttons: Array[Button] = []
	for i in range(SHOP_ITEMS.size()):
		var it: Dictionary = SHOP_ITEMS[i]
		var id: String = it["id"]
		var name_l := _label(it["name"], 24, Color(1, 1, 1), grid)
		name_l.custom_minimum_size = Vector2(170, 0)
		var info := _label("%s\n%s" % [it["desc"], _owned_text(id)], 16, Color(0.8, 0.9, 1.0), grid)
		info.custom_minimum_size = Vector2(440, 0)
		info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		var price: int = _price(it)
		var b := _btn(grid, "%d 🐟" % price, func(): _buy(id, price, i), 22)
		b.custom_minimum_size = Vector2(160, 48)
		var unavailable := (id == "helmet" and helmet) or (id == "boots" and boots) or (id == "lantern" and lantern) or (id == "life" and lives >= 9) or (id == "propeller" and propellers >= 5)
		b.disabled = fish < price or unavailable
		buttons.append(b)
	var cont := _btn(vb, "CONTINUAR A AVENTURA ▶", _next_stage)
	buttons.append(cont)
	var idx := clampi(focus_index, 0, buttons.size() - 1)
	if buttons[idx].disabled:
		idx = buttons.size() - 1
	buttons[idx].grab_focus()

func _price(it: Dictionary) -> int:
	var base: int = it["price"]
	if it["id"] == "lantern":
		return base
	return int(round(base * (1.0 + world * 0.45)))

func _buy(id: String, price: int, idx: int) -> void:
	if fish < price:
		return
	fish -= price
	_sfx("buy")
	match id:
		"propeller": propellers += 1
		"helmet": helmet = true
		"boots": boots = true
		"lantern": lantern = true
		"clock": clock_bonus += 20
		"life": lives += 1
	_build_shop(idx)

func _game_over() -> void:
	state = S.GAMEOVER
	_save()
	_music("")
	_sfx("game_over")
	center_label.text = ""
	sub_label.text = ""
	_set_hud_mode(false)
	var vb := _make_panel(560, 420)
	_center_text(vb, "FIM DE JOGO", 48, Color(1, 0.4, 0.4))
	_center_text(vb, "PONTUAÇÃO  %07d\nRECORDE  %07d" % [score, hiscore], 26)
	var b := _btn(vb, "CONTINUAR NO MUNDO %d" % (world + 1), func(): _new_game(world))
	_btn(vb, "MENU PRINCIPAL", _show_title)
	b.grab_focus()

# ---------------------------------------------------------------- final
var ending_root: Node3D
var ending_apple: Node3D
var ending_princess: Node3D
var ending_lines: Array[String] = []
var ending_step := 0

func _start_ending() -> void:
	state = S.ENDING
	_clear_panel()
	_set_hud_mode(false)
	is_boss = false
	_build_level("aurora")
	stage_len = 300.0
	pz = 0.0
	_finish_level_build()
	_music("ending")
	ending_root = Node3D.new()
	level.add_child(ending_root)
	B.make_castle(ending_root, Vector3(0, 0, 42))
	ending_princess = B.make_princess(ending_root, Vector3(0, 0, 8), pipo_mesh)
	ending_princess.rotation_degrees.y = 180
	ending_apple = B.make_golden_apple(ending_root, Vector3(0, 2.6, 0))
	var glow := OmniLight3D.new()
	glow.light_color = Color(1, 0.8, 0.3)
	glow.light_energy = 2.0
	glow.omni_range = 6.0
	ending_apple.add_child(glow)
	player.visible = true
	model.visible = true
	model.rotation = Vector3.ZERO
	hat.visible = false
	px = 0
	py = 0
	pz = -6.0
	state_t = 0.0
	ending_step = 0
	ending_lines = [
		"Pipo atravessou os cinco mundos...",
		"...e trouxe a Maçã Dourada para o Castelo da Aurora!",
		"A Princesa Penélope provou a maçã e ficou curadinha!",
		"Mas lá longe, no gelo, algo novo começa a se mexer...",
		"OBRIGADO POR JOGAR!",
	]
	center_label.text = ""
	sub_label.text = ""
	_save()

func _update_ending(d: float) -> void:
	state_t += d
	pz = minf(6.4, pz + d * 2.2)
	player.position = Vector3(0, absf(sin(state_t * 8.0)) * 0.06 if pz < 6.4 else 0.0, pz)
	model.rotation.x = 0
	model.rotation.z = sin(state_t * 8.0) * 0.08 if pz < 6.4 else 0.0
	camera.position = Vector3(5.2, 2.3, 0.5 + minf(state_t, 6.0) * 0.35)
	camera.look_at(Vector3(0, 1.7, 9.0), Vector3.UP)
	camera.fov = 50
	if particles:
		particles.position = Vector3(0, 7, 6)
	# a maçã flutua do Pipo para a princesa
	if state_t < 5.0:
		ending_apple.position = Vector3(0, 2.5 + sin(state_t * 3.0) * 0.1, pz + 0.2)
	else:
		var u := clampf((state_t - 5.0) / 2.0, 0, 1)
		ending_apple.position = Vector3(0, 2.5 + sin(u * PI) * 1.0 - u * 0.4, lerpf(6.6, 7.6, u))
	ending_apple.rotate_y(d * 2.0)
	if state_t > 7.5:
		ending_princess.position.y = absf(sin(state_t * 6.0)) * 0.3
		ending_princess.rotation_degrees.y = 180 + sin(state_t * 4.0) * 15
		if state_t > 7.6 and ending_apple.visible:
			ending_apple.visible = false
			_sfx("secret")
	var step := int(state_t / 3.2)
	if step != ending_step and step <= ending_lines.size():
		ending_step = step
	if ending_step >= 1 and ending_step <= ending_lines.size():
		sub_label.text = ending_lines[ending_step - 1]
	if ending_step == ending_lines.size() and panel == null and state_t > ending_lines.size() * 3.2 + 1.0:
		var vb := _make_panel(620, 330)
		_center_text(vb, "FIM", 60, Color(1, 0.9, 0.3))
		_center_text(vb, "PONTUAÇÃO FINAL  %07d\nRECORDE  %07d" % [score, hiscore], 26)
		var b := _btn(vb, "MENU PRINCIPAL", _show_title)
		b.grab_focus()

# ================================================================ VISUAL
func _update_player_visual(d: float) -> void:
	player.position = Vector3(px, maxf(py, -2.5), pz)
	var target_x := _lx(lane)
	var lean := clampf((px - target_x) * 0.12, -0.25, 0.25)
	if act == "stumble":
		model.rotation.y += d * 18.0
		model.rotation.x = lerpf(model.rotation.x, -0.3, d * 8.0)
	elif act == "fall":
		model.rotation.x = lerpf(model.rotation.x, 0.6, d * 6.0)
	else:
		model.rotation.y = lerp_angle(model.rotation.y, 0.0, d * 10.0)
		var forward := 0.06 + clampf((speed - SPEED_MIN) / 14.0, 0, 1) * 0.16
		if py > 0.05 and fly_t <= 0:
			forward -= 0.15
		model.rotation.x = lerpf(model.rotation.x, forward, d * 5.0)
		model.rotation.z = lerpf(model.rotation.z, lean, d * 8.0)
	var ski_phase := sin(anim_t * 12.0)
	for i in range(skis.size()):
		skis[i].rotation.y = ski_phase * 0.035 * (1.0 if i == 0 else -1.0)
		skis[i].visible = fly_t <= 0
	hat.visible = fly_t > 0
	if hat.visible:
		(hat.get_node("Blade") as Node3D).rotate_y(d * 30.0)
	helmet_node.visible = helmet
	# piscando quando invulnerável / arco-íris com a estrela
	model.visible = not (invuln > 0 and act == "run" and int(invuln * 12.0) % 2 == 0)
	if star_t > 0:
		model_mat.emission_enabled = true
		model_mat.emission = Color.from_hsv(fmod(anim_t * 1.5, 1.0), 0.8, 1.0)
		model_mat.emission_energy_multiplier = 0.6
	elif model_mat.emission_enabled:
		model_mat.emission_enabled = false

func _update_camera(d: float, snap: bool = false) -> void:
	var target: Vector3
	var look: Vector3
	if is_boss:
		target = Vector3(px * 0.3, 3.5 + py * 0.3, pz - 5.0)
		look = Vector3(px * 0.2, 1.5, pz + 10.0)
	else:
		target = Vector3(px * 0.4, 3.0 + py * 0.35, pz - 4.3 - speed * 0.05)
		look = Vector3(px * 0.35, 0.9 + py * 0.4, pz + 7.0)
	if py < -0.2:
		look.y = 0.3
	if snap:
		camera.position = target
	else:
		camera.position = camera.position.lerp(target, clampf(d * 5.0, 0, 1))
		camera.position.z = target.z
	camera.look_at(look, Vector3.UP)
	if shake > 0:
		camera.position += Vector3(randf_range(-1, 1), randf_range(-1, 1), 0) * shake * 0.25
	var fov_t := 58.0 + clampf(speed - SPEED_START, -4, 10) * 1.3
	camera.fov = lerpf(camera.fov, fov_t, clampf(d * 3.0, 0, 1)) if not snap else fov_t

# ================================================================ ENTRADA
func _on_touch(action: String) -> void:
	_do_action(action)

func _do_action(action: String) -> void:
	if paused or state != S.PLAY:
		return
	match action:
		"left":
			if act != "fall":
				lane = clampi(lane + 1, -1, 1)
		"right":
			if act != "fall":
				lane = clampi(lane - 1, -1, 1)
		"jump":
			jump_buf = 0.15
		"item":
			_use_item()

func _unhandled_input(event: InputEvent) -> void:
	if event.is_echo():
		return
	if event.is_action_pressed("toggle_touch"):
		var cur := touch.visible
		touch_forced = 0 if cur else 1
		_set_hud_mode(state == S.PLAY or state == S.INTRO)
		return
	if event.is_action_pressed("pause"):
		if state == S.PLAY or state == S.INTRO:
			_toggle_pause()
			get_viewport().set_input_as_handled()
		return
	for a in ["left", "right", "jump", "item"]:
		if event.is_action_pressed(a):
			_do_action(a)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
		if (state == S.PLAY or state == S.INTRO) and not paused:
			_toggle_pause()

func _toggle_pause() -> void:
	if not (state == S.PLAY or state == S.INTRO):
		return
	paused = not paused
	touch.release_all()
	if paused:
		music.stream_paused = true
		var vb := _make_panel(480, 360)
		_center_text(vb, "PAUSADO", 46, Color(1, 0.9, 0.3))
		var b := _btn(vb, "CONTINUAR", _toggle_pause)
		_btn(vb, "REINICIAR FASE", func():
			paused = false
			music.stream_paused = false
			_start_stage(world, stage))
		_btn(vb, "MENU PRINCIPAL", func():
			paused = false
			music.stream_paused = false
			_save()
			_show_title())
		b.grab_focus()
	else:
		music.stream_paused = false
		_clear_panel()

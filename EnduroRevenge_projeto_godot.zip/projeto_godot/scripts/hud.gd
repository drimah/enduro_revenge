extends CanvasLayer
## Interface: painel de instrumentos, mensagens, menu, pausa e fim de jogo.

const ORANGE := Color(1.0, 0.55, 0.12)
const TOXIC := Color(0.62, 1.0, 0.22)
const RED := Color(1.0, 0.25, 0.2)
const WHITE := Color(0.95, 0.92, 0.85)

var root: Control
var hud_box: Control
var lbl_day: Label
var lbl_phase: Label
var lbl_record: Label
var lbl_pad: Label
var lbl_speed: Label
var lbl_gear: Label
var lbl_odo: Label
var lbl_cars: Label
var lbl_cars_t: Label
var nitro_bar: ProgressBar
var day_bar: ProgressBar
var lbl_msg: Label
var lbl_sub: Label
var overlay: Control
var dim: ColorRect
var ov_box: VBoxContainer
var _msg_left := 0.0
var _blink: Array = []
var _t := 0.0
var _danger := false


func _ready() -> void:
	layer = 10
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Impact", "Arial Black", "DejaVu Sans", "Liberation Sans", "Noto Sans", "Sans-Serif"])
	font.font_weight = 800
	var theme := Theme.new()
	theme.default_font = font
	root = Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = theme
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_hud()
	_build_overlay()


func _lbl(parent: Node, text: String, size: int, color: Color, align := HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = align
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", maxi(4, size / 7))
	parent.add_child(l)
	return l


func _style(bg: Color, border: Color, bw: int, radius: int) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(bw)
	sb.set_corner_radius_all(radius)
	sb.content_margin_left = 22
	sb.content_margin_right = 22
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	return sb


func _bar(parent: Node, fill: Color, min_size: Vector2) -> ProgressBar:
	var pb := ProgressBar.new()
	pb.show_percentage = false
	pb.min_value = 0.0
	pb.max_value = 1.0
	pb.step = 0.0
	pb.custom_minimum_size = min_size
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.08, 0.06, 0.05, 0.85)
	bg.border_color = Color(0.4, 0.3, 0.2)
	bg.set_border_width_all(2)
	bg.set_corner_radius_all(4)
	var fg := StyleBoxFlat.new()
	fg.bg_color = fill
	fg.set_corner_radius_all(3)
	pb.add_theme_stylebox_override("background", bg)
	pb.add_theme_stylebox_override("fill", fg)
	pb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(pb)
	return pb


func _col(parent: Node, title: String) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", -4)
	parent.add_child(v)
	_lbl(v, title, 15, Color(0.75, 0.65, 0.5), HORIZONTAL_ALIGNMENT_CENTER)
	return v


func _build_hud() -> void:
	hud_box = Control.new()
	hud_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hud_box)
	hud_box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var tl := VBoxContainer.new()
	tl.position = Vector2(28, 14)
	tl.add_theme_constant_override("separation", -6)
	hud_box.add_child(tl)
	lbl_day = _lbl(tl, "DIA 1", 46, ORANGE)
	lbl_phase = _lbl(tl, "", 22, WHITE)

	var tr := VBoxContainer.new()
	hud_box.add_child(tr)
	tr.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	tr.offset_left = -460
	tr.offset_right = -28
	tr.offset_top = 18
	lbl_record = _lbl(tr, "", 20, TOXIC, HORIZONTAL_ALIGNMENT_RIGHT)
	lbl_pad = _lbl(tr, "", 16, WHITE, HORIZONTAL_ALIGNMENT_RIGHT)

	day_bar = _bar(hud_box, ORANGE, Vector2(0, 12))
	day_bar.set_anchors_preset(Control.PRESET_CENTER_TOP)
	day_bar.offset_left = -240
	day_bar.offset_right = 240
	day_bar.offset_top = 30
	day_bar.offset_bottom = 42
	var dl := _lbl(hud_box, "FIM DO DIA", 13, Color(0.8, 0.7, 0.55), HORIZONTAL_ALIGNMENT_CENTER)
	dl.set_anchors_preset(Control.PRESET_CENTER_TOP)
	dl.offset_left = -240
	dl.offset_right = 240
	dl.offset_top = 10

	var panel := PanelContainer.new()
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_box.add_child(panel)
	panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	panel.offset_left = -500
	panel.offset_right = 500
	panel.offset_top = -126
	panel.offset_bottom = -16
	panel.add_theme_stylebox_override("panel", _style(Color(0.05, 0.04, 0.03, 0.8), ORANGE, 3, 12))
	var hb := HBoxContainer.new()
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_theme_constant_override("separation", 44)
	panel.add_child(hb)
	var c1 := _col(hb, "VELOCIDADE")
	lbl_speed = _lbl(c1, "0 KM/H", 46, WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_speed.custom_minimum_size = Vector2(190, 0)
	var c1b := _col(hb, "MARCHA")
	lbl_gear = _lbl(c1b, "1", 46, ORANGE, HORIZONTAL_ALIGNMENT_CENTER)
	var c2 := _col(hb, "HODÔMETRO")
	lbl_odo = _lbl(c2, "0000.0 KM", 40, WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_odo.custom_minimum_size = Vector2(200, 0)
	var c3 := _col(hb, "CARROS A PASSAR")
	lbl_cars_t = c3.get_child(0)
	lbl_cars = _lbl(c3, "70", 46, ORANGE, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_cars.custom_minimum_size = Vector2(150, 0)
	var c4 := _col(hb, "NITRO")
	nitro_bar = _bar(c4, Color(0.3, 0.65, 1.0), Vector2(150, 22))

	lbl_msg = _lbl(root, "", 86, ORANGE, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_msg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	lbl_msg.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lbl_msg.offset_top = -170
	lbl_msg.offset_bottom = -170
	lbl_sub = _lbl(root, "", 30, WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_sub.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	lbl_sub.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	lbl_sub.offset_top = -95
	lbl_sub.offset_bottom = -95


func _build_overlay() -> void:
	overlay = Control.new()
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(overlay)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.5)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ov_box = VBoxContainer.new()
	ov_box.alignment = BoxContainer.ALIGNMENT_CENTER
	ov_box.add_theme_constant_override("separation", 6)
	cc.add_child(ov_box)


func _clear_ov() -> void:
	for c in ov_box.get_children():
		c.queue_free()
	_blink.clear()


func _spacer(h: int) -> void:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	ov_box.add_child(c)


# ---------------------------------------------------------------- telas
func show_menu(record_km: float, record_day: int) -> void:
	_clear_ov()
	dim.color = Color(0, 0, 0, 0.35)
	_lbl(ov_box, "ENDURO", 136, ORANGE, HORIZONTAL_ALIGNMENT_CENTER)
	_lbl(ov_box, "R  E  V  E  N  G  E", 50, TOXIC, HORIZONTAL_ALIGNMENT_CENTER)
	_lbl(ov_box, "Sobreviva às estradas do fim do mundo. Ultrapasse os carros antes que o dia acabe.", 22, WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	_spacer(22)
	_lbl(ov_box, "TECLADO:  W/↑ acelera  ·  S/↓ freia  ·  A D/← → direção  ·  SHIFT nitro  ·  ESC pausa", 19, Color(0.85, 0.8, 0.7), HORIZONTAL_ALIGNMENT_CENTER)
	_lbl(ov_box, "JOYSTICK:  RT ou A acelera  ·  LT ou B freia  ·  analógico/D-pad direção  ·  RB, X ou Y nitro  ·  START pausa", 19, Color(0.85, 0.8, 0.7), HORIZONTAL_ALIGNMENT_CENTER)
	_lbl(ov_box, "M liga/desliga a música  ·  F11 tela cheia", 17, Color(0.7, 0.65, 0.55), HORIZONTAL_ALIGNMENT_CENTER)
	_spacer(18)
	if record_km > 0.0:
		_lbl(ov_box, "RECORDE: %.1f KM  ·  DIA %d" % [record_km, record_day], 26, TOXIC, HORIZONTAL_ALIGNMENT_CENTER)
	_spacer(8)
	_blink.append(_lbl(ov_box, "PRESSIONE ENTER OU START", 38, ORANGE, HORIZONTAL_ALIGNMENT_CENTER))
	overlay.visible = true
	hud_box.visible = false


func show_pause() -> void:
	_clear_ov()
	dim.color = Color(0, 0, 0, 0.6)
	_lbl(ov_box, "PAUSA", 110, ORANGE, HORIZONTAL_ALIGNMENT_CENTER)
	_spacer(14)
	_lbl(ov_box, "ESC / START  continuar", 28, WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	_lbl(ov_box, "Q / BACKSPACE / Y  voltar ao menu", 28, WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	overlay.visible = true


func show_gameover(day: int, km: float, passed: int, is_record: bool) -> void:
	_clear_ov()
	dim.color = Color(0.15, 0, 0, 0.55)
	_lbl(ov_box, "FIM DA ESTRADA", 100, RED, HORIZONTAL_ALIGNMENT_CENTER)
	_lbl(ov_box, "Você não ultrapassou carros suficientes antes do anoitecer eterno.", 22, WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	_spacer(16)
	_lbl(ov_box, "DIA ALCANÇADO: %d" % day, 34, ORANGE, HORIZONTAL_ALIGNMENT_CENTER)
	_lbl(ov_box, "DISTÂNCIA: %.1f KM" % km, 34, ORANGE, HORIZONTAL_ALIGNMENT_CENTER)
	_lbl(ov_box, "CARROS ULTRAPASSADOS: %d" % passed, 34, ORANGE, HORIZONTAL_ALIGNMENT_CENTER)
	if is_record:
		_blink.append(_lbl(ov_box, "NOVO RECORDE!", 40, TOXIC, HORIZONTAL_ALIGNMENT_CENTER))
	_spacer(18)
	_blink.append(_lbl(ov_box, "ENTER / START  correr de novo   ·   Q / Y  menu", 28, WHITE, HORIZONTAL_ALIGNMENT_CENTER))
	overlay.visible = true
	hud_box.visible = true


func hide_overlay() -> void:
	overlay.visible = false
	hud_box.visible = true
	_blink.clear()


func show_message(text: String, sub := "", color := ORANGE, dur := 2.5) -> void:
	lbl_msg.text = text
	lbl_msg.add_theme_color_override("font_color", color)
	lbl_sub.text = sub
	lbl_msg.modulate.a = 1.0
	lbl_sub.modulate.a = 1.0
	_msg_left = dur


func set_record(km: float, day: int) -> void:
	lbl_record.text = "RECORDE %.1f KM · DIA %d" % [km, day] if km > 0.0 else ""


func set_pad(text: String) -> void:
	lbl_pad.text = text


func update_stats(kmh: float, gear: int, km: float, cars_left: int, quota_met: bool, day: int, phase: String, day_t: float, nitro: float, nitro_on: bool, danger: bool) -> void:
	lbl_speed.text = "%d KM/H" % int(kmh)
	lbl_gear.text = str(gear)
	lbl_odo.text = "%06.1f KM" % km
	lbl_day.text = "DIA %d" % day
	lbl_phase.text = phase
	day_bar.value = day_t
	nitro_bar.value = nitro
	nitro_bar.modulate = Color(1.6, 1.6, 2.0) if nitro_on else Color.WHITE
	_danger = danger
	if quota_met:
		lbl_cars_t.text = "META DO DIA"
		lbl_cars.text = "OK!"
		lbl_cars.add_theme_color_override("font_color", TOXIC)
	else:
		lbl_cars_t.text = "CARROS A PASSAR"
		lbl_cars.text = str(cars_left)
		lbl_cars.add_theme_color_override("font_color", RED if danger else ORANGE)


func _process(delta: float) -> void:
	_t += delta
	var on := fmod(_t, 1.0) < 0.65
	for l in _blink:
		if is_instance_valid(l):
			l.modulate.a = 1.0 if on else 0.25
	if _danger:
		lbl_cars.modulate.a = 1.0 if fmod(_t, 0.5) < 0.3 else 0.35
	else:
		lbl_cars.modulate.a = 1.0
	if _msg_left > 0.0:
		_msg_left -= delta
		var a := clampf(_msg_left / 0.5, 0.0, 1.0)
		lbl_msg.modulate.a = a
		lbl_sub.modulate.a = a

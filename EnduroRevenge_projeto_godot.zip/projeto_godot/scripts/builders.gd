extends RefCounted
## Fabrica de modelos 3D low-poly gerados por codigo (sem arquivos externos).
## Todos os materiais usam o shader do mundo, que curva a geometria junto com a pista.

const WORLD_SHADER := preload("res://shaders/world.gdshader")
const CULL_MARGIN := 400.0

static var _mats := {}
static var _meshes := {}


# ---------------------------------------------------------------- materiais
static func mat(c: Color, rough := 0.85, metal := 0.0, rust := 0.0, emis := Color(0, 0, 0), emis_e := 0.0) -> ShaderMaterial:
	var key := "%s|%.2f|%.2f|%.2f|%s|%.2f" % [c.to_html(), rough, metal, rust, emis.to_html(), emis_e]
	if _mats.has(key):
		return _mats[key]
	var m := ShaderMaterial.new()
	m.shader = WORLD_SHADER
	m.set_shader_parameter("albedo", c)
	m.set_shader_parameter("roughness", rough)
	m.set_shader_parameter("metallic", metal)
	m.set_shader_parameter("rust", rust)
	m.set_shader_parameter("emission", emis)
	m.set_shader_parameter("emission_energy", emis_e)
	_mats[key] = m
	return m


static func glow(c: Color, energy := 4.0) -> ShaderMaterial:
	return mat(c, 0.4, 0.0, 0.0, c, energy)


# ---------------------------------------------------------------- primitivas
static func _add(parent: Node3D, mesh: Mesh, pos: Vector3, m: Material, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = m
	mi.position = pos
	mi.rotation_degrees = rot
	mi.extra_cull_margin = CULL_MARGIN
	mi.name = "Peca"
	parent.add_child(mi, true)
	return mi


static func box(parent: Node3D, size: Vector3, pos: Vector3, m: Material, rot := Vector3.ZERO) -> MeshInstance3D:
	var key := "b%s" % size
	if not _meshes.has(key):
		var bm := BoxMesh.new()
		bm.size = size
		_meshes[key] = bm
	return _add(parent, _meshes[key], pos, m, rot)


static func cyl(parent: Node3D, r_top: float, r_bot: float, h: float, pos: Vector3, m: Material, rot := Vector3.ZERO, segs := 10) -> MeshInstance3D:
	var key := "c%.3f|%.3f|%.3f|%d" % [r_top, r_bot, h, segs]
	if not _meshes.has(key):
		var cm := CylinderMesh.new()
		cm.top_radius = r_top
		cm.bottom_radius = r_bot
		cm.height = h
		cm.radial_segments = segs
		cm.rings = 1
		_meshes[key] = cm
	return _add(parent, _meshes[key], pos, m, rot)


static func ball(parent: Node3D, r: float, pos: Vector3, m: Material, scale := Vector3.ONE, segs := 8) -> MeshInstance3D:
	var key := "s%.3f|%d" % [r, segs]
	if not _meshes.has(key):
		var sm := SphereMesh.new()
		sm.radius = r
		sm.height = r * 2.0
		sm.radial_segments = segs
		sm.rings = maxi(3, segs / 2)
		_meshes[key] = sm
	var mi := _add(parent, _meshes[key], pos, m)
	mi.scale = scale
	return mi


static func torus(parent: Node3D, r_in: float, r_out: float, pos: Vector3, m: Material, rot := Vector3.ZERO) -> MeshInstance3D:
	var key := "t%.3f|%.3f" % [r_in, r_out]
	if not _meshes.has(key):
		var tm := TorusMesh.new()
		tm.inner_radius = r_in
		tm.outer_radius = r_out
		tm.rings = 14
		tm.ring_segments = 6
		_meshes[key] = tm
	return _add(parent, _meshes[key], pos, m, rot)


static func wheel(parent: Node3D, pos: Vector3, r: float, w: float) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = pos
	pivot.name = "Roda"
	pivot.add_to_group("rodas", true)
	parent.add_child(pivot, true)
	var tire := mat(Color(0.045, 0.04, 0.04), 0.95)
	var hub := mat(Color(0.45, 0.42, 0.4), 0.45, 0.8, 0.4)
	cyl(pivot, r, r, w, Vector3.ZERO, tire, Vector3(0, 0, 90), 14)
	cyl(pivot, r * 0.5, r * 0.5, w + 0.04, Vector3.ZERO, hub, Vector3(0, 0, 90), 8)
	box(pivot, Vector3(w + 0.06, r * 1.5, 0.12), Vector3.ZERO, hub)
	return pivot


# ---------------------------------------------------------------- jogador
static func build_player() -> Dictionary:
	var root := Node3D.new()
	root.name = "Jogador"
	var body := Node3D.new()
	body.name = "Corpo"
	root.add_child(body)

	var gun := mat(Color(0.17, 0.17, 0.18), 0.5, 0.7, 0.35)
	var orange := mat(Color(0.85, 0.36, 0.07), 0.55, 0.3, 0.42)
	var dark := mat(Color(0.05, 0.05, 0.05), 0.9)
	var steel := mat(Color(0.6, 0.6, 0.62), 0.35, 0.9, 0.15)
	var head_m := glow(Color(1.0, 0.92, 0.7), 6.0)
	var tail_m := glow(Color(1.0, 0.08, 0.03), 5.0)
	var toxic := glow(Color(0.5, 1.0, 0.15), 3.0)

	# chassi e blindagem
	box(body, Vector3(1.9, 0.45, 3.8), Vector3(0, 0.75, 0), gun)
	box(body, Vector3(1.7, 0.16, 1.5), Vector3(0, 1.05, -1.1), orange, Vector3(-8, 0, 0))
	box(body, Vector3(0.35, 0.42, 2.6), Vector3(-1.02, 0.85, 0.2), orange)
	box(body, Vector3(0.35, 0.42, 2.6), Vector3(1.02, 0.85, 0.2), orange)
	box(body, Vector3(0.05, 0.08, 2.2), Vector3(-1.2, 1.0, 0.2), toxic)
	box(body, Vector3(0.05, 0.08, 2.2), Vector3(1.2, 1.0, 0.2), toxic)
	# gaiola de protecao
	for sx in [-0.75, 0.75]:
		for z in [-0.3, 0.9]:
			box(body, Vector3(0.1, 1.0, 0.1), Vector3(sx, 1.45, z), steel)
		box(body, Vector3(0.1, 0.1, 1.3), Vector3(sx, 1.95, 0.3), steel)
	box(body, Vector3(1.6, 0.1, 0.1), Vector3(0, 1.95, -0.3), steel)
	box(body, Vector3(1.6, 0.1, 0.1), Vector3(0, 1.95, 0.9), steel)
	box(body, Vector3(1.6, 0.06, 0.06), Vector3(0, 1.7, 0.3), steel, Vector3(0, 35, 0))
	# piloto
	box(body, Vector3(0.65, 0.55, 0.6), Vector3(0, 1.25, 0.4), dark)
	ball(body, 0.26, Vector3(0, 1.72, 0.35), mat(Color(0.12, 0.12, 0.12), 0.25, 0.8))
	box(body, Vector3(0.36, 0.1, 0.05), Vector3(0, 1.74, 0.1), glow(Color(1.0, 0.45, 0.05), 3.0))
	# ariete com espinhos
	box(body, Vector3(2.15, 0.32, 0.25), Vector3(0, 0.65, -2.0), gun)
	for sx in [-0.8, -0.27, 0.27, 0.8]:
		cyl(body, 0.0, 0.12, 0.55, Vector3(sx, 0.65, -2.38), steel, Vector3(-90, 0, 0), 6)
	# aerofolio
	box(body, Vector3(2.1, 0.08, 0.5), Vector3(0, 1.65, 1.8), orange)
	box(body, Vector3(0.08, 0.5, 0.08), Vector3(-0.7, 1.38, 1.8), steel)
	box(body, Vector3(0.08, 0.5, 0.08), Vector3(0.7, 1.38, 1.8), steel)
	# motor exposto e escapamentos
	box(body, Vector3(1.0, 0.5, 0.8), Vector3(0, 1.15, 1.45), mat(Color(0.25, 0.22, 0.2), 0.6, 0.6, 0.5))
	box(body, Vector3(0.6, 0.25, 0.5), Vector3(0, 1.5, 1.45), steel)
	var flames := []
	var flame_m := glow(Color(1.0, 0.5, 0.1), 8.0)
	for sx in [-0.38, 0.38]:
		cyl(body, 0.09, 0.09, 0.9, Vector3(sx, 1.55, 1.75), steel, Vector3(60, 0, 0), 8)
		var f := cyl(body, 0.0, 0.11, 0.6, Vector3(sx, 1.8, 2.25), flame_m, Vector3(60, 0, 0), 6)
		f.name = "Chama"
		f.add_to_group("chamas", true)
		flames.append(f)
		var fn := cyl(body, 0.0, 0.14, 1.0, Vector3(sx, 1.95, 2.5), glow(Color(0.35, 0.65, 1.0), 10.0), Vector3(60, 0, 0), 6)
		fn.name = "ChamaNitro"
		fn.add_to_group("chamas_nitro", true)
		fn.visible = false
	# farois e lanternas
	var heads := []
	heads.append(box(body, Vector3(0.32, 0.2, 0.1), Vector3(-0.6, 0.95, -1.92), head_m))
	heads.append(box(body, Vector3(0.32, 0.2, 0.1), Vector3(0.6, 0.95, -1.92), head_m))
	for sx in [-0.45, 0.0, 0.45]:
		heads.append(box(body, Vector3(0.22, 0.14, 0.12), Vector3(sx, 2.06, -0.3), head_m))
	box(body, Vector3(0.32, 0.12, 0.06), Vector3(-0.7, 0.88, 1.92), tail_m)
	box(body, Vector3(0.32, 0.12, 0.06), Vector3(0.7, 0.88, 1.92), tail_m)

	var wheels := []
	wheels.append(wheel(root, Vector3(-1.22, 0.55, 1.25), 0.55, 0.55))
	wheels.append(wheel(root, Vector3(1.22, 0.55, 1.25), 0.55, 0.55))
	wheels.append(wheel(root, Vector3(-1.15, 0.45, -1.35), 0.45, 0.4))
	wheels.append(wheel(root, Vector3(1.15, 0.45, -1.35), 0.45, 0.4))

	var lights := []
	for sx in [-0.6, 0.6]:
		var sl := SpotLight3D.new()
		sl.position = Vector3(sx, 1.0, -2.0)
		sl.rotation_degrees = Vector3(-5, 0, 0)
		sl.spot_range = 75.0
		sl.spot_angle = 24.0
		sl.light_energy = 9.0
		sl.light_color = Color(1.0, 0.92, 0.75)
		sl.shadow_enabled = false
		sl.name = "Farol"
		sl.add_to_group("farois", true)
		body.add_child(sl, true)
		lights.append(sl)
	var glow_l := OmniLight3D.new()
	glow_l.position = Vector3(0, 1.6, 2.6)
	glow_l.omni_range = 5.0
	glow_l.light_color = Color(0.3, 0.6, 1.0)
	glow_l.light_energy = 0.0
	glow_l.name = "LuzNitro"
	glow_l.add_to_group("luz_nitro", true)
	body.add_child(glow_l)

	return {"node": root, "body": body, "wheels": wheels, "flames": flames, "heads": heads,
		"lights": lights, "nitro_light": glow_l,
		"flame_mat": flame_m, "nitro_mat": glow(Color(0.35, 0.65, 1.0), 10.0)}


# ---------------------------------------------------------------- inimigos
const PAINTS := [
	Color(0.25, 0.45, 0.42), Color(0.62, 0.5, 0.2), Color(0.7, 0.68, 0.6), Color(0.35, 0.38, 0.22),
	Color(0.5, 0.16, 0.12), Color(0.3, 0.3, 0.34), Color(0.55, 0.3, 0.15), Color(0.2, 0.25, 0.4),
]


static func build_enemy(kind: String, rng: RandomNumberGenerator) -> Dictionary:
	var root := Node3D.new()
	var c: Color = PAINTS[rng.randi() % PAINTS.size()]
	var paint := mat(c, 0.7, 0.3, snappedf(rng.randf_range(0.3, 0.7), 0.1))
	var glass := mat(Color(0.04, 0.05, 0.06), 0.15, 0.8)
	var rustm := mat(Color(0.4, 0.2, 0.1), 0.9, 0.2, 0.9)
	var dark := mat(Color(0.06, 0.06, 0.06), 0.9)
	var tail := glow(Color(1.0, 0.06, 0.02), 6.0)
	var head := glow(Color(1.0, 0.9, 0.6), 3.0)
	var amber := glow(Color(1.0, 0.5, 0.05), 5.0)
	var wheels := []
	var hw := 1.0
	var hl := 2.1
	match kind:
		"truck":
			hw = 1.27
			hl = 3.55
			box(root, Vector3(2.0, 0.4, 7.0), Vector3(0, 0.62, 0.0), dark)
			box(root, Vector3(2.3, 1.7, 1.9), Vector3(0, 1.55, -2.45), paint)
			box(root, Vector3(2.32, 0.6, 1.0), Vector3(0, 1.9, -2.9), glass)
			box(root, Vector3(2.5, 2.4, 4.6), Vector3(0, 2.0, 1.15), rustm)
			box(root, Vector3(2.55, 0.3, 4.7), Vector3(0, 3.25, 1.15), mat(Color(0.3, 0.32, 0.2), 0.95), Vector3(0, 0, rng.randf_range(-4, 4)))
			for sx in [-0.95, 0.95]:
				box(root, Vector3(0.35, 0.18, 0.06), Vector3(sx, 0.95, 3.5), tail)
				box(root, Vector3(0.12, 0.12, 0.12), Vector3(sx * 1.25, 3.2, 3.45), amber)
				box(root, Vector3(0.3, 0.2, 0.06), Vector3(sx * 0.8, 1.1, -3.42), head)
			for z in [-2.4, 0.4, 2.3]:
				wheels.append(wheel(root, Vector3(-1.1, 0.55, z), 0.55, 0.4))
				wheels.append(wheel(root, Vector3(1.1, 0.55, z), 0.55, 0.4))
		"van":
			hw = 1.05
			hl = 2.25
			box(root, Vector3(2.0, 1.75, 4.4), Vector3(0, 1.25, 0), paint)
			box(root, Vector3(2.02, 0.55, 1.0), Vector3(0, 1.65, -1.75), glass)
			box(root, Vector3(1.4, 0.5, 0.05), Vector3(0, 1.6, 2.21), glass)
			box(root, Vector3(1.6, 0.15, 3.0), Vector3(0, 2.2, 0.2), rustm)
			box(root, Vector3(2.05, 0.2, 0.2), Vector3(0, 0.45, 2.25), rustm)
			for sx in [-0.8, 0.8]:
				box(root, Vector3(0.25, 0.3, 0.06), Vector3(sx, 0.95, 2.22), tail)
				box(root, Vector3(0.3, 0.2, 0.06), Vector3(sx * 0.9, 0.9, -2.22), head)
			for z in [-1.4, 1.4]:
				wheels.append(wheel(root, Vector3(-0.95, 0.4, z), 0.4, 0.3))
				wheels.append(wheel(root, Vector3(0.95, 0.4, z), 0.4, 0.3))
		"raider":
			hw = 1.05
			hl = 1.95
			var red := mat(Color(0.55, 0.06, 0.04), 0.6, 0.4, 0.35)
			var steel := mat(Color(0.55, 0.55, 0.58), 0.35, 0.9, 0.2)
			box(root, Vector3(1.7, 0.45, 3.4), Vector3(0, 0.75, 0), red)
			box(root, Vector3(1.75, 0.12, 1.2), Vector3(0, 1.0, -1.0), dark, Vector3(-10, 0, 0))
			for sx in [-0.7, 0.7]:
				box(root, Vector3(0.09, 1.0, 0.09), Vector3(sx, 1.4, -0.1), steel, Vector3(-15, 0, 0))
				box(root, Vector3(0.09, 0.9, 0.09), Vector3(sx, 1.35, 0.9), steel)
				box(root, Vector3(0.3, 0.12, 0.06), Vector3(sx, 0.85, 1.72), tail)
			box(root, Vector3(1.5, 0.09, 1.2), Vector3(0, 1.88, 0.4), steel)
			box(root, Vector3(0.6, 0.5, 0.5), Vector3(0, 1.25, 0.4), dark)
			ball(root, 0.24, Vector3(0, 1.65, 0.4), mat(Color(0.75, 0.7, 0.6), 0.8))
			for sx in [-0.65, 0.0, 0.65]:
				cyl(root, 0.0, 0.1, 0.6, Vector3(sx, 0.7, -1.95), steel, Vector3(-90, 0, 0), 6)
			for sz in [-0.8, 0.4]:
				cyl(root, 0.0, 0.08, 0.45, Vector3(-1.05, 0.8, sz), steel, Vector3(0, 0, 90), 6)
				cyl(root, 0.0, 0.08, 0.45, Vector3(1.05, 0.8, sz), steel, Vector3(0, 0, -90), 6)
			box(root, Vector3(0.05, 2.4, 0.05), Vector3(0.6, 2.1, 1.4), steel)
			box(root, Vector3(0.03, 0.55, 0.9), Vector3(0.6, 3.0, 1.85), mat(Color(0.7, 0.05, 0.03), 0.9), Vector3(0, 0, 4))
			box(root, Vector3(0.4, 0.12, 0.06), Vector3(0, 0.95, -1.72), glow(Color(1.0, 0.2, 0.05), 6.0))
			wheels.append(wheel(root, Vector3(-1.05, 0.5, 1.1), 0.5, 0.5))
			wheels.append(wheel(root, Vector3(1.05, 0.5, 1.1), 0.5, 0.5))
			wheels.append(wheel(root, Vector3(-1.0, 0.42, -1.2), 0.42, 0.35))
			wheels.append(wheel(root, Vector3(1.0, 0.42, -1.2), 0.42, 0.35))
		_:
			# sedan enferrujado
			box(root, Vector3(1.85, 0.6, 4.1), Vector3(0, 0.68, 0), paint)
			box(root, Vector3(1.6, 0.55, 2.0), Vector3(0, 1.23, 0.25), paint)
			box(root, Vector3(1.64, 0.36, 1.75), Vector3(0, 1.25, 0.25), glass)
			box(root, Vector3(1.95, 0.2, 0.15), Vector3(0, 0.5, 2.1), rustm)
			box(root, Vector3(1.95, 0.2, 0.15), Vector3(0, 0.5, -2.1), rustm)
			for sx in [-0.65, 0.65]:
				box(root, Vector3(0.4, 0.16, 0.06), Vector3(sx, 0.82, 2.07), tail)
				box(root, Vector3(0.35, 0.16, 0.06), Vector3(sx, 0.78, -2.07), head)
			var r := rng.randf()
			if r < 0.35:
				box(root, Vector3(1.2, 0.45, 1.0), Vector3(0, 1.73, 0.4), mat(Color(0.35, 0.25, 0.15), 0.95), Vector3(0, rng.randf_range(-15, 15), 0))
			elif r < 0.6:
				torus(root, 0.2, 0.42, Vector3(0, 1.58, 0.3), dark)
				torus(root, 0.2, 0.42, Vector3(0.05, 1.78, 0.3), dark)
			for z in [-1.3, 1.3]:
				wheels.append(wheel(root, Vector3(-0.93, 0.38, z), 0.38, 0.3))
				wheels.append(wheel(root, Vector3(0.93, 0.38, z), 0.38, 0.3))
	return {"node": root, "wheels": wheels, "hw": hw, "hl": hl}


# ---------------------------------------------------------------- cenario
static func build_prop(kind: String, rng: RandomNumberGenerator) -> Node3D:
	var root := Node3D.new()
	var dark := mat(Color(0.06, 0.06, 0.06), 0.9)
	match kind:
		"wreck":
			var c: Color = PAINTS[rng.randi() % PAINTS.size()]
			var burnt := rng.randf() < 0.4
			var m := mat(c.darkened(0.6) if burnt else c, 0.85, 0.3, 0.9 if burnt else 0.7)
			box(root, Vector3(1.9, 0.6, 4.1), Vector3(0, 0.45, 0), m)
			box(root, Vector3(1.6, 0.4, 1.9), Vector3(0.1, 0.9, 0.3), m, Vector3(0, 6, 8))
			box(root, Vector3(1.3, 0.05, 1.0), Vector3(0.3, 1.1, -1.4), m, Vector3(25, 0, 10))
			torus(root, 0.15, 0.36, Vector3(-0.95, 0.3, 1.3), dark, Vector3(0, 0, 80))
			if rng.randf() < 0.5:
				torus(root, 0.15, 0.36, Vector3(2.2, 0.08, 0.5), dark)
			root.rotation_degrees = Vector3(0, rng.randf_range(0, 360), rng.randf_range(-12, 12))
		"tree":
			var wood := mat(Color(0.17, 0.12, 0.09), 0.95)
			var h := rng.randf_range(4.0, 7.0)
			cyl(root, 0.12, 0.3, h, Vector3(0, h * 0.5, 0), wood, Vector3(rng.randf_range(-6, 6), 0, rng.randf_range(-6, 6)), 6)
			for i in rng.randi_range(3, 5):
				var bh := rng.randf_range(h * 0.45, h * 0.9)
				var ang := rng.randf_range(0, 360)
				var br := Node3D.new()
				br.position = Vector3(0, bh, 0)
				br.rotation_degrees = Vector3(0, ang, rng.randf_range(35, 65))
				root.add_child(br)
				var bl := rng.randf_range(1.2, 2.6)
				cyl(br, 0.03, 0.09, bl, Vector3(0, bl * 0.5, 0), wood, Vector3.ZERO, 5)
		"pole":
			var wood := mat(Color(0.28, 0.2, 0.13), 0.95)
			var p := Node3D.new()
			p.rotation_degrees = Vector3(rng.randf_range(-6, 6), rng.randf_range(0, 40), rng.randf_range(-18, 18))
			root.add_child(p)
			cyl(p, 0.13, 0.17, 9.0, Vector3(0, 4.5, 0), wood, Vector3.ZERO, 6)
			box(p, Vector3(2.6, 0.16, 0.16), Vector3(0, 8.2, 0), wood)
			for sx in [-1.1, 0.0, 1.1]:
				cyl(p, 0.06, 0.08, 0.25, Vector3(sx, 8.4, 0), mat(Color(0.3, 0.5, 0.45), 0.3), Vector3.ZERO, 6)
			if rng.randf() < 0.4:
				box(p, Vector3(0.6, 0.8, 0.4), Vector3(0.3, 6.5, 0.2), mat(Color(0.4, 0.4, 0.4), 0.6, 0.6, 0.7))
		"ruin":
			var concrete := mat(Color(0.42, 0.4, 0.37), 0.95, 0.0, 0.25)
			var hole := mat(Color(0.03, 0.03, 0.03), 1.0)
			var w := rng.randf_range(7.0, 13.0)
			var d := rng.randf_range(6.0, 10.0)
			var h := rng.randf_range(7.0, 18.0)
			box(root, Vector3(w, h, 0.5), Vector3(0, h * 0.5, d * 0.5), concrete)
			var sh := h * rng.randf_range(0.4, 0.9)
			box(root, Vector3(0.5, sh, d), Vector3(-w * 0.5, sh * 0.5, 0), concrete)
			var sh2 := h * rng.randf_range(0.2, 0.7)
			box(root, Vector3(0.5, sh2, d * 0.6), Vector3(w * 0.5, sh2 * 0.5, d * 0.2), concrete)
			var segs := 4
			for i in segs:
				var fh := h * rng.randf_range(0.25, 1.0)
				box(root, Vector3(w / segs - 0.1, fh, 0.5), Vector3(-w * 0.5 + (i + 0.5) * w / segs, fh * 0.5, -d * 0.5), concrete)
			var floors := int(h / 3.2)
			for f in floors:
				box(root, Vector3(w * rng.randf_range(0.5, 1.0), 0.25, d * 0.9), Vector3(rng.randf_range(-1, 1), 3.2 * (f + 1), 0), concrete, Vector3(rng.randf_range(-6, 6), 0, rng.randf_range(-5, 5)))
				for i in segs:
					if rng.randf() < 0.75:
						box(root, Vector3(1.1, 1.3, 0.1), Vector3(-w * 0.5 + (i + 0.5) * w / segs, 3.2 * f + 1.7, -d * 0.5 - 0.26), hole)
			var reb := mat(Color(0.35, 0.18, 0.08), 0.9, 0.5, 0.9)
			for i in 5:
				cyl(root, 0.03, 0.03, 1.5, Vector3(rng.randf_range(-w * 0.5, w * 0.5), h * 0.6 + rng.randf_range(0, 2), d * 0.5), reb, Vector3(rng.randf_range(-20, 20), 0, rng.randf_range(-20, 20)), 4)
			for i in 4:
				ball(root, rng.randf_range(0.5, 1.2), Vector3(rng.randf_range(-w * 0.6, w * 0.6), 0.2, -d * 0.5 - rng.randf_range(0.5, 3.0)), concrete, Vector3(1.4, 0.6, 1.0), 6)
			root.rotation_degrees = Vector3(0, rng.randf_range(-25, 25), 0)
		"barrels":
			var yellow := mat(Color(0.75, 0.55, 0.08), 0.6, 0.4, 0.6)
			var goo := glow(Color(0.45, 1.0, 0.12), 3.5)
			for i in rng.randi_range(3, 5):
				var pos := Vector3(rng.randf_range(-1.5, 1.5), 0.45, rng.randf_range(-1.5, 1.5))
				if rng.randf() < 0.3:
					cyl(root, 0.35, 0.35, 0.9, Vector3(pos.x, 0.35, pos.z), yellow, Vector3(90, rng.randf_range(0, 180), 0), 10)
				else:
					cyl(root, 0.35, 0.35, 0.9, pos, yellow, Vector3.ZERO, 10)
					if rng.randf() < 0.6:
						cyl(root, 0.32, 0.32, 0.04, pos + Vector3(0, 0.46, 0), goo, Vector3.ZERO, 10)
			cyl(root, 1.6, 1.6, 0.02, Vector3(0.5, 0.02, 0.8), goo, Vector3.ZERO, 12)
		"tires":
			for s in rng.randi_range(1, 3):
				var base := Vector3(rng.randf_range(-1.5, 1.5), 0, rng.randf_range(-1.5, 1.5))
				for i in rng.randi_range(2, 5):
					torus(root, 0.22, 0.5, base + Vector3(rng.randf_range(-0.05, 0.05), 0.16 + i * 0.28, 0), dark)
		"rocks":
			var rock := mat(Color(0.4, 0.33, 0.27), 0.95)
			for i in rng.randi_range(2, 4):
				var r := rng.randf_range(0.8, 2.5)
				ball(root, r, Vector3(rng.randf_range(-2, 2), r * 0.3, rng.randf_range(-2, 2)), rock, Vector3(rng.randf_range(0.8, 1.6), rng.randf_range(0.5, 1.0), rng.randf_range(0.8, 1.4)), 6)
		"sign":
			var steel := mat(Color(0.5, 0.5, 0.5), 0.5, 0.7, 0.7)
			if rng.randf() < 0.5:
				var p := Node3D.new()
				p.rotation_degrees = Vector3(0, rng.randf_range(-30, 30), rng.randf_range(-20, 20))
				root.add_child(p)
				cyl(p, 0.05, 0.05, 2.6, Vector3(0, 1.3, 0), steel, Vector3.ZERO, 6)
				cyl(p, 0.55, 0.55, 0.05, Vector3(0, 2.6, 0), mat(Color(0.6, 0.08, 0.05), 0.7, 0.2, 0.6), Vector3(90, 0, 22.5), 8)
			else:
				var board := mat(Color(0.75, 0.68, 0.5), 0.8, 0.1, 0.55)
				box(root, Vector3(0.25, 6.0, 0.25), Vector3(-2.0, 3.0, 0), steel)
				box(root, Vector3(0.25, 6.0, 0.25), Vector3(2.0, 3.0, 0), steel)
				var b := Node3D.new()
				b.position = Vector3(0, 5.5, 0)
				b.rotation_degrees = Vector3(0, 0, rng.randf_range(-12, 12))
				root.add_child(b)
				box(b, Vector3(5.2, 2.4, 0.12), Vector3.ZERO, board)
				box(b, Vector3(4.6, 0.35, 0.14), Vector3(0, 0.5, 0), mat(Color(0.55, 0.12, 0.06), 0.8, 0.0, 0.5))
				box(b, Vector3(3.2, 0.25, 0.14), Vector3(-0.4, -0.3, 0), mat(Color(0.15, 0.15, 0.15), 0.8, 0.0, 0.5))
			root.rotation_degrees.y += 90
		"bus":
			var y := mat(Color(0.8, 0.6, 0.1), 0.8, 0.3, 0.6)
			var glass := mat(Color(0.03, 0.03, 0.03), 0.9)
			var p := Node3D.new()
			root.add_child(p)
			box(p, Vector3(2.5, 2.8, 10.0), Vector3(0, 1.6, 0), y)
			for i in 7:
				box(p, Vector3(2.55, 0.8, 0.9), Vector3(0, 2.2, -3.9 + i * 1.25), glass)
			if rng.randf() < 0.5:
				p.rotation_degrees = Vector3(0, 0, 90)
				p.position = Vector3(0, 0.05, 0)
			root.rotation_degrees = Vector3(0, rng.randf_range(0, 360), 0)
		"tower":
			var steel := mat(Color(0.3, 0.3, 0.32), 0.6, 0.7, 0.6)
			var h := 22.0
			for sx in [-1.5, 1.5]:
				for sz in [-1.5, 1.5]:
					box(root, Vector3(0.25, h, 0.25), Vector3(sx, h * 0.5, sz), steel, Vector3(-sz * 2.5, 0, sx * 2.5))
			for i in 6:
				box(root, Vector3(3.4, 0.15, 0.15), Vector3(0, 3.0 + i * 3.2, 1.5), steel, Vector3(0, 0, 25 if i % 2 == 0 else -25))
				box(root, Vector3(3.4, 0.15, 0.15), Vector3(0, 3.0 + i * 3.2, -1.5), steel, Vector3(0, 0, -25 if i % 2 == 0 else 25))
			box(root, Vector3(7.0, 0.3, 0.3), Vector3(0, h - 1.5, 0), steel)
			box(root, Vector3(0.3, 0.3, 0.3), Vector3(0, h + 0.2, 0), glow(Color(1.0, 0.05, 0.02), 8.0))
			root.rotation_degrees = Vector3(0, 0, rng.randf_range(-10, 10))
	return root


static func build_post() -> Node3D:
	var root := Node3D.new()
	box(root, Vector3(0.14, 1.1, 0.14), Vector3(0, 0.55, 0), mat(Color(0.75, 0.72, 0.65), 0.7, 0.0, 0.55))
	box(root, Vector3(0.16, 0.16, 0.16), Vector3(0, 0.95, 0), glow(Color(1.0, 0.45, 0.05), 3.0))
	return root


static func build_skyline(rng: RandomNumberGenerator) -> Node3D:
	var root := Node3D.new()
	var mountain := mat(Color(0.33, 0.24, 0.17), 1.0)
	for i in 22:
		var r := rng.randf_range(90.0, 220.0)
		var h := rng.randf_range(60.0, 170.0)
		cyl(root, 0.0, r, h, Vector3(rng.randf_range(-1600, 1600), h * 0.5 - 5.0, rng.randf_range(-1150, -1500)), mountain, Vector3(0, rng.randf_range(0, 60), 0), rng.randi_range(5, 7))
	var concrete := mat(Color(0.2, 0.19, 0.2), 0.95, 0.0, 0.2)
	var red := glow(Color(1.0, 0.05, 0.02), 10.0)
	for i in 46:
		var w := rng.randf_range(14.0, 40.0)
		var h := rng.randf_range(35.0, 190.0)
		var d := rng.randf_range(14.0, 30.0)
		var x := rng.randf_range(-900.0, 900.0)
		if absf(x) < 60.0:
			x += signf(x + 0.01) * 80.0
		var z := rng.randf_range(-820.0, -1050.0)
		var tilt := Vector3(0, 0, rng.randf_range(-7, 7)) if rng.randf() < 0.3 else Vector3.ZERO
		box(root, Vector3(w, h, d), Vector3(x, h * 0.5 - 2.0, z), concrete, tilt)
		if rng.randf() < 0.6:
			var hw := w * rng.randf_range(0.3, 0.6)
			var hh := rng.randf_range(5.0, 25.0)
			box(root, Vector3(hw, hh, d * 0.8), Vector3(x + rng.randf_range(-w * 0.3, w * 0.3), h + hh * 0.5 - 2.0, z), concrete, Vector3(0, 0, rng.randf_range(-20, 20)))
		if rng.randf() < 0.25:
			box(root, Vector3(1.5, 1.5, 1.5), Vector3(x, h, z), red)
	return root

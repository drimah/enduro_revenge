extends RefCounted
## Utilitarios: adapta qualquer modelo (inclusive .glb/.blend/.fbx importados) ao mundo curvo.

const WORLD_SHADER := preload("res://shaders/world.gdshader")
static var _conv := {}
static var _default: ShaderMaterial


## Troca os materiais por versoes com o shader do mundo (que curva com a pista),
## copiando cor, textura, rugosidade, metal e emissao.
static func bendify(root: Node) -> void:
	var nodes: Array = [root]
	nodes.append_array(root.find_children("*", "GeometryInstance3D", true, false))
	for n in nodes:
		if not (n is GeometryInstance3D):
			continue
		n.extra_cull_margin = maxf(n.extra_cull_margin, 400.0)
		if n is MeshInstance3D and n.mesh != null:
			if n.material_override != null:
				n.material_override = to_world_material(n.material_override)
				continue
			for i in n.mesh.get_surface_count():
				var m: Material = n.get_surface_override_material(i)
				if m == null:
					m = n.mesh.surface_get_material(i)
				n.set_surface_override_material(i, to_world_material(m))


static func to_world_material(m: Material) -> Material:
	if m == null:
		if _default == null:
			_default = ShaderMaterial.new()
			_default.shader = WORLD_SHADER
			_default.set_shader_parameter("albedo", Color(0.7, 0.7, 0.7))
		return _default
	if m is ShaderMaterial:
		return m
	if _conv.has(m):
		return _conv[m]
	var out := ShaderMaterial.new()
	out.shader = WORLD_SHADER
	if m is BaseMaterial3D:
		var b: BaseMaterial3D = m
		out.set_shader_parameter("albedo", b.albedo_color)
		if b.albedo_texture != null:
			out.set_shader_parameter("albedo_texture", b.albedo_texture)
		out.set_shader_parameter("roughness", b.roughness)
		out.set_shader_parameter("metallic", b.metallic)
		out.set_shader_parameter("use_vertex_color", b.vertex_color_use_as_albedo)
		if b.emission_enabled:
			out.set_shader_parameter("emission", b.emission)
			out.set_shader_parameter("emission_energy", b.emission_energy_multiplier)
	_conv[m] = out
	return out


## Meia largura (x) e meio comprimento (y) do modelo, a partir das malhas.
static func extents(root: Node3D) -> Vector2:
	var mn := Vector3(INF, INF, INF)
	var mx := Vector3(-INF, -INF, -INF)
	var found := false
	for n in root.find_children("*", "MeshInstance3D", true, false):
		var xf := Transform3D.IDENTITY
		var c: Node = n
		while c != null and c != root:
			if c is Node3D:
				xf = c.transform * xf
			c = c.get_parent()
		var ab: AABB = xf * n.get_aabb()
		mn = mn.min(ab.position)
		mx = mx.max(ab.end)
		found = true
	if not found:
		return Vector2(1.0, 2.0)
	return Vector2(maxf(absf(mn.x), absf(mx.x)), maxf(absf(mn.z), absf(mx.z)))


static func in_group(root: Node, group: String) -> Array:
	var out := []
	for n in root.find_children("*", "", true, false):
		if n.is_in_group(group):
			out.append(n)
	return out


static func wheels(root: Node) -> Array:
	var out := []
	for n in root.find_children("*", "Node3D", true, false):
		var nm := String(n.name).to_lower()
		if n.is_in_group("rodas") or nm.begins_with("roda") or nm.begins_with("wheel"):
			var nested := false
			for w in out:
				if w.is_ancestor_of(n):
					nested = true
					break
			if not nested:
				out.append(n)
	return out

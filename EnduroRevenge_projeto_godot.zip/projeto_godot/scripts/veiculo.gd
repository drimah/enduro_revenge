extends Node3D
## Script da raiz de qualquer veiculo (jogador ou inimigo).
## Coloque seu modelo 3D como filho deste no. A FRENTE do carro deve apontar para -Z
## (a seta azul do gizmo aponta para TRAS do carro).
##
## Convencoes opcionais (o jogo encontra sozinho):
##  - Rodas: nos com nome comecando com "Roda" ou "Wheel", ou no grupo "rodas" (giram no eixo X)
##  - Jogador: no "Corpo" (inclina nas curvas), grupo "farois" (SpotLight3D ligados a noite),
##    grupo "chamas" (fogo do escapamento), grupo "chamas_nitro", grupo "luz_nitro"

@export_group("Colisão")
## Meia largura do carro em metros (0 = calcular automaticamente pelo modelo)
@export var half_width := 0.0
## Meio comprimento do carro em metros (0 = calcular automaticamente pelo modelo)
@export var half_length := 0.0

@export_group("Inimigo")
## Velocidade minima em m/s (x3.6 = km/h)
@export var min_speed := 26.0
## Velocidade maxima em m/s
@export var max_speed := 37.0
## Troca de faixa sozinho (estilo saqueador)
@export var troca_faixa := false
## Chance relativa de aparecer
@export var peso_spawn := 1.0
## Quanto a chance aumenta a cada dia
@export var peso_por_dia := 0.0
## Primeiro dia em que este carro pode aparecer
@export var dia_minimo := 1
## Pode aparecer por tras e te ultrapassar quando voce esta devagar
@export var pode_vir_por_tras := false

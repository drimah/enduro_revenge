extends RefCounted
## Sintetizador de musica procedural (darksynth / synthwave pos-apocaliptico).
## Toda a trilha e gerada por codigo na inicializacao (em uma thread separada).


static func mtof(m: float) -> float:
	return 440.0 * pow(2.0, (m - 69.0) / 12.0)


static func to_wav(buf: PackedFloat32Array, rate: int, loop: bool) -> AudioStreamWAV:
	var data := PackedByteArray()
	data.resize(buf.size() * 2)
	for i in buf.size():
		data.encode_s16(i * 2, int(clampf(buf[i], -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = buf.size()
	return w


static func normalize(buf: PackedFloat32Array, peak := 0.9) -> PackedFloat32Array:
	var m := 0.0001
	for v in buf:
		m = maxf(m, absf(v))
	var k := peak / m
	for i in buf.size():
		buf[i] *= k
	return buf


## Toca uma nota no buffer (com wrap no final, para loops perfeitos).
## wave: 0 serra, 1 quadrada, 2 seno, 3 triangulo
static func tone(buf: PackedFloat32Array, start: int, length: int, freq: float, vol: float, wave: int, rate: int,
		atk := 0.005, rel := 0.05, cutoff := 4000.0, decay := 0.0, detune := 0.0) -> void:
	var total := buf.size()
	var a_s := maxi(1, int(atk * rate))
	var r_s := maxi(1, int(rel * rate))
	var n := length + r_s
	var inc := freq / rate
	var inc2 := freq * (1.0 + detune) / rate
	var ph := 0.0
	var ph2 := 0.37
	var lp := 0.0
	var k := 1.0 - exp(-TAU * cutoff / rate)
	var dmul := 1.0
	if decay > 0.0:
		dmul = exp(-1.0 / (decay * rate))
	var denv := 1.0
	var use_det := detune != 0.0
	for i in n:
		var env := denv
		if i < a_s:
			env *= float(i) / a_s
		if i >= length:
			env *= 1.0 - float(i - length) / r_s
		denv *= dmul
		var x: float
		if wave == 0:
			x = ph * 2.0 - 1.0
		elif wave == 1:
			x = 1.0 if ph < 0.5 else -1.0
		elif wave == 2:
			x = sin(TAU * ph)
		else:
			x = 4.0 * absf(ph - 0.5) - 1.0
		if use_det:
			x = (x + ph2 * 2.0 - 1.0) * 0.5
			ph2 += inc2
			if ph2 >= 1.0:
				ph2 -= 1.0
		ph += inc
		if ph >= 1.0:
			ph -= 1.0
		lp += k * (x - lp)
		buf[(start + i) % total] += lp * env * vol


## Acorde de pad: serras desafinadas com filtro passa-baixa de 2 polos.
static func pad(buf: PackedFloat32Array, start: int, length: int, freqs: Array, vol: float, rate: int,
		atk: float, rel: float, cutoff: float) -> void:
	var total := buf.size()
	var incs := PackedFloat32Array()
	var phs := PackedFloat32Array()
	var seed_ph := 0.13
	for f in freqs:
		incs.append(f / rate)
		incs.append(f * 1.0065 / rate)
		phs.append(seed_ph)
		phs.append(fmod(seed_ph + 0.5, 1.0))
		seed_ph = fmod(seed_ph + 0.29, 1.0)
	var nosc := incs.size()
	var a_s := maxi(1, int(atk * rate))
	var r_s := maxi(1, int(rel * rate))
	var n := length + r_s
	var k := 1.0 - exp(-TAU * cutoff / rate)
	var lp := 0.0
	var lp2 := 0.0
	var inv := 1.0 / nosc
	for i in n:
		var env := 1.0
		if i < a_s:
			env = float(i) / a_s
		if i >= length:
			env *= 1.0 - float(i - length) / r_s
		var x := 0.0
		for j in nosc:
			var p := phs[j] + incs[j]
			if p >= 1.0:
				p -= 1.0
			phs[j] = p
			x += p
		x = (x * inv) * 2.0 - 1.0
		lp += k * (x - lp)
		lp2 += k * (lp - lp2)
		buf[(start + i) % total] += lp2 * env * vol


static func add_sample(buf: PackedFloat32Array, start: int, smp: PackedFloat32Array, vol: float) -> void:
	var total := buf.size()
	for i in smp.size():
		buf[(start + i) % total] += smp[i] * vol


# ---------------------------------------------------------------- bateria
static func kick(rate: int) -> PackedFloat32Array:
	var n := int(0.34 * rate)
	var b := PackedFloat32Array()
	b.resize(n)
	var ph := 0.0
	for i in n:
		var t := float(i) / rate
		var f := 45.0 + 115.0 * exp(-t * 28.0)
		ph += f / rate
		b[i] = sin(TAU * ph) * exp(-t * 7.5) + (randf() * 2.0 - 1.0) * exp(-t * 250.0) * 0.3
	return b


static func snare(rate: int) -> PackedFloat32Array:
	var n := int(0.24 * rate)
	var b := PackedFloat32Array()
	b.resize(n)
	var lp := 0.0
	for i in n:
		var t := float(i) / rate
		var w := randf() * 2.0 - 1.0
		lp += 0.3 * (w - lp)
		b[i] = (w - lp * 0.6) * exp(-t * 15.0) * 0.7 + sin(TAU * 185.0 * t) * exp(-t * 22.0) * 0.5
	return b


static func hat(rate: int, length: float, dec: float) -> PackedFloat32Array:
	var n := int(length * rate)
	var b := PackedFloat32Array()
	b.resize(n)
	var lp := 0.0
	for i in n:
		var t := float(i) / rate
		var w := randf() * 2.0 - 1.0
		lp += 0.5 * (w - lp)
		b[i] = (w - lp) * exp(-t * dec)
	return b


static func delay_fx(src: PackedFloat32Array, d: int, fb: float) -> PackedFloat32Array:
	var total := src.size()
	var out := src.duplicate()
	for p in 2:
		for i in total:
			var j := i - d
			if j < 0:
				j += total
			out[i] = src[i] + out[j] * fb
	return out


# ---------------------------------------------------------------- trilhas
## Trilha de corrida: 16 compassos, 128 BPM, Lá menor.
static func render_race(rate: int) -> PackedFloat32Array:
	var bpm := 128.0
	var step := int(round(rate * 60.0 / bpm / 4.0))
	var bars := 16
	var total := step * 16 * bars
	var drums := PackedFloat32Array()
	drums.resize(total)
	var bass := PackedFloat32Array()
	bass.resize(total)
	var pads := PackedFloat32Array()
	pads.resize(total)
	var leads := PackedFloat32Array()
	leads.resize(total)

	var K := kick(rate)
	var S := snare(rate)
	var H := hat(rate, 0.05, 70.0)
	var OH := hat(rate, 0.2, 14.0)
	var roots := [45, 41, 48, 43, 45, 41, 43, 40]
	var chords := [[57, 60, 64], [57, 60, 65], [55, 60, 64], [55, 59, 62],
		[57, 60, 64], [57, 60, 65], [55, 59, 62], [56, 59, 64]]
	var rng := RandomNumberGenerator.new()
	rng.seed = 2077
	var rhythm := [0, 3, 6, 8, 10, 12, 14, 16, 19, 22, 24, 28]
	var lens := [3, 3, 2, 2, 2, 2, 2, 3, 3, 2, 4, 4]
	var motif_a := []
	var motif_b := []
	for j in rhythm.size():
		motif_a.append(Vector2i(rng.randi() % 3, 1 if rng.randf() < 0.75 else 2))
		motif_b.append(Vector2i(rng.randi() % 3, 1 if rng.randf() < 0.5 else 2))

	for b in bars:
		var ci := int(b / 2) % 8
		var bar0 := b * 16 * step
		var ch: Array = chords[ci]
		for s in 16:
			var pos := bar0 + s * step
			if s % 4 == 0:
				add_sample(drums, pos, K, 0.95)
			if b >= 4 and (s == 4 or s == 12):
				add_sample(drums, pos, S, 0.55)
			if b >= 2 and s % 4 == 2:
				add_sample(drums, pos, OH, 0.16)
			if b >= 8 and s % 2 == 1:
				add_sample(drums, pos, H, 0.11)
			if b == 15 and s >= 13:
				add_sample(drums, pos, S, 0.4 + 0.08 * (s - 12))
		for s in range(0, 16, 2):
			var m: int = roots[ci] + (12 if (s == 6 or s == 14) else 0)
			tone(bass, bar0 + s * step, int(step * 1.5), mtof(m), 0.34, 0, rate, 0.003, 0.03, 520.0 + (380.0 if b >= 8 else 0.0))
		if b % 2 == 0:
			var fr := []
			for m in ch:
				fr.append(mtof(m))
			pad(pads, bar0, step * 32, fr, 0.24, rate, 0.25, 0.4, 1500.0)
		if b >= 4:
			var seq := [ch[0], ch[1], ch[2], ch[0] + 12, ch[2], ch[1], ch[0] + 12, ch[2]]
			for s in 16:
				var m2: int = seq[s % 8] + 12
				tone(leads, bar0 + s * step, int(step * 0.6), mtof(m2), 0.06, 1, rate, 0.002, 0.03, 2400.0, 0.12)
		if b >= 8 and b % 2 == 0:
			var motif: Array = motif_a if b < 12 else motif_b
			for j in rhythm.size():
				var v: Vector2i = motif[j]
				var m3: int = ch[v.x] + 12 * v.y
				tone(leads, bar0 + rhythm[j] * step, int(step * lens[j] * 0.9), mtof(m3), 0.1, 0, rate, 0.01, 0.08, 2800.0, 0.0, 0.006)

	var wet := delay_fx(leads, step * 3, 0.36)
	var out := PackedFloat32Array()
	out.resize(total)
	var beat := step * 4
	for i in total:
		var bp := float(i % beat) / beat
		var duck := 0.45 + 0.55 * minf(1.0, bp * 3.5)
		out[i] = drums[i] * 0.8 + (bass[i] + pads[i]) * duck + wet[i]
	return normalize(out, 0.92)


## Trilha do menu: lenta e sombria, 8 compassos, 80 BPM.
static func render_menu(rate: int) -> PackedFloat32Array:
	var bpm := 80.0
	var step := int(round(rate * 60.0 / bpm / 4.0))
	var bars := 8
	var total := step * 16 * bars
	var low := PackedFloat32Array()
	low.resize(total)
	var bells := PackedFloat32Array()
	bells.resize(total)
	var drums := PackedFloat32Array()
	drums.resize(total)
	var K := kick(rate)
	var OH := hat(rate, 0.3, 9.0)
	var roots := [45, 41, 38, 40]
	var chords := [[57, 60, 64], [57, 60, 65], [57, 62, 65], [56, 59, 64]]
	var rng := RandomNumberGenerator.new()
	rng.seed = 1984
	var bell_steps := [0, 3, 6, 10, 12]
	for b in bars:
		var ci := int(b / 2) % 4
		var bar0 := b * 16 * step
		var ch: Array = chords[ci]
		if b % 2 == 0:
			var fr := []
			for m in ch:
				fr.append(mtof(m - 12))
			pad(low, bar0, step * 32, fr, 0.32, rate, 1.2, 1.0, 900.0)
		tone(low, bar0, step * 15, mtof(roots[ci] - 12), 0.45, 0, rate, 0.05, 0.3, 260.0)
		tone(low, bar0, step * 15, mtof(roots[ci] - 12), 0.25, 2, rate, 0.05, 0.3, 400.0)
		for s in bell_steps:
			var m: int = ch[rng.randi() % 3] + 12
			tone(bells, bar0 + s * step, step, mtof(m), 0.1, 2, rate, 0.002, 0.5, 6000.0, 0.45)
		if b >= 2:
			add_sample(drums, bar0, K, 0.6)
			add_sample(drums, bar0 + 8 * step, K, 0.45)
			add_sample(drums, bar0 + 12 * step, OH, 0.08)
	var wet := delay_fx(bells, step * 3, 0.5)
	var out := PackedFloat32Array()
	out.resize(total)
	for i in total:
		out[i] = low[i] + wet[i] + drums[i] * 0.7
	return normalize(out, 0.85)

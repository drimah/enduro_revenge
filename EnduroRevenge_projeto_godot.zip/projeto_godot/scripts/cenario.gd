extends Node3D
## Script da raiz de qualquer peca de cenario (ruinas, arvores, carcacas...).
## Coloque seu modelo 3D como filho deste no. Ele e posicionado dos dois lados da pista.

## Distancia minima do centro da pista (metros). A pista tem 6 m para cada lado.
@export var dist_min := 10.0
## Distancia maxima do centro da pista (metros)
@export var dist_max := 22.0
## Gira aleatoriamente no eixo Y cada vez que reaparece
@export var rotacao_aleatoria := true
## Chance relativa de aparecer
@export var peso := 1.0

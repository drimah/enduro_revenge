extends Node
## Gerenciador de audio: efeitos sonoros e loops sintetizados por codigo,
## musica renderizada em segundo plano (thread).

const Music := preload("res://scripts/music.gd")
const RATE := 22050

var sfx := {}
var pool: Array = []
var engine: AudioStreamPlayer
var wind: AudioStreamPlayer
var rumble: AudioStreamPlayer
var rain: AudioStreamPlayer
var music: AudioStreamPlayer
var music_streams := {}
var wanted_music := ""
var music_enabled := true
var _thread: Thread
var _next := 0


func _ready() -> void:
	sfx["crash"] = _wav(_gen_crash())
	sfx["pass"] = _wav(_gen_sweep([880.0, 1320.0], 0.06, 1, 0.35))
	sfx["overtaken"] = _wav(_gen_glide(520.0, 230.0, 0.22, 0.4))
	sfx["beep"] = _wav(_gen_sweep([660.0], 0.16, 1, 0.45))
	sfx["go"] = _wav(_gen_sweep([1320.0], 0.5, 1, 0.45))
	sfx["levelup"] = _wav(_gen_arp([69, 72, 76, 81, 84, 88], 0.08, 0.5))
	sfx["quota"] = _wav(_gen_arp([64, 69, 73, 76, 81], 0.07, 0.6))
	sfx["gameover"] = _wav(_gen_arp([69, 65, 62, 57, 52, 45], 0.2, 0.9))
	sfx["thunder"] = _wav(_gen_thunder())
	sfx["nitro"] = _wav(_gen_nitro())
	sfx["shift"] = _wav(_gen_shift())
	sfx["warn"] = _wav(_gen_sweep([880.0, 0.0, 880.0, 0.0, 880.0], 0.09, 1, 0.3))

	engine = _loop(_gen_engine(), -80.0)
	wind = _loop(_gen_noise_loop(2.0, 500.0, false, true), -80.0)
	rumble = _loop(_gen_noise_loop(1.5, 110.0, false, false), -80.0)
	rain = _loop(_gen_noise_loop(2.0, 1800.0, true, false), -80.0)
	for i in 14:
		var p := AudioStreamPlayer.new()
		add_child(p)
		pool.append(p)
	music = AudioStreamPlayer.new()
	music.volume_db = -4.0
	add_child(music)
	_thread = Thread.new()
	_thread.start(_render_music_thread)


func _exit_tree() -> void:
	if _thread and _thread.is_started():
		_thread.wait_to_finish()
		_thread = null


# ---------------------------------------------------------------- API
func play(name: String, vol_db := 0.0, pitch := 1.0) -> void:
	if not sfx.has(name):
		return
	var p: AudioStreamPlayer = null
	for q in pool:
		if not q.playing:
			p = q
			break
	if p == null:
		p = pool[_next % pool.size()]
		_next += 1
	p.stream = sfx[name]
	p.volume_db = vol_db
	p.pitch_scale = pitch
	p.play()


func set_engine(pitch: float, vol_db: float) -> void:
	engine.pitch_scale = clampf(pitch, 0.3, 4.0)
	engine.volume_db = vol_db


func set_loop(which: String, amount: float, max_db: float, pitch := 1.0) -> void:
	var p: AudioStreamPlayer = get(which)
	if p == null:
		return
	amount = clampf(amount, 0.0, 1.0)
	p.volume_db = -80.0 if amount < 0.001 else linear_to_db(amount) + max_db
	p.pitch_scale = pitch


func silence_loops() -> void:
	engine.volume_db = -80.0
	for n in ["wind", "rumble", "rain"]:
		set_loop(n, 0.0, 0.0)


func set_paused(on: bool) -> void:
	for p in [engine, wind, rumble, rain, music]:
		p.stream_paused = on


func play_music(name: String) -> void:
	wanted_music = name
	if not music_enabled:
		return
	if music_streams.has(name):
		if music.stream != music_streams[name] or not music.playing:
			music.stream = music_streams[name]
			music.play()


func stop_music() -> void:
	wanted_music = ""
	music.stop()


func set_music_enabled(on: bool) -> void:
	music_enabled = on
	if on:
		play_music(wanted_music)
	else:
		music.stop()


# ---------------------------------------------------------------- musica (thread)
func _render_music_thread() -> void:
	var menu := Music.render_menu(RATE)
	call_deferred("_music_ready", "menu", Music.to_wav(menu, RATE, true))
	var race := Music.render_race(RATE)
	call_deferred("_music_ready", "race", Music.to_wav(race, RATE, true))


func _music_ready(name: String, stream: AudioStreamWAV) -> void:
	music_streams[name] = stream
	if wanted_music == name:
		play_music(name)
	if name == "race" and _thread:
		_thread.wait_to_finish()
		_thread = null


# ---------------------------------------------------------------- helpers
func _wav(buf: PackedFloat32Array, loop := false) -> AudioStreamWAV:
	return Music.to_wav(buf, RATE, loop)


func _loop(buf: PackedFloat32Array, vol: float) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = _wav(buf, true)
	p.volume_db = vol
	add_child(p)
	p.play()
	return p


func _buf(secs: float) -> PackedFloat32Array:
	var b := PackedFloat32Array()
	b.resize(int(secs * RATE))
	return b


# ---------------------------------------------------------------- geradores
func _gen_crash() -> PackedFloat32Array:
	var b := _buf(1.0)
	var lp := 0.0
	for i in b.size():
		var t := float(i) / RATE
		var w := randf() * 2.0 - 1.0
		lp += (0.04 + 0.6 * exp(-t * 7.0)) * (w - lp)
		var thump := sin(TAU * (70.0 - 35.0 * t) * t) * exp(-t * 7.0)
		var metal := sin(TAU * 1250.0 * t + sin(TAU * 317.0 * t) * 3.0) * exp(-t * 9.0) * 0.3
		var metal2 := sin(TAU * 2310.0 * t + sin(TAU * 91.0 * t) * 5.0) * exp(-t * 14.0) * 0.2
		b[i] = lp * 1.5 * exp(-t * 3.0) + thump * 0.9 + metal + metal2
	return Music.normalize(b, 0.95)


func _gen_sweep(freqs: Array, each: float, wave: int, vol: float) -> PackedFloat32Array:
	var b := _buf(each * freqs.size() + 0.02)
	var seg := int(each * RATE)
	var ph := 0.0
	for i in b.size():
		var k := mini(i / seg, freqs.size() - 1)
		var f: float = freqs[k]
		var lt := float(i - k * seg) / RATE
		if f <= 0.0:
			continue
		ph = fmod(ph + f / RATE, 1.0)
		var x := (1.0 if ph < 0.5 else -1.0) if wave == 1 else sin(TAU * ph)
		var env := minf(1.0, lt * 400.0) * exp(-lt * 6.0)
		if k == freqs.size() - 1:
			env *= maxf(0.0, 1.0 - lt / each)
		b[i] = x * env * vol
	return b


func _gen_glide(f0: float, f1: float, secs: float, vol: float) -> PackedFloat32Array:
	var b := _buf(secs)
	var ph := 0.0
	for i in b.size():
		var t := float(i) / RATE
		var f := lerpf(f0, f1, t / secs)
		ph = fmod(ph + f / RATE, 1.0)
		b[i] = (1.0 if ph < 0.5 else -1.0) * vol * (1.0 - t / secs) * minf(1.0, t * 300.0)
	return b


func _gen_arp(notes: Array, each: float, vol: float) -> PackedFloat32Array:
	var last := 0.6
	var b := _buf(each * (notes.size() - 1) + last)
	for j in notes.size():
		var f := Music.mtof(notes[j])
		var start := int(j * each * RATE)
		var dur := last if j == notes.size() - 1 else each * 1.2
		var n := int(dur * RATE)
		var ph := 0.0
		var ph2 := 0.0
		for i in n:
			if start + i >= b.size():
				break
			var t := float(i) / RATE
			ph = fmod(ph + f / RATE, 1.0)
			ph2 = fmod(ph2 + f * 1.005 / RATE, 1.0)
			var x := (1.0 if ph < 0.5 else -1.0) * 0.6 + (ph2 * 2.0 - 1.0) * 0.4
			b[start + i] += x * vol * exp(-t * (3.0 if j == notes.size() - 1 else 8.0)) * minf(1.0, t * 500.0)
	return b


func _gen_thunder() -> PackedFloat32Array:
	var b := _buf(3.5)
	var lp := 0.0
	var lp2 := 0.0
	for i in b.size():
		var t := float(i) / RATE
		var w := randf() * 2.0 - 1.0
		lp += 0.03 * (w - lp)
		lp2 += 0.02 * (lp - lp2)
		var crack := w * exp(-t * 18.0) * 0.6
		var roll := lp2 * 14.0 * exp(-t * 1.1) * (0.6 + 0.4 * sin(t * 9.0 + sin(t * 3.0) * 2.0))
		b[i] = crack + roll
	return Music.normalize(b, 0.95)


func _gen_nitro() -> PackedFloat32Array:
	var b := _buf(0.9)
	var lp := 0.0
	for i in b.size():
		var t := float(i) / RATE
		var w := randf() * 2.0 - 1.0
		lp += (0.05 + 0.4 * t) * (w - lp)
		var env := minf(1.0, t * 20.0) * exp(-t * 2.5)
		b[i] = (lp * 1.6 + sin(TAU * (120.0 + 300.0 * t) * t) * 0.3) * env
	return Music.normalize(b, 0.8)


func _gen_shift() -> PackedFloat32Array:
	var b := _buf(0.08)
	for i in b.size():
		var t := float(i) / RATE
		b[i] = ((randf() * 2.0 - 1.0) * 0.5 + sin(TAU * 90.0 * t)) * exp(-t * 60.0) * 0.6
	return b


func _gen_engine() -> PackedFloat32Array:
	# 1 segundo, 50 Hz: periodico perfeito para loop.
	var b := _buf(1.0)
	var lp := 0.0
	for i in b.size():
		var t := float(i) / RATE
		var saw := fmod(t * 50.0, 1.0) * 2.0 - 1.0
		var sq := 1.0 if fmod(t * 25.0, 1.0) < 0.5 else -1.0
		var x := saw * 0.5 + sq * 0.3 + sin(TAU * 100.0 * t) * 0.25 + sin(TAU * 150.0 * t) * 0.1 + (randf() * 2.0 - 1.0) * 0.07
		lp += 0.3 * (x - lp)
		b[i] = lp
	return Music.normalize(b, 0.85)


func _gen_noise_loop(secs: float, cutoff: float, highpass: bool, gusts: bool) -> PackedFloat32Array:
	var n := int(secs * RATE)
	var f := int(0.25 * RATE)
	var raw := PackedFloat32Array()
	raw.resize(n + f)
	var k := 1.0 - exp(-TAU * maxf(cutoff, 20.0) / RATE)
	var lp := 0.0
	var lp2 := 0.0
	for i in n + f:
		var w := randf() * 2.0 - 1.0
		lp += k * (w - lp)
		lp2 += k * (lp - lp2)
		var v := (w - lp2) if highpass else lp2
		if gusts:
			v *= 0.7 + 0.3 * sin(TAU * float(i) / n)
		if highpass and randf() < 0.0008:
			v += (randf() - 0.5) * 2.0
		raw[i] = v
	var out := PackedFloat32Array()
	out.resize(n)
	for i in n:
		out[i] = raw[i]
	for i in f:
		var a := float(i) / f
		out[i] = raw[i] * a + raw[n + i] * (1.0 - a)
	return Music.normalize(out, 0.8)

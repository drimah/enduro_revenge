extends Node3D
## ENDURO REVENGE - releitura moderna e pos-apocaliptica de Enduro (Activision, 1983).
## Tudo (modelos, texturas, sons e musica) e gerado por codigo.

const U := preload("res://scripts/util.gd")
const AudioMgr := preload("res://scripts/audio.gd")
const HudScript := preload("res://scripts/hud.gd")
const ROAD_SHADER := preload("res://shaders/road.gdshader")
const GROUND_SHADER := preload("res://shaders/ground.gdshader")

enum { ST_MENU, ST_COUNTDOWN, ST_RACE, ST_PAUSED, ST_GAMEOVER }

const K_CURVE := 0.00042
const K_HILL := 0.00005
const ROAD_HALF := 6.0
const LANES := [-4.0, 0.0, 4.0]
const MAX_SPEED := 62.0
const NITRO_SPEED := 84.0
const DAY_LENGTH := 200.0
const SPAWN_Z := -430.0
const PROP_SPAN := 580.0
const GEARS := [0.0, 14.0, 27.0, 39.0, 50.0, 62.0, 90.0]
const SAVE_PATH := "user://enduro_revenge.cfg"

@export_group("Cenas (arraste suas cenas aqui)")
## Cena do carro do jogador (raiz com scripts/veiculo.gd)
@export var cena_jogador: PackedScene
## Carros inimigos (raiz com scripts/veiculo.gd). Velocidade, chance e dia minimo ficam em cada cena.
@export var cenas_inimigos: Array[PackedScene] = []
## Pecas de cenario na beira da estrada (raiz com scripts/cenario.gd)
@export var cenas_cenario: Array[PackedScene] = []
## Poste refletor que se repete a cada 25 m nos dois lados da pista
@export var cena_poste: PackedScene
## Montanhas e cidade em ruinas no horizonte (fica parado, longe)
@export var cena_horizonte: PackedScene
## Quantas pecas de cenario existem ao mesmo tempo
@export var quantidade_cenario := 70

var state := ST_MENU
var audio
var hud
var cam: Camera3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var sun: DirectionalLight3D
var player: Dictionary
var rain_fx: CPUParticles3D
var dust_fx: CPUParticles3D
var ember_fx: CPUParticles3D
var rng := RandomNumberGenerator.new()
var keys: Array = []
var enemy_info: Array = []

var speed := 0.0
var px := 0.0
var lat_vel := 0.0
var distance := 0.0
var day := 1
var day_t := 0.0
var cars_left := 0
var quota_met := false
var total_passed := 0
var nitro := 1.0
var nitro_on := false
var crash_t := 0.0
var shake := 0.0
var curve := 0.0
var curve_target := 0.0
var next_curve := 300.0
var hill := 0.0
var hill_target := 0.0
var next_hill := 600.0
var countdown := 0.0
var cd_last := -1
var spawn_acc := 0.0
var spawn_gap := 40.0
var spawn_back_acc := 0.0
var enemies: Array = []
var props: Array = []
var posts: Array = []
var lightning_t := 6.0
var flash := 0.0
var thunder_delay := -1.0
var cur_phase := ""
var record_km := 0.0
var record_day := 0
var gear := 1
var rain_amt := 0.0
var dust_amt := 0.0
var night_amt := 0.0
var warn_shown := false
var gameover_t := 0.0
var music_on := true
var time := 0.0
var cam_angle := 0.0


func _ready() -> void:
	rng.randomize()
	_setup_input()
	_load_record()
	_setup_keys()
	_setup_env()
	_read_enemy_info()
	_build_world()
	_build_player()
	cam = Camera3D.new()
	cam.near = 0.1
	cam.far = 2600.0
	cam.fov = 70.0
	add_child(cam)
	cam.current = true
	_build_fx()
	audio = AudioMgr.new()
	add_child(audio)
	hud = HudScript.new()
	add_child(hud)
	Input.joy_connection_changed.connect(_on_joy_changed)
	_on_joy_changed(0, true)
	_enter_menu()


# ================================================================ entrada
func _key(code: Key) -> InputEventKey:
	var e := InputEventKey.new()
	e.physical_keycode = code
	e.device = -1
	return e


func _jb(b: JoyButton) -> InputEventJoypadButton:
	var e := InputEventJoypadButton.new()
	e.button_index = b
	e.device = -1
	return e


func _ja(axis: JoyAxis, v: float) -> InputEventJoypadMotion:
	var e := InputEventJoypadMotion.new()
	e.axis = axis
	e.axis_value = v
	e.device = -1
	return e


func _act(name: String, events: Array, dz := 0.2) -> void:
	if InputMap.has_action(name):
		InputMap.erase_action(name)
	InputMap.add_action(name, dz)
	for e in events:
		InputMap.action_add_event(name, e)


func _setup_input() -> void:
	_act("accel", [_key(KEY_UP), _key(KEY_W), _jb(JOY_BUTTON_A), _ja(JOY_AXIS_TRIGGER_RIGHT, 1.0)], 0.1)
	_act("brake", [_key(KEY_DOWN), _key(KEY_S), _jb(JOY_BUTTON_B), _ja(JOY_AXIS_TRIGGER_LEFT, 1.0)], 0.1)
	_act("left", [_key(KEY_LEFT), _key(KEY_A), _jb(JOY_BUTTON_DPAD_LEFT), _ja(JOY_AXIS_LEFT_X, -1.0)], 0.18)
	_act("right", [_key(KEY_RIGHT), _key(KEY_D), _jb(JOY_BUTTON_DPAD_RIGHT), _ja(JOY_AXIS_LEFT_X, 1.0)], 0.18)
	_act("nitro", [_key(KEY_SHIFT), _key(KEY_SPACE), _jb(JOY_BUTTON_X), _jb(JOY_BUTTON_Y), _jb(JOY_BUTTON_RIGHT_SHOULDER)])
	_act("pause", [_key(KEY_ESCAPE), _key(KEY_P), _jb(JOY_BUTTON_START)])
	_act("start", [_key(KEY_ENTER), _key(KEY_KP_ENTER), _key(KEY_SPACE), _jb(JOY_BUTTON_A), _jb(JOY_BUTTON_START)])
	_act("menu_back", [_key(KEY_Q), _key(KEY_BACKSPACE), _jb(JOY_BUTTON_Y), _jb(JOY_BUTTON_BACK)])
	_act("music", [_key(KEY_M)])
	_act("fullscreen", [_key(KEY_F11)])


func _on_joy_changed(_id: int, _connected: bool) -> void:
	if hud == null:
		return
	var pads := Input.get_connected_joypads()
	if pads.is_empty():
		hud.set_pad("CONTROLE: TECLADO")
	else:
		hud.set_pad("JOYSTICK: %s" % Input.get_joy_name(pads[0]))


func _vibrate(weak: float, strong: float, dur: float) -> void:
	for id in Input.get_connected_joypads():
		Input.start_joy_vibration(id, weak, strong, dur)


# ================================================================ ciclo do dia
func _kf(t: float, name: String, top: Color, hor: Color, sun_c: Color, sun_e: float, amb: Color, amb_e: float, fog: Color, fog_d: float, elev: float, rain: float, dust: float) -> Dictionary:
	return {"t": t, "name": name, "top": top, "hor": hor, "sun": sun_c, "sun_e": sun_e, "amb": amb, "amb_e": amb_e,
		"fog": fog, "fog_d": fog_d, "elev": elev, "rain": rain, "dust": dust}


func _setup_keys() -> void:
	var dawn := _kf(0.0, "AMANHECER TÓXICO", Color(0.22, 0.14, 0.32), Color(0.95, 0.45, 0.25), Color(1.0, 0.55, 0.35), 0.9, Color(0.55, 0.42, 0.45), 0.45, Color(0.7, 0.45, 0.35), 0.0025, 8.0, 0.0, 0.0)
	var day_k := _kf(0.12, "DIA ESCALDANTE", Color(0.42, 0.40, 0.30), Color(0.95, 0.75, 0.45), Color(1.0, 0.88, 0.65), 1.7, Color(0.85, 0.75, 0.6), 0.7, Color(0.85, 0.7, 0.5), 0.0016, 55.0, 0.0, 0.0)
	keys = [
		dawn,
		day_k,
		_kf(0.29, "DIA ESCALDANTE", day_k.top, day_k.hor, day_k.sun, 1.7, day_k.amb, 0.7, day_k.fog, 0.0018, 52.0, 0.0, 0.05),
		_kf(0.35, "TEMPESTADE DE AREIA", Color(0.45, 0.3, 0.18), Color(0.6, 0.4, 0.22), Color(0.9, 0.6, 0.35), 0.45, Color(0.6, 0.42, 0.28), 0.65, Color(0.55, 0.38, 0.22), 0.03, 48.0, 0.0, 1.0),
		_kf(0.46, "TEMPESTADE DE AREIA", Color(0.45, 0.3, 0.18), Color(0.6, 0.4, 0.22), Color(0.9, 0.6, 0.35), 0.45, Color(0.6, 0.42, 0.28), 0.65, Color(0.55, 0.38, 0.22), 0.03, 40.0, 0.0, 1.0),
		_kf(0.52, "TARDE CINZENTA", Color(0.38, 0.34, 0.3), Color(0.85, 0.65, 0.45), Color(1.0, 0.8, 0.55), 1.3, Color(0.75, 0.62, 0.5), 0.6, Color(0.75, 0.6, 0.45), 0.0022, 30.0, 0.0, 0.1),
		_kf(0.62, "PÔR DO SOL RADIOATIVO", Color(0.16, 0.24, 0.14), Color(1.0, 0.35, 0.15), Color(1.0, 0.4, 0.2), 1.0, Color(0.55, 0.35, 0.3), 0.45, Color(0.7, 0.3, 0.2), 0.0028, 5.0, 0.0, 0.0),
		_kf(0.70, "CREPÚSCULO", Color(0.07, 0.05, 0.14), Color(0.35, 0.12, 0.25), Color(0.6, 0.2, 0.4), 0.12, Color(0.25, 0.2, 0.35), 0.28, Color(0.2, 0.1, 0.18), 0.004, -4.0, 0.0, 0.0),
		_kf(0.76, "NOITE · CHUVA ÁCIDA", Color(0.01, 0.012, 0.02), Color(0.03, 0.07, 0.045), Color(0.3, 0.4, 0.5), 0.0, Color(0.1, 0.18, 0.12), 0.12, Color(0.025, 0.05, 0.035), 0.006, -20.0, 1.0, 0.0),
		_kf(0.89, "NOITE · CHUVA ÁCIDA", Color(0.01, 0.012, 0.02), Color(0.03, 0.07, 0.045), Color(0.3, 0.4, 0.5), 0.0, Color(0.1, 0.18, 0.12), 0.12, Color(0.025, 0.05, 0.035), 0.006, -20.0, 1.0, 0.0),
		_kf(0.94, "NÉVOA RADIOATIVA", Color(0.05, 0.1, 0.06), Color(0.25, 0.4, 0.25), Color(0.5, 0.8, 0.5), 0.0, Color(0.3, 0.45, 0.3), 0.35, Color(0.3, 0.45, 0.3), 0.028, -6.0, 0.0, 0.0),
		_kf(1.0, dawn.name, dawn.top, dawn.hor, dawn.sun, dawn.sun_e, dawn.amb, dawn.amb_e, dawn.fog, dawn.fog_d, dawn.elev, 0.0, 0.0),
	]


func _apply_daytime(t: float) -> void:
	var a: Dictionary = keys[0]
	var b: Dictionary = keys[1]
	for i in keys.size() - 1:
		if t >= keys[i].t and t <= keys[i + 1].t:
			a = keys[i]
			b = keys[i + 1]
			break
	var f: float = (t - a.t) / maxf(0.0001, b.t - a.t)
	f = f * f * (3.0 - 2.0 * f)
	var top: Color = a.top.lerp(b.top, f)
	var hor: Color = a.hor.lerp(b.hor, f)
	sky_mat.sky_top_color = top
	sky_mat.sky_horizon_color = hor
	sky_mat.ground_horizon_color = hor.darkened(0.3)
	sky_mat.ground_bottom_color = hor.darkened(0.75)
	var sun_e: float = lerpf(a.sun_e, b.sun_e, f)
	var elev: float = lerpf(a.elev, b.elev, f)
	sun.light_color = a.sun.lerp(b.sun, f)
	sun.light_energy = sun_e if elev > -2.0 else 0.0
	sun.rotation_degrees = Vector3(-maxf(elev, 2.0), 35.0, 0.0)
	env.ambient_light_color = a.amb.lerp(b.amb, f)
	env.ambient_light_energy = lerpf(a.amb_e, b.amb_e, f) + flash * 3.0
	env.background_energy_multiplier = 1.0 + flash * 4.0
	env.fog_light_color = a.fog.lerp(b.fog, f)
	env.fog_density = lerpf(a.fog_d, b.fog_d, f)
	rain_amt = lerpf(a.rain, b.rain, f)
	dust_amt = lerpf(a.dust, b.dust, f)
	night_amt = 1.0 - clampf(sun_e / 0.6, 0.0, 1.0)
	var phase: String = a.name if f < 0.5 else b.name
	if phase != cur_phase:
		cur_phase = phase
		if state == ST_RACE and t > 0.01:
			hud.show_message(phase, "", Color(0.95, 0.92, 0.85), 1.8)
	RenderingServer.global_shader_parameter_set("road_wet", rain_amt)


# ================================================================ construcao
func _setup_env() -> void:
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sun_angle_max = 20.0
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_white = 6.0
	env.glow_enabled = true
	env.glow_intensity = 0.9
	env.glow_bloom = 0.08
	env.glow_hdr_threshold = 0.9
	env.fog_enabled = true
	env.fog_sky_affect = 0.75
	env.adjustment_enabled = true
	env.adjustment_contrast = 1.1
	env.adjustment_saturation = 0.92
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 160.0
	add_child(sun)


func _build_world() -> void:
	var road := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(17.0, 1000.0)
	pm.subdivide_depth = 330
	pm.subdivide_width = 4
	road.mesh = pm
	var rm := ShaderMaterial.new()
	rm.shader = ROAD_SHADER
	road.material_override = rm
	road.position = Vector3(0, 0.04, -450.0)
	road.extra_cull_margin = 3000.0
	road.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(road)

	var ground := MeshInstance3D.new()
	var gm := PlaneMesh.new()
	gm.size = Vector2(3400.0, 2000.0)
	gm.subdivide_depth = 260
	gm.subdivide_width = 6
	ground.mesh = gm
	var gmat := ShaderMaterial.new()
	gmat.shader = GROUND_SHADER
	ground.material_override = gmat
	ground.position = Vector3(0, 0.0, -900.0)
	ground.extra_cull_margin = 3000.0
	ground.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ground)

	if cena_horizonte:
		var sky_node := cena_horizonte.instantiate()
		U.bendify(sky_node)
		add_child(sky_node)

	var weights := []
	var total_w := 0.0
	for sc in cenas_cenario:
		var w := 1.0
		var tmp := sc.instantiate()
		if "peso" in tmp:
			w = tmp.peso
		tmp.free()
		weights.append(w)
		total_w += w
	var n := quantidade_cenario if not cenas_cenario.is_empty() else 0
	for i in n:
		var r := rng.randf() * total_w
		var idx := 0
		while idx < weights.size() - 1 and r > weights[idx]:
			r -= weights[idx]
			idx += 1
		var inst: Node3D = cenas_cenario[idx].instantiate()
		U.bendify(inst)
		var holder := Node3D.new()
		holder.add_child(inst)
		add_child(holder)
		var p := {"node": holder, "inst": inst, "z": 20.0 - PROP_SPAN * float(i) / n + rng.randf_range(-4, 4), "side": 1.0}
		_place_prop(p)
		props.append(p)

	if cena_poste:
		for i in 24:
			for side in [-1.0, 1.0]:
				var post: Node3D = cena_poste.instantiate()
				U.bendify(post)
				post.position.x = side * 7.6
				add_child(post)
				posts.append(post)


func _build_player() -> void:
	if cena_jogador == null:
		push_error("Defina a cena do jogador no no Main (Cena Jogador).")
		var empty := Node3D.new()
		add_child(empty)
		player = {"node": empty, "body": empty, "wheels": [], "flames": [], "nitro_flames": [], "lights": [], "nitro_light": null, "hw": 1.15, "hl": 2.1}
		return
	var node: Node3D = cena_jogador.instantiate()
	U.bendify(node)
	add_child(node)
	var body: Node3D = node.get_node_or_null("Corpo")
	if body == null:
		body = node
	var ext := U.extents(node)
	var hw: float = node.half_width if "half_width" in node and node.half_width > 0.0 else ext.x
	var hl: float = node.half_length if "half_length" in node and node.half_length > 0.0 else ext.y
	var nl := U.in_group(node, "luz_nitro")
	player = {"node": node, "body": body, "wheels": U.wheels(node), "flames": U.in_group(node, "chamas"),
		"nitro_flames": U.in_group(node, "chamas_nitro"), "lights": U.in_group(node, "farois"),
		"nitro_light": nl[0] if not nl.is_empty() else null, "hw": hw, "hl": hl}


func _read_enemy_info() -> void:
	enemy_info.clear()
	for sc in cenas_inimigos:
		if sc == null:
			continue
		var tmp := sc.instantiate()
		var info := {"scene": sc, "min": 26.0, "max": 37.0, "weave": false, "peso": 1.0, "peso_dia": 0.0, "dia": 1, "back": false, "hw": 0.0, "hl": 0.0}
		if "min_speed" in tmp:
			info.min = tmp.min_speed
			info.max = tmp.max_speed
			info.weave = tmp.troca_faixa
			info.peso = tmp.peso_spawn
			info.peso_dia = tmp.peso_por_dia
			info.dia = tmp.dia_minimo
			info.back = tmp.pode_vir_por_tras
			info.hw = tmp.half_width
			info.hl = tmp.half_length
		if info.hw <= 0.0 or info.hl <= 0.0:
			var ext := U.extents(tmp)
			if info.hw <= 0.0:
				info.hw = ext.x
			if info.hl <= 0.0:
				info.hl = ext.y
		tmp.free()
		enemy_info.append(info)


func _place_prop(p: Dictionary) -> void:
	var node: Node3D = p.node
	var inst: Node3D = p.inst
	p.side = 1.0 if rng.randf() < 0.5 else -1.0
	var dmin := 10.0
	var dmax := 22.0
	var rot := true
	if "dist_min" in inst:
		dmin = inst.dist_min
		dmax = inst.dist_max
		rot = inst.rotacao_aleatoria
	var x := rng.randf_range(dmin, maxf(dmin, dmax))
	node.position = Vector3(p.side * x, 0.0, p.z)
	if rot:
		node.rotation.y = rng.randf() * TAU
	else:
		node.rotation.y = 0.0 if p.side > 0.0 else PI


func _build_fx() -> void:
	# chuva acida
	rain_fx = CPUParticles3D.new()
	rain_fx.amount = 1600
	rain_fx.lifetime = 0.8
	rain_fx.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	rain_fx.emission_box_extents = Vector3(26, 1, 40)
	rain_fx.position = Vector3(0, 16, -22)
	rain_fx.direction = Vector3(0, -1, 0)
	rain_fx.spread = 4.0
	rain_fx.initial_velocity_min = 26.0
	rain_fx.initial_velocity_max = 34.0
	rain_fx.local_coords = false
	var rmesh := BoxMesh.new()
	rmesh.size = Vector3(0.025, 0.8, 0.025)
	var rmat := StandardMaterial3D.new()
	rmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rmat.albedo_color = Color(0.6, 1.0, 0.45, 0.45)
	rmesh.material = rmat
	rain_fx.mesh = rmesh
	rain_fx.emitting = false
	add_child(rain_fx)

	# poeira da tempestade
	dust_fx = CPUParticles3D.new()
	dust_fx.amount = 420
	dust_fx.lifetime = 2.4
	dust_fx.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	dust_fx.emission_box_extents = Vector3(40, 4, 50)
	dust_fx.position = Vector3(0, 3, -30)
	dust_fx.direction = Vector3(1, 0, 0.2)
	dust_fx.spread = 20.0
	dust_fx.initial_velocity_min = 10.0
	dust_fx.initial_velocity_max = 22.0
	dust_fx.local_coords = false
	dust_fx.scale_amount_min = 1.0
	dust_fx.scale_amount_max = 3.0
	var dmesh := QuadMesh.new()
	dmesh.size = Vector2(1.6, 1.6)
	var dmat := StandardMaterial3D.new()
	dmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	dmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	dmat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	dmat.vertex_color_use_as_albedo = true
	dmat.albedo_color = Color(0.62, 0.46, 0.3, 1.0)
	var soft := GradientTexture2D.new()
	soft.fill = GradientTexture2D.FILL_RADIAL
	soft.fill_from = Vector2(0.5, 0.5)
	soft.fill_to = Vector2(1.0, 0.5)
	soft.width = 64
	soft.height = 64
	var sg := Gradient.new()
	sg.set_color(0, Color(1, 1, 1, 1))
	sg.set_color(1, Color(1, 1, 1, 0))
	soft.gradient = sg
	dmat.albedo_texture = soft
	dmesh.material = dmat
	dust_fx.mesh = dmesh
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 0.0))
	g.set_color(1, Color(1, 1, 1, 0.0))
	g.add_point(0.3, Color(1, 1, 1, 0.3))
	g.add_point(0.7, Color(1, 1, 1, 0.25))
	dust_fx.color_ramp = g
	dust_fx.emitting = false
	add_child(dust_fx)

	# brasas / cinzas flutuando
	ember_fx = CPUParticles3D.new()
	ember_fx.amount = 160
	ember_fx.lifetime = 3.0
	ember_fx.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	ember_fx.emission_box_extents = Vector3(30, 6, 40)
	ember_fx.position = Vector3(0, 4, -25)
	ember_fx.direction = Vector3(0.3, 1, 0)
	ember_fx.spread = 40.0
	ember_fx.initial_velocity_min = 0.5
	ember_fx.initial_velocity_max = 2.0
	ember_fx.local_coords = false
	var emesh := QuadMesh.new()
	emesh.size = Vector2(0.09, 0.09)
	var emat := StandardMaterial3D.new()
	emat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	emat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	emat.albedo_color = Color(1.0, 0.5, 0.1)
	emat.emission_enabled = true
	emat.emission = Color(1.0, 0.45, 0.08)
	emat.emission_energy_multiplier = 4.0
	emesh.material = emat
	ember_fx.mesh = emesh
	add_child(ember_fx)


# ================================================================ estados
func _enter_menu() -> void:
	state = ST_MENU
	_clear_enemies()
	speed = 26.0
	px = 0.0
	lat_vel = 0.0
	nitro_on = false
	day_t = rng.randf_range(0.0, 0.2)
	cur_phase = ""
	audio.set_paused(false)
	audio.play_music("menu")
	hud.lbl_msg.text = ""
	hud.lbl_sub.text = ""
	hud.set_record(record_km, record_day)
	hud.show_menu(record_km, record_day)


func _start_game() -> void:
	_clear_enemies()
	speed = 0.0
	px = 0.0
	lat_vel = 0.0
	distance = 0.0
	day = 1
	day_t = 0.0
	cur_phase = ""
	cars_left = _quota(1)
	quota_met = false
	total_passed = 0
	nitro = 1.0
	nitro_on = false
	crash_t = 0.0
	curve = 0.0
	curve_target = 0.0
	next_curve = 350.0
	hill = 0.0
	hill_target = 0.0
	next_hill = 700.0
	spawn_acc = 0.0
	spawn_back_acc = 0.0
	spawn_gap = 40.0
	warn_shown = false
	countdown = 3.6
	cd_last = -1
	state = ST_COUNTDOWN
	audio.set_paused(false)
	audio.stop_music()
	hud.hide_overlay()
	hud.set_record(record_km, record_day)
	_apply_daytime(0.0)


func _quota(d: int) -> int:
	return mini(70 + (d - 1) * 25, 200)


func _clear_enemies() -> void:
	for e in enemies:
		e.node.queue_free()
	enemies.clear()


func _pause(on: bool) -> void:
	if on:
		state = ST_PAUSED
		hud.show_pause()
	else:
		state = ST_RACE
		hud.hide_overlay()
	audio.set_paused(on)
	for fx in [rain_fx, dust_fx, ember_fx]:
		fx.speed_scale = 0.0 if on else 1.0


func _game_over() -> void:
	state = ST_GAMEOVER
	gameover_t = 0.0
	nitro_on = false
	var km := distance / 1000.0
	var is_rec := km > record_km
	if is_rec:
		record_km = km
		record_day = day
		_save_record()
	audio.play("gameover")
	audio.play_music("menu")
	hud.show_gameover(day, km, total_passed, is_rec)


# ================================================================ loop
func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	time += delta
	if Input.is_action_just_pressed("fullscreen"):
		var full := DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if full else DisplayServer.WINDOW_MODE_FULLSCREEN)
	if Input.is_action_just_pressed("music"):
		music_on = not music_on
		audio.set_music_enabled(music_on)

	match state:
		ST_MENU:
			_update_menu(delta)
		ST_COUNTDOWN:
			_update_countdown(delta)
		ST_RACE:
			_update_race(delta)
		ST_PAUSED:
			if Input.is_action_just_pressed("pause"):
				_pause(false)
			elif Input.is_action_just_pressed("menu_back"):
				_enter_menu()
		ST_GAMEOVER:
			_update_gameover(delta)


func _update_menu(delta: float) -> void:
	day_t = fmod(day_t + delta / 70.0, 1.0)
	speed = 26.0
	px = lerpf(px, sin(time * 0.3) * 2.5, delta)
	_update_world(delta)
	_update_player_visual(delta, 0.6)
	cam_angle += delta * 0.18
	var target := Vector3(px, 1.0, 0.0)
	cam.position = target + Vector3(sin(cam_angle) * 9.0, 3.2 + sin(cam_angle * 0.7) * 1.2, cos(cam_angle) * 9.0)
	cam.look_at(target + Vector3(0, 0.6, 0), Vector3.UP)
	cam.fov = 60.0
	_update_audio(0.5, false)
	if Input.is_action_just_pressed("start"):
		_start_game()


func _update_countdown(delta: float) -> void:
	countdown -= delta
	var n := int(ceil(countdown - 0.6))
	if n != cd_last and n >= 1 and n <= 3:
		cd_last = n
		hud.show_message(str(n), "DIA 1 · ULTRAPASSE %d CARROS" % cars_left, Color(1.0, 0.55, 0.12), 0.9)
		audio.play("beep")
	if countdown <= 0.6 and cd_last != 0:
		cd_last = 0
		hud.show_message("VAI!", "", Color(0.62, 1.0, 0.22), 1.0)
		audio.play("go")
		audio.play_music("race")
		state = ST_RACE
	speed = 0.0
	_update_world(delta)
	_update_player(delta, false)
	_update_camera(delta)
	_update_audio(0.0 if Input.get_action_strength("accel") < 0.1 else 1.0, true)
	_update_hud()


func _update_race(delta: float) -> void:
	if Input.is_action_just_pressed("pause"):
		_pause(true)
		return
	day_t += delta / DAY_LENGTH
	if day_t >= 1.0:
		day_t -= 1.0
		_end_of_day()
		if state != ST_RACE:
			return
	if not quota_met and not warn_shown and day_t > 0.88:
		warn_shown = true
		hud.show_message("O DIA ESTÁ ACABANDO!", "Faltam %d carros" % cars_left, Color(1.0, 0.25, 0.2), 3.0)
		audio.play("warn")
	_update_player(delta, true)
	_update_world(delta)
	_spawn_logic(delta)
	_check_collisions()
	_update_camera(delta)
	_update_audio(Input.get_action_strength("accel"), true)
	_update_hud()


func _update_gameover(delta: float) -> void:
	gameover_t += delta
	speed = move_toward(speed, 0.0, 20.0 * delta)
	day_t = minf(day_t + delta / DAY_LENGTH, 0.999)
	_update_world(delta)
	_update_player_visual(delta, 0.0)
	_update_camera(delta)
	_update_audio(0.0, true)
	if gameover_t > 1.2:
		if Input.is_action_just_pressed("start"):
			_start_game()
		elif Input.is_action_just_pressed("menu_back"):
			_enter_menu()


func _end_of_day() -> void:
	if quota_met:
		day += 1
		cars_left = _quota(day)
		quota_met = false
		warn_shown = false
		audio.play("levelup")
		hud.show_message("DIA %d" % day, "Ultrapasse %d carros antes do próximo amanhecer" % cars_left, Color(0.62, 1.0, 0.22), 3.5)
	else:
		_game_over()


# ================================================================ jogador
func _update_player(delta: float, controls: bool) -> void:
	var acc := Input.get_action_strength("accel") if controls else 0.0
	var brk := Input.get_action_strength("brake") if controls else 0.0
	var steer := (Input.get_action_strength("right") - Input.get_action_strength("left")) if controls else 0.0
	if crash_t > 0.0:
		crash_t -= delta
		acc = 0.0

	var want_nitro := controls and Input.is_action_pressed("nitro") and nitro > 0.02 and acc > 0.1 and crash_t <= 0.0
	if want_nitro and not nitro_on:
		audio.play("nitro", -2.0)
		_vibrate(0.4, 0.0, 0.3)
	nitro_on = want_nitro
	if nitro_on:
		nitro = maxf(0.0, nitro - delta * 0.3)
	else:
		nitro = minf(1.0, nitro + delta * 0.03)

	var offroad := absf(px) > ROAD_HALF - 0.5
	var maxs := NITRO_SPEED if nitro_on else MAX_SPEED
	if offroad:
		maxs = 26.0
	if acc > 0.05 and speed < maxs:
		speed += acc * (16.0 * (1.0 - speed / maxs) + 2.5) * delta * (1.9 if nitro_on else 1.0)
	elif acc <= 0.05:
		speed -= (3.0 + speed * 0.03) * delta
	if speed > maxs:
		speed = move_toward(speed, maxs, (30.0 if offroad else 10.0) * delta)
	if brk > 0.05:
		speed -= brk * 38.0 * delta
	speed = clampf(speed, 0.0, NITRO_SPEED)

	var grip := 10.0 - 6.5 * rain_amt
	var steer_max := 13.0 * clampf(speed / 18.0, 0.0, 1.0)
	lat_vel = lerpf(lat_vel, steer * steer_max, clampf(grip * delta, 0.0, 1.0))
	px += lat_vel * delta
	px -= curve * speed * 0.11 * delta
	if absf(px) > 10.5:
		px = signf(px) * 10.5
		lat_vel = 0.0
	if offroad and speed > 4.0:
		shake = maxf(shake, 0.12 + speed / 220.0)
	_update_player_visual(delta, acc)


func _update_player_visual(delta: float, acc: float) -> void:
	var node: Node3D = player.node
	var body: Node3D = player.body
	var offroad := absf(px) > ROAD_HALF - 0.5
	var bob := sin(time * 23.0) * 0.03 * (1.0 if offroad else 0.25) * clampf(speed / 30.0, 0.0, 1.0)
	node.position = Vector3(px, 0.0, 0.0)
	body.position.y = bob
	var yaw := -lat_vel * 0.022
	if crash_t > 0.0:
		yaw += sin(time * 26.0) * 0.28 * crash_t
	node.rotation.y = lerpf(node.rotation.y, yaw, clampf(delta * 10.0, 0.0, 1.0))
	body.rotation.z = lerpf(body.rotation.z, lat_vel * 0.012, clampf(delta * 6.0, 0.0, 1.0))
	body.rotation.x = lerpf(body.rotation.x, (acc * 0.025 if not nitro_on else 0.05), clampf(delta * 4.0, 0.0, 1.0))
	for w in player.wheels:
		w.rotation.x -= speed * delta / 0.5
	var fl := 0.25 + acc * 0.6
	if nitro_on:
		fl = 1.6 + sin(time * 50.0) * 0.3
	for f in player.flames:
		f.scale = Vector3(1.0, fl, 1.0) * (0.9 + randf() * 0.2)
		f.visible = not nitro_on and (fl > 0.3 or randf() < 0.3)
	for f in player.nitro_flames:
		f.visible = nitro_on
		f.scale = Vector3(1.0, 0.8 + randf() * 0.5, 1.0)
	if player.nitro_light:
		player.nitro_light.light_energy = 3.0 if nitro_on else 0.0
	var lights_on := night_amt > 0.35 or env.fog_density > 0.02
	for l in player.lights:
		l.visible = lights_on


func _update_camera(delta: float) -> void:
	var target := Vector3(px * 0.75, 3.3 + speed * 0.008, 8.2 - speed * 0.02)
	cam.position = cam.position.lerp(target, clampf(delta * 6.0, 0.0, 1.0))
	shake = maxf(0.0, shake - delta * 2.2)
	var sh := Vector3(randf() - 0.5, randf() - 0.5, 0.0) * shake * 0.5
	cam.position += sh
	cam.look_at(Vector3(px * 0.9, 1.2, -25.0), Vector3.UP)
	cam.rotate_object_local(Vector3(0, 0, 1), -curve * 0.05 - lat_vel * 0.003)
	var fov_t := 68.0 + speed * 0.2 + (10.0 if nitro_on else 0.0)
	cam.fov = lerpf(cam.fov, fov_t, clampf(delta * 3.0, 0.0, 1.0))


# ================================================================ mundo
func _update_world(delta: float) -> void:
	distance += speed * delta
	if distance > next_curve:
		next_curve = distance + rng.randf_range(350.0, 1100.0)
		var opts := [-1.0, -0.6, 0.0, 0.0, 0.6, 1.0]
		curve_target = opts[rng.randi() % opts.size()]
	if distance > next_hill:
		next_hill = distance + rng.randf_range(500.0, 1400.0)
		hill_target = rng.randf_range(-1.0, 1.0)
	curve = move_toward(curve, curve_target, delta * 0.22 * clampf(speed / 30.0, 0.15, 1.5))
	hill = move_toward(hill, hill_target, delta * 0.15)
	RenderingServer.global_shader_parameter_set("road_curve", curve * K_CURVE)
	RenderingServer.global_shader_parameter_set("road_hill", hill * K_HILL)
	RenderingServer.global_shader_parameter_set("road_scroll", distance)

	for p in props:
		p.z += speed * delta
		if p.z > 30.0:
			p.z -= PROP_SPAN
			_place_prop(p)
		p.node.position.z = p.z

	var off := fmod(distance, 25.0)
	var half := posts.size() / 2
	for i in posts.size():
		var post: Node3D = posts[i]
		post.position.z = -560.0 + float(i % half) * 25.0 + off

	_update_enemies(delta)
	_apply_daytime(day_t)
	_update_weather(delta)


func _update_weather(delta: float) -> void:
	rain_fx.emitting = rain_amt > 0.4
	dust_fx.emitting = dust_amt > 0.4
	ember_fx.emitting = night_amt < 0.9 and dust_amt < 0.5
	rain_fx.position.x = px
	dust_fx.position.x = px
	ember_fx.position.x = px
	rain_fx.gravity = Vector3(0, -20, speed * 0.9)
	dust_fx.gravity = Vector3(6, -0.3, speed * 1.2)
	ember_fx.gravity = Vector3(0.5, 0.2, speed * 1.0)

	flash = maxf(0.0, flash - delta * 3.5)
	if flash > 0.0 and randf() < 0.3:
		flash *= 0.4
	if (rain_amt > 0.5 or dust_amt > 0.6) and state != ST_PAUSED:
		lightning_t -= delta
		if lightning_t <= 0.0:
			lightning_t = rng.randf_range(4.0, 11.0)
			flash = 1.0
			thunder_delay = rng.randf_range(0.25, 1.4)
	if thunder_delay > 0.0:
		thunder_delay -= delta
		if thunder_delay <= 0.0:
			audio.play("thunder", rng.randf_range(-6.0, 0.0), rng.randf_range(0.85, 1.1))
			_vibrate(0.2, 0.4, 0.4)


# ================================================================ inimigos
func _spawn_logic(delta: float) -> void:
	spawn_acc += maxf(speed - 22.0, 0.0) * delta
	if spawn_acc >= spawn_gap:
		spawn_acc = 0.0
		var base := maxf(17.0, 40.0 - day * 3.5)
		spawn_gap = rng.randf_range(base * 0.6, base * 1.4)
		_spawn_enemy(true)
	spawn_back_acc += maxf(30.0 - speed, 0.0) * delta
	if spawn_back_acc >= 60.0:
		spawn_back_acc = 0.0
		_spawn_enemy(false)


func _pick_info(ahead: bool) -> Dictionary:
	var cands := []
	var total := 0.0
	for info in enemy_info:
		if info.dia > day:
			continue
		if not ahead and not info.back:
			continue
		var w: float = info.peso + info.peso_dia * (day - 1)
		if w <= 0.0:
			continue
		cands.append([info, w])
		total += w
	if cands.is_empty():
		return {}
	var r := rng.randf() * total
	for c in cands:
		r -= c[1]
		if r <= 0.0:
			return c[0]
	return cands[-1][0]


func _spawn_enemy(ahead: bool) -> void:
	if enemies.size() >= 18:
		return
	var z := SPAWN_Z if ahead else 45.0
	var near := 0
	for e in enemies:
		if absf(e.z - z) < 20.0:
			near += 1
	if near >= 2:
		return
	var free_lanes := []
	for lx in LANES:
		var ok := true
		for e in enemies:
			if absf(e.x - lx) < 2.6 and absf(e.z - z) < 32.0:
				ok = false
		if not ahead and absf(lx - px) < 3.0:
			ok = false
		if ok:
			free_lanes.append(lx)
	if free_lanes.is_empty():
		return
	var lane_x: float = free_lanes[rng.randi() % free_lanes.size()]
	var info := _pick_info(ahead)
	if info.is_empty():
		return
	var node: Node3D = info.scene.instantiate()
	U.bendify(node)
	add_child(node)
	var spd := rng.randf_range(info.min, maxf(info.min, info.max))
	if not ahead:
		spd = maxf(spd, rng.randf_range(40.0, 50.0))
	var e := {"node": node, "wheels": U.wheels(node), "hw": info.hw, "hl": info.hl,
		"x": lane_x, "target_x": lane_x, "z": z, "prev_z": z, "base": spd, "speed": spd,
		"weave": info.weave or (day >= 3 and rng.randf() < 0.15), "ai_t": rng.randf_range(1.0, 3.0), "hit_cd": 0.0}
	node.position = Vector3(lane_x, 0, z)
	enemies.append(e)


func _update_enemies(delta: float) -> void:
	var counting := state == ST_RACE
	for e in enemies:
		var cap: float = e.base
		for o in enemies:
			if o == e:
				continue
			if absf(o.x - e.x) < 2.6 and o.z < e.z and e.z - o.z < e.hl + o.hl + 7.0:
				cap = minf(cap, o.speed)
		e.speed = move_toward(e.speed, cap, 18.0 * delta)
		e.ai_t -= delta
		if e.weave and e.ai_t <= 0.0:
			e.ai_t = rng.randf_range(1.5, 3.5)
			e.target_x = LANES[rng.randi() % 3]
		if e.z > 0.0 and e.z < 22.0 and absf(e.x - px) < 2.6 and e.speed > speed:
			var best: float = e.target_x
			var bd := -1.0
			for lx in LANES:
				var d := absf(lx - px)
				if d > bd:
					bd = d
					best = lx
			e.target_x = best
		e.x = move_toward(e.x, e.target_x, 3.5 * delta)
		e.hit_cd = maxf(0.0, e.hit_cd - delta)
		e.prev_z = e.z
		e.z += (speed - e.speed) * delta
		if counting:
			if e.prev_z < 0.0 and e.z >= 0.0:
				total_passed += 1
				if not quota_met:
					cars_left -= 1
					audio.play("pass", -6.0)
					if cars_left <= 0:
						cars_left = 0
						quota_met = true
						audio.play("quota")
						hud.show_message("META CUMPRIDA!", "Sobreviva até o amanhecer para o DIA %d" % (day + 1), Color(0.62, 1.0, 0.22), 3.0)
			elif e.prev_z >= 0.0 and e.z < 0.0:
				total_passed = maxi(0, total_passed - 1)
				if not quota_met:
					cars_left += 1
					audio.play("overtaken", -5.0)
		var node: Node3D = e.node
		node.position = Vector3(e.x, 0.0, e.z)
		node.rotation.y = -(e.target_x - e.x) * 0.06
		for w in e.wheels:
			w.rotation.x -= e.speed * delta / 0.45

	for i in range(enemies.size() - 1, -1, -1):
		var e: Dictionary = enemies[i]
		if e.z > 70.0 or e.z < -480.0:
			e.node.queue_free()
			enemies.remove_at(i)


func _check_collisions() -> void:
	for e in enemies:
		if e.hit_cd > 0.0:
			continue
		if absf(e.x - px) < player.hw + e.hw and absf(e.z) < player.hl + e.hl:
			_crash(e)


func _crash(e: Dictionary) -> void:
	e.hit_cd = 1.2
	if e.z < 0.0:
		speed = minf(speed, e.speed * 0.45)
		e.z -= 3.0
	else:
		e.speed = speed * 0.8
		e.z += 3.0
	var dir := signf(px - e.x)
	if dir == 0.0:
		dir = 1.0 if randf() < 0.5 else -1.0
	lat_vel = dir * 9.0
	crash_t = 1.1
	shake = 1.1
	nitro_on = false
	audio.play("crash", 0.0, rng.randf_range(0.9, 1.1))
	_vibrate(0.8, 1.0, 0.5)


# ================================================================ audio / hud
func _update_audio(acc: float, active: bool) -> void:
	var g := 0
	while g < 5 and speed > GEARS[g + 1]:
		g += 1
	var lo: float = GEARS[g]
	var hi: float = GEARS[g + 1]
	var r := clampf((speed - lo) / (hi - lo), 0.0, 1.0)
	if g + 1 > gear and state == ST_RACE:
		audio.play("shift", -8.0)
	gear = g + 1
	var pitch := 0.55 + r * 0.95 + g * 0.1 + (0.25 if nitro_on else 0.0)
	var vol := -9.0 + acc * 3.0 if active else -14.0
	audio.set_engine(pitch, vol)
	audio.set_loop("wind", clampf(speed / NITRO_SPEED, 0.0, 1.0) * 0.6 + dust_amt * 0.5, -6.0, 0.8 + speed / 140.0)
	audio.set_loop("rumble", 1.0 if (absf(px) > ROAD_HALF - 0.5 and speed > 4.0) else 0.0, -4.0)
	audio.set_loop("rain", rain_amt, -10.0)


func _update_hud() -> void:
	var danger := not quota_met and day_t > 0.82
	hud.update_stats(speed * 3.6, gear, distance / 1000.0, cars_left, quota_met, day, cur_phase, day_t, nitro, nitro_on, danger)


# ================================================================ recorde
func _load_record() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		record_km = cf.get_value("record", "km", 0.0)
		record_day = cf.get_value("record", "day", 0)


func _save_record() -> void:
	var cf := ConfigFile.new()
	cf.set_value("record", "km", record_km)
	cf.set_value("record", "day", record_day)
	cf.save(SAVE_PATH)

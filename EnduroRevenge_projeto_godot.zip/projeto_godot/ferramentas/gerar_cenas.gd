extends SceneTree
## Gera as cenas .tscn originais (jogador, inimigos, cenario) a partir de scripts/builders.gd.
## ATENCAO: sobrescreve as cenas em res://scenes/ e o main.tscn! Use so para restaurar o original.
## Uso:  godot --headless --path . -s res://ferramentas/gerar_cenas.gd

const B := preload("res://scripts/builders.gd")
const VEH := preload("res://scripts/veiculo.gd")
const PROP := preload("res://scripts/cenario.gd")
const MAIN := preload("res://scripts/main.gd")


func _initialize() -> void:
	for d in ["res://scenes/veiculos/inimigos", "res://scenes/cenario"]:
		DirAccess.make_dir_recursive_absolute(d)
	var rng := RandomNumberGenerator.new()
	rng.seed = 2077

	# jogador
	var p := B.build_player()
	var pr: Node3D = p.node
	pr.set_script(VEH)
	pr.half_width = 1.15
	pr.half_length = 2.1
	var player_scene := _save(pr, "res://scenes/veiculos/jogador.tscn")

	# inimigos: [arquivo, tipo, min, max, troca_faixa, peso, peso_dia, dia_min, por_tras]
	var enemies := [
		["sedan_1", "sedan", 26.0, 37.0, false, 1.0, 0.0, 1, true],
		["sedan_2", "sedan", 26.0, 37.0, false, 1.0, 0.0, 1, true],
		["sedan_3", "sedan", 26.0, 37.0, false, 1.0, 0.0, 1, true],
		["van_1", "van", 24.0, 32.0, false, 0.8, 0.0, 1, false],
		["van_2", "van", 24.0, 32.0, false, 0.8, 0.0, 1, false],
		["caminhao_1", "truck", 19.0, 26.0, false, 0.6, 0.0, 1, false],
		["caminhao_2", "truck", 19.0, 26.0, false, 0.6, 0.0, 2, false],
		["saqueador_1", "raider", 34.0, 46.0, true, 0.2, 0.2, 1, true],
		["saqueador_2", "raider", 34.0, 46.0, true, 0.2, 0.2, 1, true],
	]
	var enemy_scenes: Array[PackedScene] = []
	for e in enemies:
		var data := B.build_enemy(e[1], rng)
		var root := Node3D.new()
		root.name = String(e[0]).capitalize().replace(" ", "")
		root.set_script(VEH)
		var model: Node3D = data.node
		model.name = "Modelo"
		root.add_child(model)
		root.half_width = data.hw
		root.half_length = data.hl
		root.min_speed = e[2]
		root.max_speed = e[3]
		root.troca_faixa = e[4]
		root.peso_spawn = e[5]
		root.peso_por_dia = e[6]
		root.dia_minimo = e[7]
		root.pode_vir_por_tras = e[8]
		enemy_scenes.append(_save(root, "res://scenes/veiculos/inimigos/%s.tscn" % e[0]))

	# cenario: [arquivo, tipo, dist_min, dist_max, rotacao, peso]
	var props := [
		["carcaca_1", "wreck", 10.0, 22.0, true, 1.0], ["carcaca_2", "wreck", 10.0, 22.0, true, 1.0], ["carcaca_3", "wreck", 10.0, 22.0, true, 1.0],
		["arvore_seca_1", "tree", 10.0, 35.0, true, 1.0], ["arvore_seca_2", "tree", 10.0, 35.0, true, 1.0], ["arvore_seca_3", "tree", 10.0, 35.0, true, 1.0],
		["poste_luz_1", "pole", 9.0, 11.0, false, 1.0], ["poste_luz_2", "pole", 9.0, 11.0, false, 1.0],
		["ruina_1", "ruin", 20.0, 55.0, true, 1.0], ["ruina_2", "ruin", 20.0, 55.0, true, 1.0], ["ruina_3", "ruin", 20.0, 55.0, true, 1.0],
		["barris_toxicos_1", "barrels", 10.0, 22.0, true, 1.0], ["barris_toxicos_2", "barrels", 10.0, 22.0, true, 1.0],
		["pneus_1", "tires", 10.0, 22.0, true, 0.8], ["pneus_2", "tires", 10.0, 22.0, true, 0.8],
		["rochas_1", "rocks", 10.0, 35.0, true, 1.0], ["rochas_2", "rocks", 10.0, 35.0, true, 1.0],
		["placa_1", "sign", 10.0, 18.0, false, 0.7], ["placa_2", "sign", 10.0, 18.0, false, 0.7],
		["onibus_1", "bus", 20.0, 45.0, true, 0.6], ["onibus_2", "bus", 20.0, 45.0, true, 0.6],
		["torre_1", "tower", 20.0, 50.0, false, 0.6],
	]
	var prop_scenes: Array[PackedScene] = []
	for e in props:
		var root := Node3D.new()
		root.name = String(e[0]).capitalize().replace(" ", "")
		root.set_script(PROP)
		var model := B.build_prop(e[1], rng)
		model.name = "Modelo"
		root.add_child(model)
		root.dist_min = e[2]
		root.dist_max = e[3]
		root.rotacao_aleatoria = e[4]
		root.peso = e[5]
		prop_scenes.append(_save(root, "res://scenes/cenario/%s.tscn" % e[0]))

	var post := B.build_post()
	post.name = "PosteRefletor"
	var post_scene := _save(post, "res://scenes/cenario/poste_refletor.tscn")
	var sky := B.build_skyline(rng)
	sky.name = "Horizonte"
	var sky_scene := _save(sky, "res://scenes/cenario/horizonte.tscn")

	var main := Node3D.new()
	main.name = "Main"
	main.set_script(MAIN)
	main.cena_jogador = player_scene
	main.cenas_inimigos = enemy_scenes
	main.cenas_cenario = prop_scenes
	main.cena_poste = post_scene
	main.cena_horizonte = sky_scene
	_save(main, "res://scenes/main.tscn")
	print("Cenas geradas com sucesso.")
	quit()


func _save(root: Node, path: String) -> PackedScene:
	for n in root.find_children("*", "", true, false):
		n.owner = root
	var ps := PackedScene.new()
	var err := ps.pack(root)
	if err != OK:
		push_error("Falha ao empacotar %s" % path)
	ResourceSaver.save(ps, path)
	root.free()
	return load(path)
